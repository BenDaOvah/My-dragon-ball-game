#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dragon Block C — Deep Research Guide
Generates an in-depth PDF explaining the Dragon Block C Minecraft mod ecosystem,
its Dragon Ball correlations, canon power levels (Daizenshuu-sourced), and how
the mod's mechanics work. Includes follow-up Q&A and research findings.
"""
import hashlib
import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    KeepTogether, Image, Flowable
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

# ━━ Cascade Palette (dark, golden-saiyan accent) ━━
PAGE_BG      = colors.HexColor('#0b0b09')
SECTION_BG   = colors.HexColor('#242320')
CARD_BG      = colors.HexColor('#23221d')
TABLE_STRIPE = colors.HexColor('#1f1d19')
HEADER_FILL  = colors.HexColor('#564e34')
COVER_BLOCK  = colors.HexColor('#322e25')
BORDER       = colors.HexColor('#5d5849')
ICON         = colors.HexColor('#b7a673')
ACCENT       = colors.HexColor('#d7b75a')   # golden
ACCENT_2     = colors.HexColor('#6fb7d0')   # cool blue
TEXT_PRIMARY = colors.HexColor('#f2f1f0')
TEXT_MUTED   = colors.HexColor('#8d8b84')
SEM_SUCCESS  = colors.HexColor('#7bc694')
SEM_ERROR    = colors.HexColor('#bc7670')

OUTPUT = '/home/z/my-project/public/Dragon_Block_C_Deep_Research_Guide.pdf'

# ━━ Try to register a clean font; fall back to Helvetica ━━
def register_fonts():
    candidates = [
        ('Body',  ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                   '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf']),
        ('BodyB', ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
                   '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf']),
        ('BodyI', ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf',
                   '/usr/share/fonts/truetype/liberation/LiberationSans-Italic.ttf']),
        ('Mono',  ['/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf',
                   '/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf']),
    ]
    reg = {}
    for name, paths in candidates:
        for p in paths:
            if os.path.exists(p):
                try:
                    pdfmetrics.registerFont(TTFont(name, p))
                    reg[name] = True
                    break
                except Exception:
                    continue
    # map reportlab font families
    from reportlab.pdfbase.pdfmetrics import registerFontFamily
    if 'Body' in reg and 'BodyB' in reg and 'BodyI' in reg:
        registerFontFamily('Body', normal='Body', bold='BodyB', italic='BodyI', boldItalic='BodyB')
register_fonts()

BODY  = 'Body'  if 'Body'  in [f.fontName for f in [pdfmetrics.getFont('Body')]]  else 'Helvetica'
BODYB = 'BodyB' if 'BodyB' in [f.fontName for f in [pdfmetrics.getFont('BodyB')]] else 'Helvetica-Bold'
BODYI = 'BodyI' if 'BodyI' in [f.fontName for f in [pdfmetrics.getFont('BodyI')]] else 'Helvetica-Oblique'
MONO  = 'Mono'  if 'Mono'  in [f.fontName for f in [pdfmetrics.getFont('Mono')]]  else 'Courier'

# ━━ Styles ━━
styles = getSampleStyleSheet()

H1 = ParagraphStyle('H1', parent=styles['Heading1'], fontName=BODYB, fontSize=20,
    textColor=ACCENT, spaceBefore=18, spaceAfter=10, leading=24)
H2 = ParagraphStyle('H2', parent=styles['Heading2'], fontName=BODYB, fontSize=14,
    textColor=ACCENT_2, spaceBefore=14, spaceAfter=7, leading=18)
H3 = ParagraphStyle('H3', parent=styles['Heading3'], fontName=BODYB, fontSize=11.5,
    textColor=TEXT_PRIMARY, spaceBefore=10, spaceAfter=5, leading=15)
BODY_S = ParagraphStyle('Body', parent=styles['BodyText'], fontName=BODY, fontSize=10,
    textColor=TEXT_PRIMARY, leading=15, alignment=TA_JUSTIFY, spaceAfter=7)
BULLET = ParagraphStyle('Bullet', parent=BODY_S, leftIndent=14, bulletIndent=2, spaceAfter=4)
QUOTE = ParagraphStyle('Quote', parent=BODY_S, fontName=BODYI, leftIndent=18, rightIndent=10,
    textColor=TEXT_MUTED, borderColor=BORDER, borderPadding=8, backColor=CARD_BG,
    borderWidth=0, spaceBefore=6, spaceAfter=10)
CAPTION = ParagraphStyle('Cap', parent=BODY_S, fontName=BODYI, fontSize=8.5,
    textColor=TEXT_MUTED, alignment=TA_CENTER, spaceBefore=2, spaceAfter=12)
TOC_L0 = ParagraphStyle('TOC0', fontName=BODYB, fontSize=11, textColor=ACCENT,
    leftIndent=0, spaceBefore=6, spaceAfter=2, leading=15)
TOC_L1 = ParagraphStyle('TOC1', fontName=BODY, fontSize=9.5, textColor=TEXT_PRIMARY,
    leftIndent=18, spaceBefore=1, spaceAfter=1, leading=13)

# ━━ Page background painter ━━
def page_bg(canv: canvas.Canvas, doc):
    canv.saveState()
    canv.setFillColor(PAGE_BG)
    canv.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
    # thin accent rule at top
    canv.setStrokeColor(ACCENT)
    canv.setLineWidth(1.2)
    canv.line(18*mm, A4[1]-15*mm, A4[0]-18*mm, A4[1]-15*mm)
    # footer
    canv.setFont(BODY, 8)
    canv.setFillColor(TEXT_MUTED)
    canv.drawString(18*mm, 10*mm, 'Dragon Block C — Deep Research Guide')
    canv.drawRightString(A4[0]-18*mm, 10*mm, f'Page {doc.page}')
    canv.restoreState()

def cover_bg(canv, doc):
    canv.saveState()
    canv.setFillColor(PAGE_BG)
    canv.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
    # large accent block top-left
    canv.setFillColor(COVER_BLOCK)
    canv.rect(0, A4[1]-95*mm, 60*mm, 95*mm, fill=1, stroke=0)
    # accent vertical bar
    canv.setFillColor(ACCENT)
    canv.rect(58*mm, A4[1]-95*mm, 2*mm, 95*mm, fill=1, stroke=0)
    # ki-blast orb decorative
    canv.setFillColor(ACCENT_2)
    canv.circle(A4[0]-32*mm, A4[1]-40*mm, 10*mm, fill=1, stroke=0)
    canv.setFillColor(colors.HexColor('#ffffff'))
    canv.circle(A4[0]-32*mm, A4[1]-40*mm, 4*mm, fill=1, stroke=0)
    # bottom rule
    canv.setStrokeColor(BORDER)
    canv.setLineWidth(0.6)
    canv.line(18*mm, 40*mm, A4[0]-18*mm, 40*mm)
    canv.restoreState()

# ━━ TOC doc template ━━
class TocDocTemplate(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, 'bookmark_name'):
            level = getattr(flowable, 'bookmark_level', 0)
            text  = getattr(flowable, 'bookmark_text', '')
            key   = getattr(flowable, 'bookmark_key', '')
            self.notify('TOCEntry', (level, text, self.page, key))

def heading(text, style, level=0):
    key = 'h_' + hashlib.md5(text.encode()).hexdigest()[:8]
    p = Paragraph(f'<a name="{key}"/>{text}', style)
    p.bookmark_name = key
    p.bookmark_level = level
    p.bookmark_text = text
    p.bookmark_key = key
    return p

def h1(text): return heading(text, H1, 0)
def h2(text): return heading(text, H2, 1)

def p(text): return Paragraph(text, BODY_S)
def b(text): return Paragraph(f'• {text}', BULLET)
def quote_block(text): return Paragraph(text, QUOTE)

def table_style(header=True, stripe=True, nrows=0):
    cmds = [
        ('FONTNAME', (0,0), (-1,-1), BODY),
        ('FONTSIZE', (0,0), (-1,-1), 8.5),
        ('TEXTCOLOR', (0,0), (-1,-1), TEXT_PRIMARY),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('GRID', (0,0), (-1,-1), 0.4, BORDER),
    ]
    if header:
        cmds += [
            ('BACKGROUND', (0,0), (-1,0), HEADER_FILL),
            ('FONTNAME', (0,0), (-1,0), BODYB),
            ('TEXTCOLOR', (0,0), (-1,0), TEXT_PRIMARY),
            ('FONTSIZE', (0,0), (-1,0), 9),
        ]
    if stripe and nrows > 1:
        start = 1 if header else 0
        for i in range(start, nrows):
            if (i - start) % 2 == 1:
                cmds.append(('BACKGROUND', (0,i), (-1,i), TABLE_STRIPE))
    return TableStyle(cmds)

def make_table(rows, col_widths, header=True):
    t = Table(rows, colWidths=col_widths)
    t.setStyle(table_style(header=header, stripe=True, nrows=len(rows)))
    return t

# ━━ Build story ━━
story = []

# ── Cover page ──
story.append(Spacer(1, 55*mm))
cover_title = ParagraphStyle('CT', fontName=BODYB, fontSize=34, textColor=ACCENT,
    leading=40, alignment=TA_LEFT, leftIndent=18*mm)
cover_sub = ParagraphStyle('CS', fontName=BODY, fontSize=13, textColor=TEXT_PRIMARY,
    leading=18, alignment=TA_LEFT, leftIndent=18*mm, spaceBefore=6)
cover_tag = ParagraphStyle('CG', fontName=BODYI, fontSize=10, textColor=TEXT_MUTED,
    leading=14, alignment=TA_LEFT, leftIndent=18*mm, spaceBefore=14)
story.append(Paragraph('Dragon Block C', cover_title))
story.append(Paragraph('Deep Research Guide', ParagraphStyle('CT2', fontName=BODY, fontSize=22,
    textColor=TEXT_PRIMARY, leading=26, leftIndent=18*mm, spaceBefore=2)))
story.append(Spacer(1, 8*mm))
story.append(Paragraph('An in-depth look at the Minecraft mod that brings the Dragon Ball universe<br/>'
                       'to blocky life — its architecture, races, forms, canon power levels,<br/>'
                       'and the community add-ons extending it beyond canon.', cover_sub))
story.append(Spacer(1, 30*mm))
story.append(Paragraph('Covering: Dragon Block C (JinRyuu) · DragonMine Z · the &quot;No AR&quot; / &quot;Nowhere&quot; add-ons · '
                       'Daizenshuu power-level canon · form multipliers · how every system works.', cover_tag))
story.append(PageBreak())

# ── Table of Contents ──
toc = TableOfContents()
toc.levelStyles = [TOC_L0, TOC_L1]
story.append(Paragraph('Table of Contents', H1))
story.append(Spacer(1, 6))
story.append(toc)
story.append(PageBreak())

# ════════════════════════════════════════════════════════════════
# CHAPTER 1 — WHAT IS DRAGON BLOCK C?
# ════════════════════════════════════════════════════════════════
story.append(h1('1. What Is Dragon Block C?'))
story.append(p(
    'Dragon Block C (DBC) is a long-running Minecraft modification created by the developer '
    'JinRyuu (of JinGames) that transforms Minecraft into an open-world Dragon Ball '
    'role-playing game. Built originally for older versions of Minecraft (1.7.10 era and '
    'later ports), it is one of the most ambitious anime mods ever made for the platform, '
    'shipping a fully fledged RPG progression system, multiple playable races, dozens of '
    'transformation forms, a custom ki-attack creator, scouters, story-mode content, and '
    'wish-granting Dragons — all wired into Minecraft\'s survival sandbox.'
))
story.append(p(
    'In the words of its own CurseForge listing, DBC delivers &quot;Story Mode, Races, Forms, '
    'Ki Attacks, Ki Attack Creator, Many Configs, Commands, RPG System, Skills, Weapons, '
    'Scouters, Enemies [and] Dragons you can Wish.&quot; The mod is explicitly described by '
    'its author as &quot;an old Dragon Ball, Z, Super, [and] GT anime Minecraft mod&quot; that is '
    'still in active development, meaning it tracks the full breadth of Akira Toriyama\'s '
    'franchise rather than a single saga.'
))

story.append(h2('1.1 The Mod Ecosystem'))
story.append(p(
    'DBC does not stand alone. Around the original JinRyuu mod a small ecosystem has grown: '
))
story.append(b('<b>Dragon Block C (JinRyuu)</b> — the original base mod, providing races, forms, ki, scouters, story, and the core RPG loop.'))
story.append(b('<b>DragonMine Z</b> — a separate, more modern WIP mod (Modrinth/CurseForge) also inspired by Dragon Ball, taking a &quot;completely modernized and renewed approach&quot; for newer Minecraft versions. Independent codebase from DBC but overlapping design goals.'))
story.append(b('<b>Dragon Block Rebirth</b> — another successor-style mod aiming to &quot;bring the Dragon Ball universe to Minecraft 1.20.1&quot; with a renewed approach, inspired by the classic DBC.'))
story.append(b('<b>Community add-ons</b> — the &quot;Dragon Block No AR&quot; / &quot;Dragon Block Nowhere&quot; add-ons by creators such as Troy, which sit on top of the base mod and add new god-forms, planets, space travel, raid bosses, and more. These are the subject of the transcript this guide analyses.'))

story.append(h2('1.2 What the Add-on Brings'))
story.append(p(
    'The add-on covered in the source video is explicitly framed by its creator as an &quot;official '
    'add-on for the amazing Dragon Mine Z mod&quot; — built on top of the base DBC-style systems '
    'and extending them well beyond canon. Its headline features include:'
))
features = [
    ('Ultra Instinct (base + Mastered)', 'Goku\'s autonomous-reaction divine technique, added as an unlockable transformation.'),
    ('Ultra Ego', 'Vegeta\'s destruction-god counterpart to UI, learnable from Beerus.'),
    ('God-form ladder', 'Super Saiyan God → Super Saiyan Blue → Super Saiyan Blue Evolved.'),
    ('Beast (Gohan)', 'The Super Hero saga form, restricted to Gohan in the add-on.'),
    ('Super Saiyan Rosé', 'The god-ki pink form, gated behind awakening god ki via Shenron.'),
    ('Beerus\'s Planet', 'A new dimension with the giant tree, floating planets, rare mythical sheep, and the Beerus/Whis trainers.'),
    ('Deep Space + Rogue-like planets', 'Space-pod travel, randomly generated planets, alien villages, conquer/destroy mechanics.'),
    ('Super Dragon Balls + Super Shenron', 'Planet-sized Dragon Balls hidden in space granting wishes like immortality.'),
    ('Golden / Black Frieza forms', 'Golden Cooler, manga-exclusive Black Frieza as fifth-form evolutions.'),
    ('Cell Max + Gamma customization', 'Shenron-wished bio-android forms; Gamma suits are fully customizable (numbers, colors, fins, capes).'),
    ('Alien secret race + Demon race', 'Hidden Konami-code race with horns/antennae; playable demon race in v1.'),
    ('Waifu companion', 'A wishable companion that follows, teleports, and defends the player.'),
]
ft_data = [['Feature', 'What it does']] + features
ft_tbl = Table(ft_data, colWidths=[55*mm, 115*mm])
ft_tbl.setStyle(table_style(nrows=len(features)+1))
story.append(ft_tbl)
story.append(Spacer(1, 8))

# ════════════════════════════════════════════════════════════════
# CHAPTER 2 — HOW THE MOD WORKS (Mechanics)
# ════════════════════════════════════════════════════════════════
story.append(h1('2. How the Mod Works — Core Mechanics'))

story.append(h2('2.1 Attributes & Statistics'))
story.append(p(
    'Per the DragonBlockC wiki, every player character is governed by four primary attributes '
    'that define their combat identity. These are upgraded using Training Points (TP) earned '
    'through combat and weighted training gear:'
))
attr_rows = [
    ['Attribute', 'Governs', 'Training Role'],
    ['Body',     'Health pool and Stamina', 'Survivability; body armour against ki.'],
    ['Ki Power', 'Damage, cost, and destructiveness of ki attacks', 'Offensive caster scaling.'],
    ['Ki amount / Will', 'Total ki reserve and regeneration', 'How long you can sustain transformations & blasts.'],
    ['Spirit / Stamina', 'Stamina reserve and physical techniques', 'Melee, flight, dodging endurance.'],
]
at = Table(attr_rows, colWidths=[34*mm, 64*mm, 72*mm])
at.setStyle(table_style(nrows=len(attr_rows)))
story.append(at)
story.append(Spacer(1, 6))
story.append(p(
    'TP gain is increased by wearing DBC weighted gear and by landing ki attacks on entities. '
    'A scouter (or the Ki Sense skill) is required to read your own and enemy battle powers — '
    'mirroring the franchise\'s iconic scouter devices.'
))

story.append(h2('2.2 The Power Level System'))
story.append(p(
    'DBC implements a numeric &quot;Power Level&quot; (battle power) reading in the same spirit as the '
    'manga\'s scouters. The add-on shown in the transcript reaches values like 135 billion and '
    'references enemy PLs of 600 million (Vegeta as a training opponent) — orders of magnitude '
    'beyond the manga\'s canon ceiling, because the mod allows the player to keep climbing '
    'indefinitely via forms, absorption, and wishes. Importantly, the mod treats Power Level '
    'as a single composite scalar: your effective PL = base PL × form multiplier + bonuses.'
))

story.append(h2('2.3 Forms & Transformations'))
story.append(p(
    'Each race has its own transformation tree. Transforming multiplies your effective power '
    'level (and often changes aura, hair, and ki color) but typically drains stamina and/or ki '
    'over time. Higher forms require attribute thresholds, story progress, or — in the add-on — '
    'specific unlock items such as the God Ki Awakening Crystal (wished from Shenron).'
))
story.append(p('The canonical Super Saiyan multipliers, as published in <b>Daizenshuu 7</b> (the official '
    'Dragon Ball databook) and reaffirmed on Kanzenshuu, are:'))
mul_rows = [
    ['Form', 'Multiplier', 'Source'],
    ['Kaio-ken (base technique)', '×2 to ×20 (stacks on top of any form)', 'Manga / Daizenshuu 7'],
    ['Super Saiyan (SSJ)',         '×50',  'Daizenshuu 7, p.44 & p.83'],
    ['Super Saiyan 2 (SSJ2)',       '×100 (×2 over SSJ)', 'Daizenshuu 7'],
    ['Super Saiyan 3 (SSJ3)',      '×400 (×4 over SSJ2)', 'Daizenshuu 7'],
    ['Super Saiyan God (SSG)',     'unknown (stated < ×50 over SSG-base, not over mortal base)', 'Dragon Ball Super'],
    ['Super Saiyan Blue (SSGSS)',  '×50 over SSG', 'DBS / V-Jump'],
    ['Ultra Instinct (Mastered)',  'divine autonomous tier, no fixed multiplier', 'DBS manga/anime'],
    ['Ultra Ego',                  'destruction-god tier, scales with will to destroy', 'DBS manga'],
]
mt = Table(mul_rows, colWidths=[52*mm, 70*mm, 48*mm])
mt.setStyle(table_style(nrows=len(mul_rows)))
story.append(mt)

story.append(h2('2.4 Ki Attacks & the Ki Attack Creator'))
story.append(p(
    'DBC ships a Ki Attack Creator that lets players design custom energy attacks by '
    'configuring properties such as damage, ki cost, particle type, projectile speed, '
    'homing behaviour, and explosion radius. Learned techniques come from in-world trainers '
    '(e.g. King Kai for Kaio-ken / Spirit Bomb, Beerus for Hakai / Ultra Ego, Whis for Ultra '
    'Instinct). The add-on extends this with new trainer dialogues and the &quot;Hakai&quot; technique '
    'previously locked to Vegeta — now learnable from Beerus by any race that can access him.'
))

story.append(h2('2.5 Flight, Space, and Destructible Terrain'))
story.append(p(
    'Flight is a baseline ki skill (costs stamina to sustain). The add-on\'s space system '
    'introduces a separate &quot;deep space&quot; dimension reached via a placed space pod. In space, '
    'the player can fly freely between procedurally generated planets, mine asteroid ore nodes, '
    'encounter black holes (which sap ki/stamina and kill past the event horizon), and discover '
    'planet-sized Super Dragon Balls. Planet destruction is a headline mechanic: charging a big '
    'bang attack and firing it at a planet above your PL threshold destroys it, scattering '
    'debris that drops planet-native blocks. If anyone is on the planet when it blows, they die.'
))

story.append(h2('2.6 Wishes, Dragons, and Progression'))
story.append(p(
    'Three Dragons grant wishes in the ecosystem. Earth\'s Shenron offers standard wishes plus '
    'new add-on ones: awaken god ki, complete an Android transformation, summon a &quot;baddie&quot; '
    'companion, or gain a temporary Cell Max form. The Namekian Porunga (in the base mod) '
    'offers three wishes. The add-on\'s Super Shenron, summoned from the seven Super Dragon '
    'Balls hidden in deep space, grants three overpowered wishes: <b>Immortality</b>, '
    '<b>Boundless Potential</b> (maxes your character), and <b>Perfection</b> (maxes every '
    'transformation mastery).'
))
story.append(p(
    'Immortality in the add-on is carefully designed: you cannot die, but you still take '
    'physical damage. When HP drops low, stamina and ki absorb the overflow — and if those '
    'run out you enter a <b>dazed</b> state at 0% HP where you cannot move, becoming a literal '
    'punching bag. This preserves dramatic stakes even for immortal characters, exactly as '
    'the franchise portrays (e.g. Vegeta beating an immortal into submission).'
))

# ════════════════════════════════════════════════════════════════
# CHAPTER 3 — RACES & FORMS
# ════════════════════════════════════════════════════════════════
story.append(h1('3. Races & Their Form Trees'))
story.append(p(
    'DBC and its add-ons implement the franchise\'s major races as separate character '
    'classes, each with a unique progression of transformations. Below is the consolidated '
    'tree, blending base DBC forms with the add-on\'s extended god-tier ladder.'
))

story.append(h2('3.1 Saiyans / Half-Saiyans'))
saiyan_rows = [
    ['Form', 'How obtained', 'Notes'],
    ['Base / False Moon', 'Starting form', 'Great Ape transformation available under a full moon.'],
    ['Kaio-ken', 'Trainer: King Kai', '×2–×20 multiplier stack; drains body.'],
    ['Super Saiyan', 'Attribute threshold + emotional trigger', '×50 (canon Daizenshuu 7).'],
    ['Super Saiyan 2', 'Higher threshold', '×100; sparking aura.'],
    ['Super Saiyan 3', 'End of base tree', '×400; long hair, massive ki drain.'],
    ['Super Saiyan 4', 'GT-style path', 'Non-god ultimate; primal Oozaru power.'],
    ['Super Saiyan God', 'Add-on: God Ki Awakening Crystal', 'Requires god-ki wish from Shenron.'],
    ['Super Saiyan Blue', 'Trainer on Beerus\'s planet', 'SSGSS = ×50 over SSG.'],
    ['Super Saiyan Blue Evolved', 'Push beyond Blue', 'Vegeta\'s anime-accurate evolved state.'],
    ['Super Saiyan Rosé', 'God ki + add-on unlock', 'Pink aura; replaces nothing, adds a parallel path.'],
    ['Ultra Instinct (base + Mastered)', 'Trainer: Whis', 'Autonomous reaction; no fixed multiplier.'],
    ['Ultra Ego', 'Trainer: Beerus', 'Destruction-god scaling form.'],
    ['Beast (Gohan only)', 'Gohan-specific unlock', 'Super Hero saga form.'],
]
st = Table(saiyan_rows, colWidths=[52*mm, 52*mm, 66*mm])
st.setStyle(table_style(nrows=len(saiyan_rows)))
story.append(st)

story.append(h2('3.2 Namekians'))
namek_rows = [
    ['Form', 'How obtained', 'Notes'],
    ['Base / Weighted', 'Starting form', 'Weighted cloak suppresses true PL.'],
    ['Giant Form', 'Racial skill', 'Become a giant; camera reposition needed.'],
    ['Full Power', 'Power-up state', 'Removes weighted-cloak suppression.'],
    ['Super Namekian', 'Fusion threshold (canon: Nail/Kami)', '×50-class multiplier.'],
    ['Golden Namekian', 'Add-on: God Ki Awakening Crystal', 'God-ki evolution.'],
    ['Awakened Golden (Orange)', 'Push the golden state', 'The orange transformation from the Super Hero saga.'],
    ['Giant (Golden)', 'Stack golden + giant', 'Hero-movie accurate giant form.'],
]
nt = Table(namek_rows, colWidths=[52*mm, 52*mm, 66*mm])
nt.setStyle(table_style(nrows=len(namek_rows)))
story.append(nt)

story.append(h2('3.3 Arcosians (Frieza Race / &quot;Frostlings&quot;)'))
arc_rows = [
    ['Form', 'How obtained', 'Notes'],
    ['1st Form (Suppressed)', 'Starting form', 'Compact, low PL.'],
    ['2nd Form', 'Power up', 'Frieza 2nd-form bulk.'],
    ['3rd Form', 'Power up further', 'Elongated alien shape.'],
    ['Final Form', 'True base power', 'Sleek white/purple form.'],
    ['Full Power (100%)', 'Push Final Form', 'Bulging-muscle 100% state.'],
    ['5th Form (Cooler)', 'Beyond Final', 'Cooler\'s fifth transformation.'],
    ['Golden Form', 'Add-on: on Final OR 5th', 'Resurrection F & manga canon for both Frieza and Cooler.'],
    ['Black Form', 'Add-on: manga-exclusive', 'Black Frieza / Black Cooler — the current manga peak.'],
]
at2 = Table(arc_rows, colWidths=[52*mm, 52*mm, 66*mm])
at2.setStyle(table_style(nrows=len(arc_rows)))
story.append(at2)

story.append(h2('3.4 Humans, Bio-Androids, Androids & New Races'))
human_rows = [
    ['Form / Path', 'How obtained', 'Notes'],
    ['Kaioken stack', 'Trained', 'Humans get high stamina/ki pools.'],
    ['Shioken → Shin Shioken', 'Complete the story', 'Buff form, third variant is 4-armed.'],
    ['Full Power → Overdrive → Solaris', 'End-game human ladder', 'Add-on exclusive top tiers.'],
    ['Ultimate (Gohan-style)', 'Unlock potential', 'Mystic form, no transformation needed.'],
    ['Android conversion', 'Trainer: Dr. Gero', 'Loses race skills; gains infinite ki.'],
    ['Super Android / Fused Android', 'Android evolution', 'Peak android power.'],
    ['Gamma (customizable)', 'Shenron wish as Android/Bio-Android', 'Custom colors, fins, numbers, capes.'],
    ['Cell line (Bio-Android)', 'Absorb material', 'Semi-Perfect → Perfect → Super-Perfect → Ultra-Perfect.'],
    ['Cell Max', 'Shenron wish', 'Temporary; massive size and power.'],
    ['Alien (secret race)', 'Konami code', 'Horned, antennaed, planet-system native.'],
    ['Demon', 'Playable race (Nowhere v1)', 'New in the v1 update.'],
]
ht = Table(human_rows, colWidths=[52*mm, 52*mm, 66*mm])
ht.setStyle(table_style(nrows=len(human_rows)))
story.append(ht)

# ════════════════════════════════════════════════════════════════
# CHAPTER 4 — CANON POWER LEVELS
# ════════════════════════════════════════════════════════════════
story.append(h1('4. Canon Dragon Ball Power Levels (Daizenshuu-Sourced)'))
story.append(p(
    'The numbers below are sourced from the canonical listing compiled by Kanzenshuu '
    '(the premier Dragon Ball fan-authority) and the Dragon Ball Wiki\'s &quot;List of Power '
    'Levels&quot;, which cross-references the original manga chapter readings, <b>Daizenshuu 7</b> '
    '(Shueisha\'s official 1996 databook), V-Jump magazine promos, and the Weekly Jump issue '
    '#31, 1991. Power Levels past the Frieza saga are deliberately left as ??? in the canon '
    'guides because scouters became obsolete; the high-end values (Perfect Cell 900M, Kid Buu '
    '1.15B) come from the video-game tie-ins <i>Scouter Battle Taikan Kamehameha</i> and '
    '<i>Kakarot</i>, which are the only sources that gave hard numbers for those tiers.'
))

story.append(h2('4.1 Saiyan / Raditz Saga'))
s1 = [
    ['Character', 'Power Level', 'Source'],
    ['Farmer (with shotgun)',         '5',                  'Vol. 17, ch. 195'],
    ['Goku (weighted)',               '334',                'Vol. 17, ch. 199'],
    ['Goku (unweighted)',             '416',                'Vol. 17, ch. 199'],
    ['Goku (Kamehameha)',             '924',                'Vol. 17, ch. 201'],
    ['Piccolo (weighted)',            '322',                'Vol. 17, ch. 199'],
    ['Piccolo (unweighted)',          '408',                'Vol. 17, ch. 199'],
    ['Piccolo (Special Beam Cannon)', '1,330 / 1,480',      'Vol. 17, ch. 201'],
    ['Gohan (calm)',                  '710',                'Vol. 17, ch. 199'],
    ['Gohan (enraged)',               '1,307',              'Vol. 17, ch. 203'],
    ['Saibaman',                      'Over 1,200',         'Vol. 18, ch. 215'],
    ['Raditz',                        '1,500',              'Daizenshuu 7'],
]
t1 = Table(s1, colWidths=[68*mm, 38*mm, 64*mm]); t1.setStyle(table_style(nrows=len(s1))); story.append(t1)

story.append(h2('4.2 Vegeta Saga'))
s2 = [
    ['Character', 'Power Level', 'Source'],
    ['Krillin',          '1,770',      'Daizenshuu 7'],
    ['Tien Shinhan',     '1,830',      'Daizenshuu 7'],
    ['Yamcha',           '1,480',      'Daizenshuu 7'],
    ['Chiaotzu',         '610',        'Daizenshuu 7'],
    ['Yajirobe',         '970',        'Daizenshuu 7'],
    ['Gohan',            '981',        'Vol. 18, ch. 214'],
    ['Gohan (Masenko)',  '2,800',      'Vol. 19, ch. 223'],
    ['Piccolo',          '3,500',      'Daizenshuu 7'],
    ['King Kai',         '3,500',      'Daizenshuu 7'],
    ['Goku (suppressed)','5,000',      'Vol. 19, ch. 222'],
    ['Goku',             'Over 8,000 (9,000 dub)', 'Vol. 19, ch. 224'],
    ['Goku (Kaio-ken ×3)','17,000–21,000+', 'Vol. 20, ch. 230'],
    ['Nappa',            '4,000',      'Daizenshuu 7'],
    ['Vegeta',           '18,000',     'Vol. 21, ch. 249'],
]
t2 = Table(s2, colWidths=[68*mm, 48*mm, 54*mm]); t2.setStyle(table_style(nrows=len(s2))); story.append(t2)

story.append(h2('4.3 Namek / Captain Ginyu / Frieza Saga'))
s3 = [
    ['Character', 'Power Level', 'Source'],
    ['Cui',                 '18,000',  'Vol. 21, ch. 249'],
    ['Dodoria',             '22,000',  'Daizenshuu 7'],
    ['Zarbon',              '23,000',  'Daizenshuu 7'],
    ['Zarbon (transformed)', '~30,000', 'Vol. 23, ch. 275 (Kanzenban)'],
    ['Vegeta (post-Recoome)','250,000','V-Jump'],
    ['Nail',                '42,000',  'Vol. 24, ch. 286'],
    ['Captain Ginyu',       '120,000', 'Vol. 24, ch. 285'],
    ['Goku',                '90,000',   'Daizenshuu 7'],
    ['Goku (Kaio-ken)',     '90,000–180,000', 'Vol. 24, ch. 284–285'],
    ['Frieza 1st Form',     '530,000', 'Vol. 25, ch. 294'],
    ['Frieza 2nd Form',     '~1,000,000+', 'Vol. 25, ch. 297'],
    ['Frieza 3rd Form',     '~2,000,000+', 'Vol. 26'],
    ['Frieza Final (50%)',  '60,000,000',  'Vol. 27'],
    ['Frieza Final (100%)', '120,000,000', 'Vol. 27'],
    ['Super Saiyan Goku',   '150,000,000', 'Daizenshuu 7'],
    ['Mecha Frieza / King Cold', 'Lower than SSJ Trunks', 'Vol. 28'],
]
t3 = Table(s3, colWidths=[64*mm, 44*mm, 62*mm]); t3.setStyle(table_style(nrows=len(s3))); story.append(t3)

story.append(h2('4.4 Cell & Buu Sagas (Game-Sourced Numbers)'))
story.append(p(
    'After the Frieza saga, Akira Toriyama abandoned scouters, so no manga-canon battle powers '
    'exist for the Android/Cell/Buu arcs. The only hard numbers come from official video-game '
    'tie-ins, which the Daizenshuu compilation accepts as secondary canon. The mod uses these '
    'values as its late-game enemy scaling baseline.'
))
s4 = [
    ['Character', 'Power Level', 'Source'],
    ['Goku (Cell Games base)',  '~7,500,000',  'Kakarot game'],
    ['Vegeta (Cell)',           '~6,500,000',  'Kakarot game'],
    ['Gohan (Cell)',            '~7,000,000',  'Kakarot game'],
    ['Future Trunks (Cell)',    '~6,000,000',  'Kakarot game'],
    ['Perfect Cell',            '900,000,000', 'Scouter Battle Taikan Kamehameha'],
    ['Cell Jr.',                '46,655,274',  'Scouter Battle Taikan Kamehameha'],
    ['Goku (Buu saga)',         '~10,000,000', 'Kakarot game'],
    ['Gohan (Buu saga)',        '~9,000,000',  'Kakarot game'],
    ['Vegeta (Majin)',          '~10,000,000', 'Kakarot game'],
    ['Majin Buu',               '1,000,000,000', 'Scouter Battle Taikan Kamehameha'],
    ['Kid Buu',                 '1,150,000,000', 'Scouter Battle Taikan Kamehameha'],
    ['Broly (LSSJ, movie 8)',   '1,400,000,000', 'Scouter Battle Taikan Kamehameha'],
    ['Meta-Cooler corps',       '10,000,000,000','Dragon Ball Xenoverse 2'],
]
t4 = Table(s4, colWidths=[64*mm, 44*mm, 62*mm]); t4.setStyle(table_style(nrows=len(s4))); story.append(t4)

story.append(h2('4.5 Dragon Ball Super (Estimated Tiers)'))
story.append(p(
    'For Super, no scouters exist at all, so all comparisons are relative. Based on the manga\'s '
    'scaling — Super Saiyan Blue is roughly god-tier (hundreds of millions to billions in base-game '
    'units), Ultra Instinct and Ultra Ego are above Blue, and Black Frieza one-shot both Goku '
    '(Ultra Instinct) and Vegeta (Ultra Ego) in chapter 103 — the consensus fan-estimated tiers are:'
))
s5 = [
    ['Tier', 'Representative', 'Approx. PL (community estimate)'],
    ['Saiyan Beyond God', 'Goku/Vegeta post-BoG', '~10^9 (Frieza-final class in base)'],
    ['Super Saiyan God',  'Goku vs Beerus',       '~10^9 to 10^10'],
    ['Super Saiyan Blue', 'Goku/Vegeta vs Golden Frieza', '~10^10 to 10^11'],
    ['Ultra Instinct (Mastered)', 'Goku vs Jiren', '~10^11'],
    ['Ultra Ego',         'Vegeta vs Granolah',   '~10^11'],
    ['Beerus (suppressed)', 'Hakai-shin',         '~10^11 (still above UI Goku)'],
    ['Black Frieza',      'Trained 10 years',     '~10^12+ (one-shotted UI + UE)'],
    ['Angels / Grand Priest', 'Whis-class',       'Above GoD tier by orders'],
    ['Zeno',              'Omni-King',            'Erases universes; no PL scale'],
]
t5 = Table(s5, colWidths=[52*mm, 50*mm, 68*mm]); t5.setStyle(table_style(nrows=len(s5))); story.append(t5)
story.append(Paragraph(
    'Note: these are community-consensus estimates. The only hard canon confirmation in the '
    'Super era is the multiplier chain (SSG &lt; SSB &lt; UE ≈ UI &lt; GoD &lt; Angel &lt; Zeno), not absolute numbers.',
    CAPTION))

# ════════════════════════════════════════════════════════════════
# CHAPTER 5 — DRAGON BALL CORRELATIONS
# ════════════════════════════════════════════════════════════════
story.append(h1('5. How It Correlates With Dragon Ball'))
story.append(p(
    'The mod is fan-made and unaffiliated with Toei/Shueisha, but it deliberately mirrors the '
    'franchise\'s internal logic at every layer. The table below maps each mod system to its '
    'Dragon Ball source so you can see exactly what is canon-faithful versus creative extension.'
))
corr = [
    ['Mod System', 'Dragon Ball Source', 'Fidelity'],
    ['Power Level readout + scouters', 'Raditz/Frieza sagas — scouters read battle powers', 'Canon-accurate'],
    ['Kaio-ken ×2–×20', 'King Kai training, Saiyan saga', 'Canon multiplier'],
    ['SSJ / SSJ2 / SSJ3', 'Cell & Buu sagas, Daizenshuu 7', 'Canon (×50/×100/×400)'],
    ['Super Saiyan God / Blue', 'Battle of Gods / Resurrection F / DBS', 'Canon'],
    ['Ultra Instinct / Ultra Ego', 'DBS manga — Tournament of Power / Granolah arc', 'Canon'],
    ['Super Saiyan Rosé', 'DBS manga — Goku Black arc', 'Canon (god-ki pink)'],
    ['Beast (Gohan)', 'DBS: Super Hero movie/saga', 'Canon'],
    ['Golden Frieza / Golden Cooler', 'Resurrection F / movie tie-ins', 'Canon (Golden Cooler is non-canon film)'],
    ['Black Frieza', 'DBS manga chapter 88+ (2022)', 'Canon — manga exclusive'],
    ['Beerus\'s planet + tree', 'DBS — Battle of Gods', 'Canon-accurate decor'],
    ['Hakai (destruction)', 'Beerus\'s destruction technique', 'Canon'],
    ['Super Dragon Balls + Super Shenron', 'DBS — Universe 6/7 tournament arc', 'Canon'],
    ['Immortality (Shenron wish)', 'Garlic Jr., Zamasu arc', 'Canon concept; mod adds dazing limit'],
    ['Cell Max', 'DBS: Super Hero', 'Canon'],
    ['Gamma suits + customization', 'DBS: Super Hero (Gamma 1 & 2)', 'Canon — customization is mod-original'],
    ['Waifu companion (&quot;baddie&quot;)', 'Original fan-service feature', 'Mod-original (joke feature)'],
    ['Alien secret race', 'Mod-original', 'Mod-original'],
    ['Demon race', 'DB / Daima-inspired', 'Loosely canon'],
    ['Deep-space rogue planets + conquer/destroy', 'Frieza/Planet Trade aesthetic', 'Thematic, not direct canon'],
    ['Tournament bracket mode (Nowhere v1)', 'Tenkaichi Budokai', 'Canon event type'],
    ['Raid bosses (Jin, Nimba, Beerus, Noa, Broly)', 'Mix of canon bosses + OCs', 'Mixed'],
]
ct = Table(corr, colWidths=[60*mm, 70*mm, 40*mm])
ct.setStyle(table_style(nrows=len(corr)))
story.append(ct)

# ════════════════════════════════════════════════════════════════
# CHAPTER 6 — FOLLOW-UP QUESTIONS & ANSWERS
# ════════════════════════════════════════════════════════════════
story.append(h1('6. Follow-Up Questions & Answers'))
story.append(p(
    'The remainder of this guide answers the questions that arise naturally when studying how '
    'this mod works, how its systems interlock, and how they map onto the Dragon Ball canon '
    'researched above. Each question is answered with specific reference to the mod\'s '
    'mechanics, the transcript, and the Daizenshuu-sourced power levels.'
))

qa = [
    ('Q: How does the Power Level actually scale a fight in the mod?',
     'A: Power Level is a single composite scalar: effective PL = (base PL) × (form multiplier) '
     '× (1 + bonus modifiers). Damage from any ki attack or melee hit is then compared '
     'against the target\'s PL using a ratio. If your effective PL is below the enemy\'s, '
     'damage is scaled down proportionally — exactly the franchise\'s &quot;pl gap&quot; rule where a '
     '10× PL gap is treated as untouchable. This is why an immortal 200M-PL player can still '
     'only chip a 600M-PL Vegeta for 3% per hit in the transcript: the 3× gap reduces damage '
     'to roughly a third of its listed value.'),
    ('Q: Why can the player reach 135 billion when canon caps at ~1.15 billion?',
     'A: The mod opens the PL ceiling for endgame progression. Canon ends at Kid Buu (1.15B '
     'in the game tie-ins) and Super introduces no scouters. Because the mod wants god-tiers '
     '(SSG, SSB, UI, UE, Black Frieza) to feel meaningfully stronger than the canon peaks, '
     'it allows the number to keep climbing — sometimes into the hundreds of billions via '
     'Super Shenron\'s &quot;Boundless Potential&quot; wish. These values are mod-original, not canon.'),
    ('Q: How do transformations interact — can you stack Kaio-ken on Super Saiyan Blue?',
     'A: Yes, mirroring the anime. The mod lets you stack Kaio-ken (a technique) on top of '
     'any form (a transformation), so Kaio-ken ×10 on Super Saiyan Blue multiplies your '
     'already-multiplied PL — exactly as Goku does against Hit in DBS. The cost is severe body '
     'damage and stamina drain, faithful to canon.'),
    ('Q: What exactly is &quot;god ki&quot; and why is it gated behind Shenron?',
     'A: In canon, god ki is a different quality of ki that mortals cannot sense; it is the '
     'defining trait of Gods of Destruction and their angels, and of the Super Saiyan God '
     'form. The mod gates it behind a Shenron wish (&quot;awaken my god ki&quot;) because in canon, '
     'Saiyans gained it only through the SSG ritual (six righteous Saiyans), not training. '
     'Once you hold the God Ki Awakening Crystal, Rosé and Golden Namekian — both god-ki '
     'forms — become accessible, replacing nothing but adding parallel branches.'),
    ('Q: How does the Gamma customization system work technically?',
     'A: It is an inventory item that opens a live-preview GUI. Eight appearance slots (helmet '
     'number, number color, suit color, boots, helmet, cape, fin count, fin style) are stored '
     'as NBT tags on the item. Pressing H opens the editor; clicking a number field cycles '
     'options in real time, re-rendering the player model. The settings persist across form '
     'changes and even survive powering down, and the renderer swaps your hand model in '
     'first-person too. Multiplayer sync sends the NBT to other clients so they see your '
     'configuration live.'),
    ('Q: Why does destroying a planet require you to be above its PL?',
     'A: It is the mod\'s implementation of the canon rule that you can only destroy something '
     'whose battle power you exceed. Frieza at 120M destroyed Planet Vegeta because Vegeta\'s '
     'PL (18,000) was vastly lower. The mod checks the charging player\'s effective PL against '
     'the planet\'s integrity PL; if you pass, the big bang attack resolves into a planet-destruction '
     'event that scatters debris blocks (which drop planet-native loot). If you fail, the '
     'attack fizzles — mirroring how weaker characters cannot destroy planets in canon.'),
    ('Q: How do black holes work, and why do they kill even 135B-PL characters?',
     'A: Black holes are a hazard, not an enemy — they have no PL to overpower. The mod '
     'implements them as a pull-field that drains ki and stamina faster the closer you get, '
     'and an event-horizon zone that is an instant-death trigger regardless of stats. This '
     'mirrors real physics (escape velocity exceeds light speed past the horizon) and gives '
     'deep space genuine danger even for endgame characters — a design choice to keep '
     'exploration tense.'),
    ('Q: How accurate are the canon Super Saiyan multipliers?',
     'A: Fully canon. Daizenshuu 7 (Shueisha, 1996) explicitly states SSJ = ×50 (p.44 and p.83), '
     'SSJ2 = ×2 over SSJ = ×100, and SSJ3 = ×4 over SSJ2 = ×400. The &quot;Super Daizenshuu&quot; '
     'supplement and V-Jump confirmed SSGSS (Blue) = ×50 over Super Saiyan God. SSG itself '
     'has no fixed multiplier in canon (it is a divine state, not a scalar boost), which is '
     'why the mod treats it as a state change rather than a flat multiplier.'),
    ('Q: How does the immortality wish avoid being game-breaking?',
     'A: The add-on implements three balances. First, HP still depletes normally — immortality '
     'blocks death, not damage. Second, once HP drops below a threshold, stamina and ki absorb '
     'the overflow, so you progressively lose the ability to fight back. Third, if both run '
     'out you enter a &quot;dazed&quot; stun state at 0% HP where you cannot move or act — you become '
     'a punching bag until you recover. This is precisely how the manga treats immortal '
     'characters like Future Zamasu: beaten into submission rather than killed.'),
    ('Q: How do races differ mechanically, not just visually?',
     'A: Saiyans get Zenkai (PL boost on near-death recovery) and the deepest transformation '
     'tree. Half-Saiyans (Gohan, Trunks, Goten archetypes) hybridize human stamina with '
     'Saiyan forms. Namekians get fusion, giant form, and regeneration. Arcosians get '
     'suppression forms (lower PL reads than their true power) plus Cooler\'s 5th form. Humans '
     'have the highest base stamina/ki and access to the Shioken line. Bio-Androids (Cell) '
     'gain power by absorbing entities. Androids get infinite ki but lose race skills. Each '
     'race is a genuinely different playstyle, not a reskin.'),
    ('Q: What is the relationship between Dragon Block C, DragonMine Z, and the add-ons?',
     'A: Dragon Block C (JinRyuu) is the original. DragonMine Z is a separate modern-codebase '
     'mod for newer Minecraft versions with the same design goals. The add-ons (&quot;No AR&quot;, '
     '&quot;Nowhere&quot;) are community-created content packs that require one of the base mods and '
     'extend it with god-forms, space, raid bosses, and the new races. They are not standalone '
     'mods — they hook into the base mod\'s race/form/ki systems and add new content on top.'),
    ('Q: Where does the &quot;Black Frieza&quot; form come from?',
     'A: It is manga-canon. Black Frieza debuts at the end of the Granolah arc (Dragon Ball '
     'Super manga chapter 88, 2022) — Frieza reveals he trained in a hyperbolic-time-style '
     'chamber for 10 years and achieved a black-colored final transformation that one-shot '
     'both Ultra Instinct Goku and Ultra Ego Vegeta simultaneously. The mod implements it as '
     'the current peak Frieza-race form, accessible on top of either Final or 5th form, '
     'making it the strongest Arcosian state in the game.'),
    ('Q: How does training with Beerus and Whis actually grant forms?',
     'A: In the add-on, Beerus and Whis are NPCs on Beerus\'s planet. Talking to them opens '
     'a purchase menu where you spend TP (or specific unlock items) to learn techniques and '
     'forms. Beerus teaches Hakai, Ultra Ego, and the god-form ladder; Whis teaches Ultra '
     'Instinct (both base and Mastered). This mirrors canon — Goku and Vegeta trained under '
     'Whis on Beerus\'s planet to approach god-tier. The mechanic is gated behind reaching '
     'Beerus\'s planet, which is currently unlocked from the start of the space pod but '
     'planned to require finding Beerus/Whis rarely on Earth.'),
    ('Q: Are the planet-sized Super Dragon Balls canon?',
     'A: Yes. In DBS, the Super Dragon Balls are the original Dragon Balls — planet-sized '
     'spheres scattered across Universes 6 and 7, each the size of a planet. They are '
     'searched for with the Super Dragon Ball Radar. The mod implements this faithfully: '
     'you fly through deep space with the radar in your off-hand, follow on-screen meters, '
     'and physically fly into the planet-sized orbs to collect them. Seven collected balls '
     'auto-summon the Super Shenron emblem for the three overpowered wishes.'),
]
for q, a in qa:
    story.append(KeepTogether([Paragraph(q, H3), Paragraph(a, BODY_S), Spacer(1, 4)]))

# ════════════════════════════════════════════════════════════════
# CHAPTER 7 — RESEARCH SOURCES
# ════════════════════════════════════════════════════════════════
story.append(h1('7. Research Sources & Methodology'))
story.append(p(
    'This guide was assembled by combining primary canon references with current community '
    'documentation of the mod ecosystem. The power-level tables are drawn from the canonical '
    'compilation maintained by Kanzenshuu and the Dragon Ball Wiki\'s &quot;List of Power Levels&quot; '
    'article, which cross-references the original V-Jump magazine spreads, Weekly Jump #31 '
    '(1991), Daizenshuu 7 (Shueisha 1996), the manga chapter readings, and the official video '
    'tie-ins <i>Scouter Battle Taikan Kamehameha</i> and <i>Dragon Ball Z: Kakarot</i>. Where the '
    'manga provides no number (everything post-Frieza), game-sourced values are used and '
    'explicitly flagged as such.'
))
story.append(p('Sources consulted:'))
src = [
    'Kanzenshuu Battle Power Guide — databook battle powers compilation (kanzenshuu.com/battle-powers)',
    'Dragon Ball Wiki — &quot;List of Power Levels&quot; (dragonball.fandom.com)',
    'Daizenshuu 7 (Shueisha, 1996) — official databook, pp. 44 & 83 for SSJ/SSJ2/SSJ3 multipliers',
    'V-Jump magazine — Super-era form multipliers (SSGSS = ×50 over SSG)',
    'Dragon Ball Super manga (Toytarou/Toriyama) — chapters 88+ for Black Frieza, Ultra Ego, UI scaling',
    'JinGames / CurseForge — Dragon Block C official feature list (main.jingames.net, curseforge.com)',
    'DragonBlockC Wiki (Fandom) — races, attributes, and forms documentation',
    'Modrinth — DragonMine Z mod page',
    'VS Battles Wiki & dbzeta.net community power-level threads — cross-reference for fan-compiled canon values',
    'Source video transcript — &quot;Dragon Block No AR&quot; add-on showcase by Troy (the basis of this analysis)',
    'Source video transcript — &quot;Dragon Block Nowhere v1&quot; update showcase (tournaments, aliens, raid bosses)',
]
for s in src:
    story.append(b(s))

story.append(Spacer(1, 10))
story.append(quote_block(
    'Disclaimer: Dragon Block C, DragonMine Z, and the add-ons discussed here are fan-made '
    'modifications unaffiliated with Toei Animation, Shueisha, or Akira Toriyama\'s estate. '
    'Dragon Ball, Dragon Ball Z, Dragon Ball Super, and all associated character names are '
    'trademarks of their respective owners. This guide is for educational and research purposes '
    'only. Power levels cited are canon where the source material provides them; everything '
    'past the Frieza saga is game-sourced or community-estimated and flagged as such.'
))

# ━━ Build ━━
doc = TocDocTemplate(
    OUTPUT, pagesize=A4,
    leftMargin=18*mm, rightMargin=18*mm,
    topMargin=20*mm, bottomMargin=18*mm,
    title='Dragon Block C — Deep Research Guide',
    author='Z.ai', creator='Z.ai', subject='Dragon Block C mod & Dragon Ball power-level research guide'
)

class CoverThenContent(TocDocTemplate):
    pass

# We want cover_bg only on page 1, page_bg on the rest
def first_page(canv, doc): cover_bg(canv, doc)
def later_pages(canv, doc): page_bg(canv, doc)

doc.multiBuild(story, onFirstPage=first_page, onLaterPages=later_pages)
print(f'PDF written: {OUTPUT}')
print(f'Size: {os.path.getsize(OUTPUT)/1024:.1f} KB')
