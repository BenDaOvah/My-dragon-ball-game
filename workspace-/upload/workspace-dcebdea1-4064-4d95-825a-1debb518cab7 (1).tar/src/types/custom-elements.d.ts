import type { DetailedHTMLProps, HTMLAttributes } from "react";

/**
 * Type declarations for the Neon Arcade Wix-style custom elements.
 * Each element renders inside Shadow DOM and exposes its attributes below.
 */
type CustomElement<
  T extends Record<string, unknown> = Record<string, unknown>
> = DetailedHTMLProps<HTMLAttributes<HTMLElement> & T, HTMLElement>;

declare module "react" {
  namespace JSX {
    interface IntrinsicElements {
      "arcade-marquee": CustomElement<{
        title?: string;
        subtitle?: string;
        blinky?: string;
      }>;
      "cabinet-card": CustomElement<{
        "game-title"?: string;
        "game-tag"?: string;
        "game-icon"?: string;
        "icon-color"?: string;
      }>;
      "block-stacker": CustomElement;
      "vector-volley": CustomElement;
      "brick-blaster": CustomElement;
      "circuit-snake": CustomElement;
      "pixel-runner": CustomElement;
      "galaxy-invaders": CustomElement;
      "dragon-power": CustomElement;
    }
  }
}
