import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Neon Arcade — Retro Custom Element Cabinets",
  description:
    "A retro/neon arcade built from Wix-style custom elements. Six hand-built games, CRT-glow marquees, and arcade-cabinet cards.",
  keywords: [
    "neon arcade",
    "retro games",
    "web components",
    "custom elements",
    "wix",
    "block stacker",
    "vector volley",
    "brick blaster",
    "circuit snake",
    "pixel runner",
    "galaxy invaders",
  ],
  authors: [{ name: "Neon Arcade" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Neon Arcade",
    description: "Six hand-built retro cabinets — all original engines, zero quarters required.",
    siteName: "Neon Arcade",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Neon Arcade",
    description: "Six hand-built retro cabinets — all original engines, zero quarters required.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Press Start 2P pixel font — used by every custom element by name (literal
            family name, required for Shadow DOM). next/font can't expose a stable
            literal name, so a Google Fonts stylesheet link is the correct host-page
            approach here; the custom element files themselves stay fully self-contained. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap"
          rel="stylesheet"
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
