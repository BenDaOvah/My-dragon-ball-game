"use client";

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

/* ------------------------------------------------------------------ */
/* Game registry — drives the cabinet grid, lightbox, and leaderboard */
/* ------------------------------------------------------------------ */
type GameDef = {
  tag: string;
  title: string;
  icon: string;
  color: string;
  blurb: string;
  controls: string;
  difficulty: "EASY" | "MED" | "HARD" | "INSANE";
};

const GAMES: GameDef[] = [
  {
    tag: "block-stacker",
    title: "Block Stacker",
    icon: "🟦",
    color: "#00fff2",
    blurb: "Falling-block stacking puzzle. Rotate, soft-drop, hard-drop, clear lines, chase the level-up.",
    controls: "← → move · ↑/W rotate · ↓ soft · SPACE hard-drop",
    difficulty: "MED",
  },
  {
    tag: "vector-volley",
    title: "Vector Volley",
    icon: "🏓",
    color: "#ff2d95",
    blurb: "Neon paddle duel vs a CPU that sharpens as you score. First to 11 takes the match.",
    controls: "↑/W & ↓/S · drag on screen",
    difficulty: "MED",
  },
  {
    tag: "brick-blaster",
    title: "Brick Blaster",
    icon: "🧱",
    color: "#f9f871",
    blurb: "Blast through six neon brick rows. Ball accelerates as the wall thins. Three lives.",
    controls: "← → / A D · SPACE launch",
    difficulty: "EASY",
  },
  {
    tag: "circuit-snake",
    title: "Circuit Snake",
    icon: "🐍",
    color: "#39ff14",
    blurb: "Trace the circuit, grow the conductor. Walls wrap — only your own tail can end you.",
    controls: "arrows / WASD · swipe",
    difficulty: "MED",
  },
  {
    tag: "pixel-runner",
    title: "Pixel Runner",
    icon: "🏃",
    color: "#00fff2",
    blurb: "Endless neon sprint. One button to jump, ever-accelerating obstacles. Don't crash.",
    controls: "SPACE / ↑ / W · tap",
    difficulty: "HARD",
  },
  {
    tag: "galaxy-invaders",
    title: "Galaxy Invaders",
    icon: "👾",
    color: "#b14dff",
    blurb: "Repel the descending alien swarm. They speed up as you thin them. Wave after wave.",
    controls: "← → / A D · SPACE fire",
    difficulty: "INSANE",
  },
  {
    tag: "dragon-power",
    title: "Dragon Power",
    icon: "🐉",
    color: "#ff8c2a",
    blurb: "Dragon Ball-inspired arena brawler. Canon-accurate power levels, destructible pixel terrain, form transformations, escalating bosses — Saibaman to Kid Buu.",
    controls: "A/D move · W/S fly · J ki · K charge · L transform · P punch",
    difficulty: "INSANE",
  },
];

const SCRIPTS = [
  "/custom-elements/arcade-marquee.js",
  "/custom-elements/cabinet-card.js",
  "/custom-elements/block-stacker.js",
  "/custom-elements/vector-volley.js",
  "/custom-elements/brick-blaster.js",
  "/custom-elements/circuit-snake.js",
  "/custom-elements/pixel-runner.js",
  "/custom-elements/galaxy-invaders.js",
  "/custom-elements/dragon-power.js",
];

const DIFFICULTY_COLOR: Record<GameDef["difficulty"], string> = {
  EASY: "#39ff14",
  MED: "#f9f871",
  HARD: "#ff8c2a",
  INSANE: "#ff2d95",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/* High-score store — read from localStorage via useSyncExternalStore  */
/* (the React-idiomatic way to sync external mutable state).           */
/* ------------------------------------------------------------------ */
function readHighScores(): Record<string, number> {
  const next: Record<string, number> = {};
  if (typeof window === "undefined") return next;
  GAMES.forEach((g) => {
    const raw = window.localStorage.getItem(`arcade-highscore-${g.tag}`);
    next[g.tag] = raw ? parseInt(raw, 10) || 0 : 0;
  });
  return next;
}

let hsCached: Record<string, number> = {};
let hsCacheKey = "";
const HS_SERVER_EMPTY: Record<string, number> = {};
function getHighScoreSnapshot(): Record<string, number> {
  const fresh = readHighScores();
  const key = Object.values(fresh).join("|");
  if (key !== hsCacheKey) {
    hsCached = fresh;
    hsCacheKey = key;
  }
  return hsCached;
}
function getHighScoreServerSnapshot(): Record<string, number> {
  return HS_SERVER_EMPTY;
}
function subscribeHighScores(cb: () => void): () => void {
  const onStorage = (e: StorageEvent) => {
    if (e.key && e.key.startsWith("arcade-highscore-")) cb();
  };
  const onGameOver = () => cb();
  window.addEventListener("storage", onStorage);
  document.addEventListener("game-over", onGameOver);
  return () => {
    window.removeEventListener("storage", onStorage);
    document.removeEventListener("game-over", onGameOver);
  };
}

type RecentRun = { game: string; score: number; at: number };

export default function Home() {
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [scores, setScores] = useState<RecentRun[]>([]);
  const highScores = useSyncExternalStore(
    subscribeHighScores,
    getHighScoreSnapshot,
    getHighScoreServerSnapshot
  );
  const lightboxRef = useRef<HTMLDivElement | null>(null);

  /* ---- Load every custom-element script once ---- */
  useEffect(() => {
    SCRIPTS.forEach((src) => {
      if (document.querySelector(`script[src="${src}"]`)) return;
      const el = document.createElement("script");
      el.src = src;
      el.async = true;
      document.body.appendChild(el);
    });
  }, []);

  /* ---- Cabinet selection -> open lightbox ---- */
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { gameTag?: string };
      if (detail?.gameTag && GAMES.some((g) => g.tag === detail.gameTag)) {
        setActiveGame(detail.gameTag);
      }
    };
    document.addEventListener("cabinet-selected", handler);
    return () => document.removeEventListener("cabinet-selected", handler);
  }, []);

  /* ---- game-over -> record recent run (high scores update via store) ---- */
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { game?: string; score?: number };
      if (detail?.game && typeof detail.score === "number") {
        setScores((prev) => [...prev.slice(-11), { game: detail.game!, score: detail.score!, at: Date.now() }]);
      }
    };
    document.addEventListener("game-over", handler);
    return () => document.removeEventListener("game-over", handler);
  }, []);

  /* ---- Escape closes lightbox ---- */
  useEffect(() => {
    if (!activeGame) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActiveGame(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeGame]);

  /* ---- Lock body scroll while lightbox open ---- */
  useEffect(() => {
    if (activeGame) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [activeGame]);

  const activeDef = useMemo(() => GAMES.find((g) => g.tag === activeGame) ?? null, [activeGame]);

  const totalHighScore = useMemo(
    () => Object.values(highScores).reduce((a, b) => a + b, 0),
    [highScores]
  );

  return (
    <div
      className="min-h-screen flex flex-col text-[#e8e8f0]"
      style={{ backgroundColor: "#0a0a12" }}
    >
      {/* CRT scanline overlay over the whole page */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-[60] opacity-[0.5]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(to bottom, rgba(255,255,255,0.035) 0px, rgba(255,255,255,0.035) 1px, transparent 1px, transparent 3px)",
          mixBlendMode: "overlay",
        }}
      />

      {/* ===== Header ===== */}
      <header
        className="sticky top-0 z-50 backdrop-blur"
        style={{
          backgroundColor: "rgba(10,10,18,0.78)",
          borderBottom: "1px solid rgba(0,255,242,0.25)",
          boxShadow: "0 0 18px rgba(0,255,242,0.12)",
        }}
      >
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span
              className="inline-flex h-9 w-9 items-center justify-center rounded-md text-lg"
              style={{
                border: "1px solid #ff2d95",
                boxShadow: "0 0 12px rgba(255,45,149,0.55)",
                color: "#ff2d95",
              }}
            >
              ▶
            </span>
            <span
              className="font-[family-name:var(--font-pixel)] text-[12px] sm:text-[14px] tracking-wider"
              style={{ color: "#00fff2", textShadow: "0 0 8px rgba(0,255,242,0.7)" }}
            >
              NEON&nbsp;ARCADE
            </span>
          </div>
          <nav className="hidden sm:flex items-center gap-5 text-[12px] text-[#9aa]">
            <a href="#cabinets" className="hover:text-[#00fff2] transition-colors">Cabinets</a>
            <a href="#leaderboard" className="hover:text-[#00fff2] transition-colors">Leaderboard</a>
            <a href="#how" className="hover:text-[#00fff2] transition-colors">How it works</a>
          </nav>
          <a
            href="/test.html"
            target="_blank"
            rel="noreferrer"
            className="text-[11px] font-[family-name:var(--font-pixel)] px-3 py-2 rounded-md transition-colors"
            style={{
              border: "1px solid #39ff14",
              color: "#39ff14",
              boxShadow: "0 0 10px rgba(57,255,20,0.3)",
            }}
          >
            TEST.HTML
          </a>
        </div>
      </header>

      {/* ===== Main ===== */}
      <main className="flex-1 mx-auto w-full max-w-6xl px-4 pt-8 pb-16 flex flex-col gap-14">
        {/* Hero marquee */}
        <section>
          <arcade-marquee
            title="NEON ARCADE"
            subtitle="Six hand-built retro cabinets · original engines · zero quarters required"
            blinky="★ INSERT COIN ★"
          />
        </section>

        {/* Stat strip */}
        <section
          className="grid grid-cols-2 md:grid-cols-4 gap-4"
          aria-label="Arcade at a glance"
        >
          <StatCard label="CABINETS" value={String(GAMES.length)} color="#00fff2" />
          <StatCard label="GENRES" value="6" color="#ff2d95" />
          <StatCard
            label="COMBINED BEST"
            value={String(totalHighScore)}
            color="#f9f871"
          />
          <StatCard label="QUARTERS" value="FREE" color="#39ff14" />
        </section>

        {/* Cabinet grid */}
        <section id="cabinets" className="scroll-mt-24">
          <SectionTitle accent="#00fff2">▸ SELECT A CABINET</SectionTitle>
          <p className="text-[13px] text-[#9aa] mt-1 mb-6 max-w-2xl">
            Tap any cabinet to boot it inside a CRT lightbox. Each machine keeps its own local high
            score and fires a <code className="text-[#39ff14]">game-over</code> event you can wire to
            a Wix Table via Velo.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {GAMES.map((g) => (
              <div key={g.tag} className="flex flex-col gap-3">
                <cabinet-card
                  game-title={g.title}
                  game-tag={g.tag}
                  game-icon={g.icon}
                  icon-color={g.color}
                />
                <div className="flex items-center justify-between px-1">
                  <Badge
                    variant="outline"
                    className="border-[1px] text-[9px] font-[family-name:var(--font-pixel)] px-2 py-1"
                    style={{
                      color: DIFFICULTY_COLOR[g.difficulty],
                      borderColor: DIFFICULTY_COLOR[g.difficulty],
                      boxShadow: `0 0 8px ${DIFFICULTY_COLOR[g.difficulty]}33`,
                    }}
                  >
                    {g.difficulty}
                  </Badge>
                  <span className="text-[10px] text-[#7a7a8c] font-[family-name:var(--font-pixel)]">
                    BEST&nbsp;
                    <span style={{ color: "#f9f871" }}>
                      {highScores[g.tag] ?? 0}
                    </span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section id="how" className="scroll-mt-24">
          <SectionTitle accent="#ff2d95">▸ HOW IT WORKS</SectionTitle>
          <div className="grid md:grid-cols-3 gap-5 mt-6">
            <InfoCard
              color="#00fff2"
              title="SHADOW DOM"
              body="Every cabinet is a self-contained Web Component. HTML, CSS, and canvas game logic live in one .js file under public/custom-elements/. Nothing leaks in or out."
            />
            <InfoCard
              color="#ff2d95"
              title="EVENT CONTRACT"
              body="On game end each machine dispatches a composed, bubbling game-over CustomEvent with detail { game, score } and persists its high score to localStorage."
            />
            <InfoCard
              color="#f9f871"
              title="WIX READY"
              body="Drop the files into Wix Dev Mode, register the tag as a Custom Element, and place the tag on a page. Wire a Velo table to the game-over event for a live leaderboard."
            />
          </div>
        </section>

        {/* Leaderboard preview */}
        <section id="leaderboard" className="scroll-mt-24">
          <SectionTitle accent="#39ff14">▸ LEADERBOARD</SectionTitle>
          <p className="text-[13px] text-[#9aa] mt-1 mb-6 max-w-2xl">
            Preview of local high scores. In production this becomes a native Wix Table fed by the
            <code className="text-[#39ff14]"> game-over</code> event through Velo.
          </p>
          <div
            className="rounded-xl overflow-hidden"
            style={{
              border: "1px solid rgba(57,255,20,0.3)",
              boxShadow: "0 0 18px rgba(57,255,20,0.12)",
            }}
          >
            {GAMES.map((g, i) => (
              <div
                key={g.tag}
                className="flex items-center justify-between px-4 py-3"
                style={{
                  backgroundColor: i % 2 === 0 ? "rgba(20,20,31,0.6)" : "rgba(10,10,18,0.6)",
                  borderBottom:
                    i < GAMES.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
                }}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="text-xl" aria-hidden>{g.icon}</span>
                  <span
                    className="font-[family-name:var(--font-pixel)] text-[11px] sm:text-[12px] truncate"
                    style={{ color: g.color }}
                  >
                    {g.title.toUpperCase()}
                  </span>
                </div>
                <span
                  className="font-[family-name:var(--font-pixel)] text-[12px] sm:text-[14px]"
                  style={{ color: "#f9f871", textShadow: "0 0 6px rgba(249,248,113,0.5)" }}
                >
                  {highScores[g.tag] ?? 0}
                </span>
              </div>
            ))}
          </div>

          {/* Recent session feed */}
          <div className="mt-8">
            <h3
              className="font-[family-name:var(--font-pixel)] text-[11px] mb-3"
              style={{ color: "#9aa" }}
            >
              ▸ RECENT RUNS (THIS SESSION)
            </h3>
            <div className="max-h-56 overflow-y-auto rounded-lg pr-1 [scrollbar-width:thin]">
              {scores.length === 0 ? (
                <p className="text-[13px] text-[#5a5a6c] py-4 text-center">
                  No runs yet — boot a cabinet and post a score.
                </p>
              ) : (
                [...scores].reverse().map((s, idx) => (
                  <div
                    key={`${s.at}-${idx}`}
                    className="flex items-center justify-between px-3 py-2 text-[12px] mb-1 rounded"
                    style={{
                      border: "1px solid rgba(0,255,242,0.12)",
                      backgroundColor: "rgba(20,20,31,0.4)",
                    }}
                  >
                    <span className="font-[family-name:var(--font-pixel)] text-[10px] text-[#00fff2]">
                      {s.game}
                    </span>
                    <span className="text-[#9aa]">
                      scored{" "}
                      <span style={{ color: "#f9f871" }}>{s.score}</span>
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </section>
      </main>

      {/* ===== Footer (sticky to bottom) ===== */}
      <footer
        className="mt-auto"
        style={{
          borderTop: "1px solid rgba(255,45,149,0.25)",
          boxShadow: "0 0 18px rgba(255,45,149,0.1)",
          backgroundColor: "rgba(10,10,18,0.6)",
        }}
      >
        <div className="mx-auto max-w-6xl px-4 py-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-[#7a7a8c] font-[family-name:var(--font-pixel)]">
            NEON ARCADE · BUILT WITH WEB COMPONENTS
          </p>
          <p className="text-[11px] text-[#5a5a6c]">
            Original engines · inspired-by classics · no trademarked assets
          </p>
        </div>
      </footer>

      {/* ===== Game lightbox ===== */}
      {activeGame && (
        <div
          ref={lightboxRef}
          role="dialog"
          aria-modal="true"
          aria-label={`Playing ${activeDef?.title ?? "game"}`}
          className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6"
          style={{ backgroundColor: "rgba(5,5,12,0.92)" }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setActiveGame(null);
          }}
        >
          <div
            className="w-full max-w-[680px] max-h-[94vh] overflow-y-auto rounded-xl"
            style={{
              border: "2px solid " + (activeDef?.color ?? "#00fff2"),
              boxShadow: `0 0 30px ${activeDef?.color ?? "#00fff2"}66`,
              backgroundColor: "#0a0a12",
            }}
          >
            {/* lightbox header */}
            <div
              className="flex items-center justify-between px-4 py-3"
              style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="text-xl" aria-hidden>{activeDef?.icon}</span>
                <div className="min-w-0">
                  <div
                    className="font-[family-name:var(--font-pixel)] text-[12px] truncate"
                    style={{ color: activeDef?.color }}
                  >
                    {activeDef?.title.toUpperCase()}
                  </div>
                  <div className="text-[10px] text-[#7a7a8c] truncate">
                    {activeDef?.controls}
                  </div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setActiveGame(null)}
                className="font-[family-name:var(--font-pixel)] text-[10px] h-8"
                style={{ borderColor: "#ff2d95", color: "#ff2d95" }}
              >
                ESC ✕
              </Button>
            </div>
            {/* game host */}
            <div className="p-3 sm:p-4">
              {/* The active game custom element. Rendered fresh on open so its
                  connectedCallback/disconnectedCallback manage the game loop. */}
              {activeGame === "block-stacker" && <block-stacker />}
              {activeGame === "vector-volley" && <vector-volley />}
              {activeGame === "brick-blaster" && <brick-blaster />}
              {activeGame === "circuit-snake" && <circuit-snake />}
              {activeGame === "pixel-runner" && <pixel-runner />}
              {activeGame === "galaxy-invaders" && <galaxy-invaders />}
              {activeGame === "dragon-power" && <dragon-power />}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Small presentational helpers                                        */
/* ------------------------------------------------------------------ */
function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div
      className="rounded-xl px-4 py-4 text-center"
      style={{
        backgroundColor: "rgba(20,20,31,0.7)",
        border: `1px solid ${color}44`,
        boxShadow: `0 0 14px ${color}22`,
      }}
    >
      <div className="font-[family-name:var(--font-pixel)] text-[8px] tracking-wider text-[#7a7a8c] mb-2">
        {label}
      </div>
      <div
        className="font-[family-name:var(--font-pixel)] text-[20px] sm:text-[24px]"
        style={{ color, textShadow: `0 0 10px ${color}66` }}
      >
        {value}
      </div>
    </div>
  );
}

function SectionTitle({ children, accent }: { children: React.ReactNode; accent: string }) {
  return (
    <h2
      className="font-[family-name:var(--font-pixel)] text-[14px] sm:text-[16px] tracking-wider"
      style={{ color: accent, textShadow: `0 0 8px ${accent}66` }}
    >
      {children}
    </h2>
  );
}

function InfoCard({ title, body, color }: { title: string; body: string; color: string }) {
  return (
    <div
      className="rounded-xl p-5"
      style={{
        backgroundColor: "rgba(20,20,31,0.7)",
        border: `1px solid ${color}44`,
        boxShadow: `0 0 14px ${color}1a`,
      }}
    >
      <h3
        className="font-[family-name:var(--font-pixel)] text-[11px] mb-3"
        style={{ color, textShadow: `0 0 8px ${color}55` }}
      >
        {title}
      </h3>
      <p className="text-[13px] leading-relaxed text-[#bcbcd0]">{body}</p>
    </div>
  );
}
