// Wix Custom Element — save as public/custom-elements/circuit-snake.js — tag: circuit-snake
// Wall collision rule: WRAP-AROUND — the snake passes through walls and reappears on the opposite side.
// Only self-collision ends the game.

(function () {
  const STYLE = `
    :host {
      display: block; width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body); color: #e8e8f0;
    }
    * { box-sizing: border-box; }
    .wrap {
      position: relative; background: var(--arcade-bg);
      border: 2px solid var(--arcade-neon-green); border-radius: 10px;
      box-shadow: 0 0 14px rgba(57,255,20,0.4), inset 0 0 30px rgba(57,255,20,0.05);
      padding: 14px; overflow: hidden;
    }
    .wrap::after {
      content: ""; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay; z-index: 5;
    }
    .head { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; gap:10px; }
    .title { font-family: var(--font-pixel); font-size:13px; letter-spacing:1px; color: var(--arcade-neon-green); text-shadow:0 0 8px rgba(57,255,20,0.8); }
    .hint { font-size:11px; color:#9aa; }
    .bar { display:flex; gap:10px; margin-bottom:10px; flex-wrap:wrap; }
    .stat { background: var(--arcade-panel); border:1px solid #2a2a3d; border-radius:6px; padding:6px 10px; flex:1; min-width:70px; }
    .stat .l { font-family: var(--font-pixel); font-size:8px; color:#7a7a8c; letter-spacing:.5px; }
    .stat .v { font-family: var(--font-pixel); font-size:14px; color: var(--arcade-neon-yellow); text-shadow:0 0 6px rgba(249,248,113,0.5); }
    .stat.best .v { color: var(--arcade-neon-cyan); text-shadow:0 0 6px rgba(0,255,242,0.5); }
    canvas { display:block; width:100%; height:auto; background:#05050c; border:2px solid #2a2a3d; border-radius:6px; image-rendering:pixelated; touch-action:none; }
    .touch { display:none; margin-top:12px; }
    .pad { display:grid; grid-template-columns:repeat(3,1fr); gap:6px; max-width:240px; margin:0 auto; }
    .tbtn {
      font-family: var(--font-pixel); font-size:12px; padding:16px 0;
      background: var(--arcade-panel); color: var(--arcade-neon-green);
      border:1px solid var(--arcade-neon-green); border-radius:6px;
      box-shadow:0 0 8px rgba(57,255,20,0.25); cursor:pointer; user-select:none; touch-action:manipulation;
    }
    .tbtn:active { background: rgba(57,255,20,0.15); }
    .tbtn.spacer { visibility:hidden; }
    .overlay { position:absolute; inset:0; display:none; align-items:center; justify-content:center; background:rgba(5,5,12,0.88); z-index:10; border-radius:10px; }
    .overlay.show { display:flex; }
    .ocard { text-align:center; padding:20px 24px; }
    .otitle { font-family: var(--font-pixel); font-size:18px; color: var(--arcade-neon-pink); text-shadow:0 0 12px rgba(255,45,149,0.9); margin-bottom:12px; }
    .oscore { font-family: var(--font-pixel); font-size:13px; color: var(--arcade-neon-yellow); text-shadow:0 0 8px rgba(249,248,113,0.7); margin-bottom:4px; }
    .ohs { font-size:11px; color:#9aa; margin-bottom:14px; }
    .obtn { font-family: var(--font-pixel); font-size:10px; padding:12px 18px; background:transparent; color: var(--arcade-neon-green); border:2px solid var(--arcade-neon-green); border-radius:6px; box-shadow:0 0 12px rgba(57,255,20,0.4); cursor:pointer; text-transform:uppercase; letter-spacing:1px; }
    .obtn:active { background: rgba(57,255,20,0.15); }
  `;

  const HS_KEY = 'arcade-highscore-circuit-snake';
  const COLS = 24, ROWS = 18;

  class CircuitSnake extends HTMLElement {
    constructor() { super(); this.attachShadow({ mode: 'open' }); }
    connectedCallback() {
      const root = this.shadowRoot;
      root.innerHTML = `
        <style>${STYLE}</style>
        <div class="wrap" id="wrap">
          <div class="head">
            <div class="title">CIRCUIT SNAKE</div>
            <div class="hint">arrows / WASD · walls wrap · don't hit yourself</div>
          </div>
          <div class="bar">
            <div class="stat"><div class="l">SCORE</div><div class="v" id="score">0</div></div>
            <div class="stat"><div class="l">LENGTH</div><div class="v" id="length">3</div></div>
            <div class="stat best"><div class="l">BEST</div><div class="v" id="best">0</div></div>
          </div>
          <canvas id="cv" width="528" height="396"></canvas>
          <div class="touch" id="touch">
            <div class="pad">
              <div class="tbtn spacer"></div>
              <button class="tbtn" data-dir="up">▲</button>
              <div class="tbtn spacer"></div>
              <button class="tbtn" data-dir="left">◀</button>
              <button class="tbtn" data-dir="down">▼</button>
              <button class="tbtn" data-dir="right">▶</button>
            </div>
          </div>
          <div class="overlay" id="overlay">
            <div class="ocard">
              <div class="otitle">GAME OVER</div>
              <div class="oscore" id="oscore">SCORE 0</div>
              <div class="ohs" id="ohs">BEST 0</div>
              <button class="obtn" id="restart">PLAY AGAIN</button>
            </div>
          </div>
        </div>
      `;
      this.cv = root.getElementById('cv');
      this.ctx = this.cv.getContext('2d');
      this.scoreEl = root.getElementById('score');
      this.lengthEl = root.getElementById('length');
      this.bestEl = root.getElementById('best');
      this.overlay = root.getElementById('overlay');
      this.oscore = root.getElementById('oscore');
      this.ohs = root.getElementById('ohs');
      this.touchWrap = root.getElementById('touch');

      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      if (isTouch) this.touchWrap.style.display = 'block';

      this.nextDir = null;
      this._onKey = (e) => this.onKey(e);
      this._onResize = () => this.resize();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);

      this._touchStart = null;
      this._onTS = (e) => { this._touchStart = { x: e.touches[0].clientX, y: e.touches[0].clientY }; };
      this._onTM = (e) => this.onTouchMove(e);
      this.cv.addEventListener('touchstart', this._onTS);
      this.cv.addEventListener('touchmove', this._onTM);
      this.touchWrap.addEventListener('click', (e) => {
        const btn = e.target.closest('.tbtn[data-dir]');
        if (!btn) return;
        this.setDir(btn.dataset.dir);
      });

      root.getElementById('restart').addEventListener('click', () => this.reset(true));

      this.highScore = this.loadHighScore();
      this.bestEl.textContent = this.highScore;
      this.reset();
      this.loop();
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      this.cv.removeEventListener('touchstart', this._onTS);
      this.cv.removeEventListener('touchmove', this._onTM);
      cancelAnimationFrame(this.raf);
    }
    resize() {
      const w = this.clientWidth || 528;
      const ratio = COLS / ROWS;
      let cw = w; let ch = cw / ratio;
      this.cv.width = cw; this.cv.height = ch;
      this.cell = cw / COLS;
    }
    loadHighScore() { try { return parseInt(localStorage.getItem(HS_KEY) || '0', 10) || 0; } catch (e) { return 0; } }
    saveHighScore(v) { try { localStorage.setItem(HS_KEY, String(v)); } catch (e) {} }

    reset(restart) {
      this.dir = { x: 1, y: 0 };
      this.nextDir = null;
      const cx = Math.floor(COLS / 2), cy = Math.floor(ROWS / 2);
      this.snake = [{ x: cx, y: cy }, { x: cx - 1, y: cy }, { x: cx - 2, y: cy }];
      this.placeFood();
      this.score = 0;
      this.over = false;
      this.tick = 0;
      this.lastStep = performance.now();
      this.updateHud();
      this.overlay.classList.remove('show');
      if (restart) this.loop();
    }
    placeFood() {
      let f;
      do {
        f = { x: Math.floor(Math.random() * COLS), y: Math.floor(Math.random() * ROWS) };
      } while (this.snake.some((s) => s.x === f.x && s.y === f.y));
      this.food = f;
    }
    stepSpeed() {
      const len = this.snake.length;
      // ms per step; speeds up as snake grows
      return Math.max(60, 140 - (len - 3) * 4);
    }
    onKey(e) {
      const k = e.key.toLowerCase();
      if (k === 'arrowup' || k === 'w') this.setDir('up');
      else if (k === 'arrowdown' || k === 's') this.setDir('down');
      else if (k === 'arrowleft' || k === 'a') this.setDir('left');
      else if (k === 'arrowright' || k === 'd') this.setDir('right');
      else return;
      e.preventDefault();
    }
    onTouchMove(e) {
      if (!this._touchStart) return;
      const dx = e.touches[0].clientX - this._touchStart.x;
      const dy = e.touches[0].clientY - this._touchStart.y;
      if (Math.abs(dx) < 16 && Math.abs(dy) < 16) return;
      if (Math.abs(dx) > Math.abs(dy)) this.setDir(dx > 0 ? 'right' : 'left');
      else this.setDir(dy > 0 ? 'down' : 'up');
      this._touchStart = null;
    }
    setDir(name) {
      const map = { up: { x: 0, y: -1 }, down: { x: 0, y: 1 }, left: { x: -1, y: 0 }, right: { x: 1, y: 0 } };
      const nd = map[name];
      if (!nd) return;
      // can't reverse directly
      if (nd.x === -this.dir.x && nd.y === -this.dir.y) return;
      this.nextDir = nd;
    }
    update(now) {
      if (this.over) return;
      if (now - this.lastStep < this.stepSpeed()) return;
      this.lastStep = now;
      if (this.nextDir) { this.dir = this.nextDir; this.nextDir = null; }
      const head = this.snake[0];
      let nx = head.x + this.dir.x;
      let ny = head.y + this.dir.y;
      // wrap around walls
      nx = (nx + COLS) % COLS;
      ny = (ny + ROWS) % ROWS;
      // self collision
      if (this.snake.some((s) => s.x === nx && s.y === ny)) {
        this.endGame();
        return;
      }
      this.snake.unshift({ x: nx, y: ny });
      if (nx === this.food.x && ny === this.food.y) {
        this.score = this.snake.length;
        this.placeFood();
        this.updateHud();
      } else {
        this.snake.pop();
      }
    }
    updateHud() {
      this.scoreEl.textContent = this.score;
      this.lengthEl.textContent = this.snake.length;
    }
    endGame() {
      this.over = true;
      cancelAnimationFrame(this.raf);
      const finalScore = this.snake.length;
      if (finalScore > this.highScore) { this.highScore = finalScore; this.saveHighScore(this.highScore); }
      this.bestEl.textContent = this.highScore;
      this.oscore.textContent = 'SCORE ' + finalScore;
      this.ohs.textContent = 'BEST ' + this.highScore;
      this.overlay.classList.add('show');
      this.dispatchEvent(new CustomEvent('game-over', {
        detail: { game: 'circuit-snake', score: finalScore },
        bubbles: true, composed: true
      }));
    }
    draw() {
      const ctx = this.ctx, cell = this.cell;
      ctx.fillStyle = '#05050c';
      ctx.fillRect(0, 0, this.cv.width, this.cv.height);
      // grid
      ctx.strokeStyle = 'rgba(57,255,20,0.06)';
      ctx.lineWidth = 1;
      for (let x = 0; x <= COLS; x++) { ctx.beginPath(); ctx.moveTo(x * cell, 0); ctx.lineTo(x * cell, ROWS * cell); ctx.stroke(); }
      for (let y = 0; y <= ROWS; y++) { ctx.beginPath(); ctx.moveTo(0, y * cell); ctx.lineTo(COLS * cell, y * cell); ctx.stroke(); }
      // food
      ctx.shadowColor = '#ff2d95'; ctx.shadowBlur = 14;
      ctx.fillStyle = '#ff2d95';
      const fx = this.food.x * cell, fy = this.food.y * cell;
      ctx.fillRect(fx + 2, fy + 2, cell - 4, cell - 4);
      ctx.shadowBlur = 0;
      // snake
      for (let i = this.snake.length - 1; i >= 0; i--) {
        const s = this.snake[i];
        const isHead = i === 0;
        ctx.shadowColor = '#39ff14'; ctx.shadowBlur = isHead ? 16 : 8;
        ctx.fillStyle = isHead ? '#9dff5e' : '#39ff14';
        ctx.fillRect(s.x * cell + 1, s.y * cell + 1, cell - 2, cell - 2);
      }
      ctx.shadowBlur = 0;
    }
    loop() {
      if (this.over) return;
      this.update(performance.now());
      this.draw();
      this.raf = requestAnimationFrame(() => this.loop());
    }
  }
  customElements.define('circuit-snake', CircuitSnake);
})();
