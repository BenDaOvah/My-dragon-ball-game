// Wix Custom Element — save as public/custom-elements/galaxy-invaders.js — tag: galaxy-invaders

(function () {
  const STYLE = `
    :host {
      display: block; width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --arcade-neon-purple: #b14dff;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body); color: #e8e8f0;
    }
    * { box-sizing: border-box; }
    .wrap {
      position: relative; background: var(--arcade-bg);
      border: 2px solid var(--arcade-neon-purple); border-radius: 10px;
      box-shadow: 0 0 14px rgba(177,77,255,0.5), inset 0 0 30px rgba(177,77,255,0.05);
      padding: 14px; overflow: hidden;
    }
    .wrap::after {
      content: ""; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay; z-index: 5;
    }
    .head { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; gap:10px; }
    .title { font-family: var(--font-pixel); font-size:13px; letter-spacing:1px; color: var(--arcade-neon-purple); text-shadow:0 0 8px rgba(177,77,255,0.9); }
    .hint { font-size:11px; color:#9aa; }
    .bar { display:flex; gap:10px; margin-bottom:10px; flex-wrap:wrap; }
    .stat { background: var(--arcade-panel); border:1px solid #2a2a3d; border-radius:6px; padding:6px 10px; flex:1; min-width:70px; }
    .stat .l { font-family: var(--font-pixel); font-size:8px; color:#7a7a8c; letter-spacing:.5px; }
    .stat .v { font-family: var(--font-pixel); font-size:14px; color: var(--arcade-neon-cyan); text-shadow:0 0 6px rgba(0,255,242,0.5); }
    .stat.best .v { color: var(--arcade-neon-green); text-shadow:0 0 6px rgba(57,255,20,0.5); }
    .stat.wave .v { color: var(--arcade-neon-yellow); text-shadow:0 0 6px rgba(249,248,113,0.5); }
    canvas { display:block; width:100%; height:auto; background:#05050c; border:2px solid #2a2a3d; border-radius:6px; image-rendering:pixelated; touch-action:none; }
    .touch { display:none; margin-top:12px; }
    .trow { display:flex; gap:8px; }
    .tbtn {
      font-family: var(--font-pixel); font-size:11px; padding:16px 0; flex:1;
      background: var(--arcade-panel); color: var(--arcade-neon-cyan);
      border:1px solid var(--arcade-neon-cyan); border-radius:6px;
      box-shadow:0 0 8px rgba(0,255,242,0.3); cursor:pointer; user-select:none; touch-action:manipulation;
    }
    .tbtn.fire { color: var(--arcade-neon-pink); border-color: var(--arcade-neon-pink); box-shadow:0 0 8px rgba(255,45,149,0.3); }
    .tbtn:active { background: rgba(0,255,242,0.18); }
    .tbtn.fire:active { background: rgba(255,45,149,0.15); }
    .overlay { position:absolute; inset:0; display:none; align-items:center; justify-content:center; background:rgba(5,5,12,0.88); z-index:10; border-radius:10px; }
    .overlay.show { display:flex; }
    .ocard { text-align:center; padding:20px 24px; }
    .otitle { font-family: var(--font-pixel); font-size:18px; margin-bottom:12px; }
    .otitle.win { color: var(--arcade-neon-green); text-shadow:0 0 12px rgba(57,255,20,0.9); }
    .otitle.lose { color: var(--arcade-neon-pink); text-shadow:0 0 12px rgba(255,45,149,0.9); }
    .oscore { font-family: var(--font-pixel); font-size:13px; color: var(--arcade-neon-yellow); text-shadow:0 0 8px rgba(249,248,113,0.7); margin-bottom:4px; }
    .ohs { font-size:11px; color:#9aa; margin-bottom:14px; }
    .obtn { font-family: var(--font-pixel); font-size:10px; padding:12px 18px; background:transparent; color: var(--arcade-neon-green); border:2px solid var(--arcade-neon-green); border-radius:6px; box-shadow:0 0 12px rgba(57,255,20,0.4); cursor:pointer; text-transform:uppercase; letter-spacing:1px; }
    .obtn:active { background: rgba(57,255,20,0.15); }
  `;

  const HS_KEY = 'arcade-highscore-galaxy-invaders';

  class GalaxyInvaders extends HTMLElement {
    constructor() { super(); this.attachShadow({ mode: 'open' }); }
    connectedCallback() {
      const root = this.shadowRoot;
      root.innerHTML = `
        <style>${STYLE}</style>
        <div class="wrap" id="wrap">
          <div class="head">
            <div class="title">GALAXY INVADERS</div>
            <div class="hint">← → / A D move · SPACE fire</div>
          </div>
          <div class="bar">
            <div class="stat"><div class="l">SCORE</div><div class="v" id="score">0</div></div>
            <div class="stat wave"><div class="l">WAVE</div><div class="v" id="wave">1</div></div>
            <div class="stat"><div class="l">LIVES</div><div class="v" id="lives">3</div></div>
            <div class="stat best"><div class="l">BEST</div><div class="v" id="best">0</div></div>
          </div>
          <canvas id="cv" width="560" height="420"></canvas>
          <div class="touch" id="touch">
            <div class="trow"><button class="tbtn" data-dir="left">◀</button><button class="tbtn fire" data-act="fire">FIRE</button><button class="tbtn" data-dir="right">▶</button></div>
          </div>
          <div class="overlay" id="overlay">
            <div class="ocard">
              <div class="otitle" id="otitle">GAME OVER</div>
              <div class="oscore" id="oscore">SCORE 0</div>
              <div class="ohs" id="ohs">BEST 0</div>
              <button class="obtn" id="restart">PLAY AGAIN</button>
            </div>
          </div>
        </div>
      `;
      this.cv = root.getElementById('cv');
      this.ctx = this.cv.getContext('2d');
      this.scoreEl = root.getElementById('score');
      this.waveEl = root.getElementById('wave');
      this.livesEl = root.getElementById('lives');
      this.bestEl = root.getElementById('best');
      this.overlay = root.getElementById('overlay');
      this.otitle = root.getElementById('otitle');
      this.oscore = root.getElementById('oscore');
      this.ohs = root.getElementById('ohs');
      this.touchWrap = root.getElementById('touch');

      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      if (isTouch) this.touchWrap.style.display = 'block';

      this.keys = { left: false, right: false, fire: false };
      this.fireHeld = false;
      this._onKey = (e) => this.onKey(e, true);
      this._onKeyUp = (e) => this.onKey(e, false);
      this._onResize = () => this.resize();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('keyup', this._onKeyUp);
      window.addEventListener('resize', this._onResize);

      this.touchWrap.addEventListener('pointerdown', (e) => {
        const btn = e.target.closest('.tbtn');
        if (!btn) return;
        if (btn.dataset.dir === 'left') this.touchDir = -1;
        else if (btn.dataset.dir === 'right') this.touchDir = 1;
        else if (btn.dataset.act === 'fire') this.touchFire = true;
      });
      this.touchWrap.addEventListener('pointerup', () => { this.touchDir = 0; this.touchFire = false; });
      this.touchWrap.addEventListener('pointerleave', () => { this.touchDir = 0; this.touchFire = false; });

      root.getElementById('restart').addEventListener('click', () => this.reset(true));

      this.highScore = this.loadHighScore();
      this.bestEl.textContent = this.highScore;
      this.reset();
      this.loop();
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('keyup', this._onKeyUp);
      window.removeEventListener('resize', this._onResize);
      cancelAnimationFrame(this.raf);
    }
    resize() {
      const w = this.clientWidth || 560;
      const ratio = 560 / 420;
      this.cv.width = w; this.cv.height = w / ratio;
      this.scale = this.cv.width / 560;
    }
    loadHighScore() { try { return parseInt(localStorage.getItem(HS_KEY) || '0', 10) || 0; } catch (e) { return 0; } }
    saveHighScore(v) { try { localStorage.setItem(HS_KEY, String(v)); } catch (e) {} }

    reset(restart) {
      this.W = 560; this.H = 420;
      this.playerW = 36; this.playerH = 18;
      this.playerX = (this.W - this.playerW) / 2;
      this.playerY = this.H - 40;
      this.bullets = [];
      this.enemyBullets = [];
      this.particles = [];
      this.stars = [];
      for (let i = 0; i < 50; i++) this.stars.push({ x: Math.random() * this.W, y: Math.random() * this.H, s: Math.random() * 1.5 + 0.3, sp: Math.random() * 0.4 + 0.1 });
      this.score = 0; this.lives = 3; this.wave = 1; this.over = false;
      this.touchDir = 0; this.touchFire = false;
      this.fireCooldown = 0;
      this.buildWave();
      this.updateHud();
      this.overlay.classList.remove('show');
      if (restart) this.loop();
    }
    buildWave() {
      this.invaders = [];
      const cols = 9, rows = 5;
      const startX = 40, startY = 50;
      const stepX = 44, stepY = 34;
      const colors = ['#ff2d95', '#b14dff', '#00fff2', '#39ff14', '#f9f871'];
      const points = [40, 30, 20, 15, 10];
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          this.invaders.push({
            x: startX + c * stepX, y: startY + r * stepY, w: 26, h: 18,
            color: colors[r], points: points[r], alive: true, type: r
          });
        }
      }
      this.invDir = 1;
      this.invSpeed = 0.3 + (this.wave - 1) * 0.2;
      this.invDrop = 16;
      this.invShootTimer = 90;
    }
    updateHud() {
      this.scoreEl.textContent = this.score;
      this.waveEl.textContent = this.wave;
      this.livesEl.textContent = this.lives;
    }
    onKey(e, down) {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') { this.keys.left = down; e.preventDefault(); }
      else if (k === 'arrowright' || k === 'd') { this.keys.right = down; e.preventDefault(); }
      else if (k === ' ') { this.keys.fire = down; e.preventDefault(); }
    }
    fire() {
      if (this.over) return;
      if (this.fireCooldown > 0) return;
      this.fireCooldown = 18;
      this.bullets.push({ x: this.playerX + this.playerW / 2, y: this.playerY - 4, vy: -8 });
    }
    update() {
      if (this.over) return;
      // stars
      for (const st of this.stars) { st.y += st.sp; if (st.y > this.H) { st.y = 0; st.x = Math.random() * this.W; } }
      // player
      const ps = 4.5;
      if (this.keys.left || this.touchDir === -1) this.playerX -= ps;
      if (this.keys.right || this.touchDir === 1) this.playerX += ps;
      this.playerX = Math.max(8, Math.min(this.W - this.playerW - 8, this.playerX));
      if (this.keys.fire || this.touchFire) this.fire();
      if (this.fireCooldown > 0) this.fireCooldown--;

      // bullets
      for (const b of this.bullets) b.y += b.vy;
      this.bullets = this.bullets.filter((b) => b.y > -10);
      for (const b of this.enemyBullets) b.y += b.vy;
      this.enemyBullets = this.enemyBullets.filter((b) => b.y < this.H + 10);

      // invaders movement (classic side-step, drop on edge)
      const alive = this.invaders.filter((i) => i.alive);
      if (alive.length === 0) {
        // wave cleared
        this.wave++;
        this.buildWave();
        this.updateHud();
        return;
      }
      let hitEdge = false;
      for (const inv of alive) {
        inv.x += this.invDir * this.invSpeed;
        if (inv.x <= 8 || inv.x + inv.w >= this.W - 8) hitEdge = true;
      }
      if (hitEdge) {
        this.invDir *= -1;
        for (const inv of alive) inv.y += this.invDrop;
        // check if reached player level
        for (const inv of alive) {
          if (inv.y + inv.h >= this.playerY) { this.endGame(false); return; }
        }
      }
      // invaders shoot
      this.invShootTimer--;
      if (this.invShootTimer <= 0) {
        // pick bottom-most invader in a random column
        const cols = {};
        for (const inv of alive) {
          const col = Math.round(inv.x / 44);
          if (!cols[col] || inv.y > cols[col].y) cols[col] = inv;
        }
        const shooters = Object.values(cols);
        if (shooters.length) {
          const s = shooters[Math.floor(Math.random() * shooters.length)];
          this.enemyBullets.push({ x: s.x + s.w / 2, y: s.y + s.h, vy: 3.2 + this.wave * 0.3 });
        }
        this.invShootTimer = Math.max(28, 90 - this.wave * 8 - (50 - alive.length));
      }

      // bullet vs invader
      for (const b of this.bullets) {
        for (const inv of this.invaders) {
          if (!inv.alive) continue;
          if (b.x > inv.x && b.x < inv.x + inv.w && b.y > inv.y && b.y < inv.y + inv.h) {
            inv.alive = false;
            b.y = -100;
            this.score += inv.points;
            this.spawnExplosion(inv.x + inv.w / 2, inv.y + inv.h / 2, inv.color);
            // speed up as fewer remain
            this.invSpeed = (0.3 + (this.wave - 1) * 0.2) * (1 + (45 - alive.length) * 0.04);
            this.updateHud();
            break;
          }
        }
      }
      this.bullets = this.bullets.filter((b) => b.y > -10);

      // enemy bullet vs player
      for (const b of this.enemyBullets) {
        if (b.x > this.playerX && b.x < this.playerX + this.playerW && b.y > this.playerY && b.y < this.playerY + this.playerH) {
          b.y = this.H + 100;
          this.lives--;
          this.spawnExplosion(this.playerX + this.playerW / 2, this.playerY + this.playerH / 2, '#00fff2');
          this.updateHud();
          if (this.lives <= 0) { this.endGame(false); return; }
        }
      }
      this.enemyBullets = this.enemyBullets.filter((b) => b.y < this.H + 10);

      // particles
      for (const p of this.particles) { p.x += p.vx; p.y += p.vy; p.life--; }
      this.particles = this.particles.filter((p) => p.life > 0);
    }
    spawnExplosion(x, y, color) {
      for (let i = 0; i < 10; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = Math.random() * 2.5 + 0.5;
        this.particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 22, color });
      }
    }
    endGame(won) {
      this.over = true;
      cancelAnimationFrame(this.raf);
      if (this.score > this.highScore) { this.highScore = this.score; this.saveHighScore(this.highScore); }
      this.bestEl.textContent = this.highScore;
      this.otitle.textContent = won ? 'VICTORY' : 'GAME OVER';
      this.otitle.className = 'otitle ' + (won ? 'win' : 'lose');
      this.oscore.textContent = 'SCORE ' + this.score;
      this.ohs.textContent = 'BEST ' + this.highScore;
      this.overlay.classList.add('show');
      this.dispatchEvent(new CustomEvent('game-over', {
        detail: { game: 'galaxy-invaders', score: this.score },
        bubbles: true, composed: true
      }));
    }
    draw() {
      const ctx = this.ctx, s = this.scale || 1;
      ctx.fillStyle = '#05050c';
      ctx.fillRect(0, 0, this.cv.width, this.cv.height);
      ctx.save();
      ctx.scale(s, s);
      // stars
      for (const st of this.stars) {
        ctx.fillStyle = `rgba(255,255,255,${st.s * 0.4})`;
        ctx.fillRect(st.x, st.y, st.s, st.s);
      }
      // invaders
      for (const inv of this.invaders) {
        if (!inv.alive) continue;
        ctx.shadowColor = inv.color; ctx.shadowBlur = 8;
        ctx.fillStyle = inv.color;
        // pixel-ish invader shape
        const u = 3;
        const cx = inv.x, cy = inv.y;
        const patterns = [
          [ "  XXXX  ", " XXXXXX ", "XX XX XX", "XXXXXXXX", " X XX X ", "X X  X X" ],
          [ "  X  X  ", "   XX   ", " XXXXXX ", "XXXXXXXX", "X XXXX X", "X X  X X" ],
          [ " XXXXXX ", "X      X", "X XX XX ", "XXXXXXXX", " XX  XX ", "X X  X X" ]
        ];
        const pat = patterns[inv.type % patterns.length];
        for (let r = 0; r < pat.length; r++) {
          for (let c = 0; c < pat[r].length; c++) {
            if (pat[r][c] === 'X') ctx.fillRect(cx + c * u, cy + r * u, u, u);
          }
        }
      }
      ctx.shadowBlur = 0;
      // player bullets
      ctx.shadowColor = '#39ff14'; ctx.shadowBlur = 8;
      ctx.fillStyle = '#39ff14';
      for (const b of this.bullets) ctx.fillRect(b.x - 1, b.y, 3, 10);
      ctx.shadowColor = '#ff2d95';
      ctx.fillStyle = '#ff2d95';
      for (const b of this.enemyBullets) ctx.fillRect(b.x - 1, b.y, 3, 8);
      ctx.shadowBlur = 0;
      // player ship
      ctx.shadowColor = '#00fff2'; ctx.shadowBlur = 12;
      ctx.fillStyle = '#00fff2';
      const px = this.playerX, py = this.playerY;
      ctx.fillRect(px + 12, py, 12, 6);
      ctx.fillRect(px + 6, py + 6, 24, 6);
      ctx.fillRect(px, py + 12, 36, 6);
      ctx.shadowBlur = 0;
      // particles
      for (const p of this.particles) {
        ctx.globalAlpha = p.life / 22;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, 3, 3);
      }
      ctx.globalAlpha = 1;
      ctx.restore();
    }
    loop() {
      if (this.over) return;
      this.update(); this.draw();
      this.raf = requestAnimationFrame(() => this.loop());
    }
  }
  customElements.define('galaxy-invaders', GalaxyInvaders);
})();
