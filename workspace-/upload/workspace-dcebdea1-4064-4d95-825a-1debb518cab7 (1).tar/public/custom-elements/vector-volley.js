// Wix Custom Element — save as public/custom-elements/vector-volley.js — tag: vector-volley

(function () {
  const STYLE = `
    :host {
      display: block;
      width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body);
      color: #e8e8f0;
    }
    * { box-sizing: border-box; }
    .wrap {
      position: relative;
      background: var(--arcade-bg);
      border: 2px solid var(--arcade-neon-pink);
      border-radius: 10px;
      box-shadow: 0 0 14px rgba(255,45,149,0.5), inset 0 0 30px rgba(255,45,149,0.05);
      padding: 14px;
      overflow: hidden;
    }
    .wrap::after {
      content: ""; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay; z-index: 5;
    }
    .head { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; gap:10px; }
    .title { font-family: var(--font-pixel); font-size:13px; letter-spacing:1px; color: var(--arcade-neon-cyan); text-shadow:0 0 8px rgba(0,255,242,0.8); }
    .hint { font-size:11px; color:#9aa; }
    .scorebar {
      display:flex; align-items:center; justify-content:center; gap:24px;
      margin-bottom:10px;
    }
    .sb { text-align:center; }
    .sb .lbl { font-family: var(--font-pixel); font-size:8px; color:#7a7a8c; margin-bottom:4px; letter-spacing:.5px; }
    .sb .val { font-family: var(--font-pixel); font-size:22px; }
    .sb.p .val { color: var(--arcade-neon-cyan); text-shadow:0 0 10px rgba(0,255,242,0.7); }
    .sb.c .val { color: var(--arcade-neon-pink); text-shadow:0 0 10px rgba(255,45,149,0.7); }
    canvas {
      display:block; width:100%; height:auto; background:#05050c; border:2px solid #2a2a3d; border-radius:6px; image-rendering:pixelated; touch-action:none;
    }
    .touch { display:none; margin-top:12px; }
    .tbtn {
      font-family: var(--font-pixel); font-size:11px; padding:14px 0; width:100%;
      background: var(--arcade-panel); color: var(--arcade-neon-cyan);
      border:1px solid var(--arcade-neon-cyan); border-radius:6px;
      box-shadow:0 0 8px rgba(0,255,242,0.3); cursor:pointer; user-select:none; touch-action:manipulation;
    }
    .tbtn:active { background: rgba(0,255,242,0.18); }
    .overlay {
      position:absolute; inset:0; display:none; align-items:center; justify-content:center;
      background:rgba(5,5,12,0.86); z-index:10; border-radius:10px;
    }
    .overlay.show { display:flex; }
    .ocard { text-align:center; padding:20px 24px; }
    .otitle { font-family: var(--font-pixel); font-size:18px; margin-bottom:12px; }
    .otitle.win { color: var(--arcade-neon-green); text-shadow:0 0 12px rgba(57,255,20,0.9); }
    .otitle.lose { color: var(--arcade-neon-pink); text-shadow:0 0 12px rgba(255,45,149,0.9); }
    .oscore { font-family: var(--font-pixel); font-size:13px; color: var(--arcade-neon-yellow); text-shadow:0 0 8px rgba(249,248,113,0.7); margin-bottom:14px; }
    .obtn {
      font-family: var(--font-pixel); font-size:10px; padding:12px 18px;
      background:transparent; color: var(--arcade-neon-green); border:2px solid var(--arcade-neon-green);
      border-radius:6px; box-shadow:0 0 12px rgba(57,255,20,0.4); cursor:pointer; text-transform:uppercase; letter-spacing:1px;
    }
    .obtn:active { background: rgba(57,255,20,0.15); }
  `;

  const HS_KEY = 'arcade-highscore-vector-volley';
  const WIN_SCORE = 11;

  class VectorVolley extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
      const root = this.shadowRoot;
      root.innerHTML = `
        <style>${STYLE}</style>
        <div class="wrap" id="wrap">
          <div class="head">
            <div class="title">VECTOR VOLLEY</div>
            <div class="hint">↑/W & ↓/S · drag on screen · first to ${WIN_SCORE}</div>
          </div>
          <div class="scorebar">
            <div class="sb p"><div class="lbl">PLAYER</div><div class="val" id="pscore">0</div></div>
            <div class="sb"><div class="lbl">VS</div><div class="val" style="color:#5a5a6c">—</div></div>
            <div class="sb c"><div class="lbl">CPU</div><div class="val" id="cscore">0</div></div>
          </div>
          <canvas id="cv" width="640" height="360"></canvas>
          <div class="touch" id="touch">
            <button class="tbtn" data-dir="up">▲ MOVE UP</button>
            <button class="tbtn" data-dir="down" style="margin-top:6px;">▼ MOVE DOWN</button>
          </div>
          <div class="overlay" id="overlay">
            <div class="ocard">
              <div class="otitle" id="otitle">YOU WIN</div>
              <div class="oscore" id="oscore">11 — 0</div>
              <button class="obtn" id="restart">PLAY AGAIN</button>
            </div>
          </div>
        </div>
      `;
      this.cv = root.getElementById('cv');
      this.ctx = this.cv.getContext('2d');
      this.pscoreEl = root.getElementById('pscore');
      this.cscoreEl = root.getElementById('cscore');
      this.overlay = root.getElementById('overlay');
      this.otitle = root.getElementById('otitle');
      this.oscore = root.getElementById('oscore');
      this.touchWrap = root.getElementById('touch');

      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      if (isTouch) this.touchWrap.style.display = 'block';

      this.keys = { up: false, down: false };
      this._onKey = (e) => this.onKey(e, true);
      this._onKeyUp = (e) => this.onKey(e, false);
      this._onResize = () => this.resize();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('keyup', this._onKeyUp);
      window.addEventListener('resize', this._onResize);

      // pointer drag on canvas
      this._onPointer = (e) => this.onPointer(e);
      this.cv.addEventListener('pointerdown', this._onPointer);
      this.cv.addEventListener('pointermove', this._onPointer);

      root.getElementById('restart').addEventListener('click', () => this.reset(true));
      this.touchWrap.addEventListener('pointerdown', (e) => {
        const btn = e.target.closest('.tbtn');
        if (!btn) return;
        const dir = btn.dataset.dir;
        this.touchDir = dir === 'up' ? -1 : 1;
      });
      this.touchWrap.addEventListener('pointerup', () => { this.touchDir = 0; });
      this.touchWrap.addEventListener('pointerleave', () => { this.touchDir = 0; });

      this.highScore = this.loadHighScore();
      this.reset();
      this.loop();
    }

    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('keyup', this._onKeyUp);
      window.removeEventListener('resize', this._onResize);
      this.cv.removeEventListener('pointerdown', this._onPointer);
      this.cv.removeEventListener('pointermove', this._onPointer);
      cancelAnimationFrame(this.raf);
    }

    resize() {
      const w = this.clientWidth || 640;
      const ratio = 640 / 360;
      let cw = w;
      let ch = cw / ratio;
      this.cv.width = cw;
      this.cv.height = ch;
      this.scale = cw / 640; // logical units scale
    }

    loadHighScore() {
      try { return parseInt(localStorage.getItem(HS_KEY) || '0', 10) || 0; } catch (e) { return 0; }
    }
    saveHighScore(v) { try { localStorage.setItem(HS_KEY, String(v)); } catch (e) {} }

    reset(restart) {
      this.W = 640; this.H = 360;
      this.paddleW = 12; this.paddleH = 70;
      this.ballR = 8;
      this.playerY = (this.H - this.paddleH) / 2;
      this.cpuY = (this.H - this.paddleH) / 2;
      this.pScore = 0; this.cScore = 0;
      this.over = false;
      this.touchDir = 0;
      this.resetBall(Math.random() < 0.5 ? -1 : 1);
      this.updateScore();
      this.overlay.classList.remove('show');
      if (restart) this.loop();
    }

    resetBall(dir) {
      this.ballX = this.W / 2;
      this.ballY = this.H / 2;
      const speed = 5;
      const angle = (Math.random() * 0.6 - 0.3); // small vertical angle
      this.vx = dir * speed;
      this.vy = speed * angle;
      this.serveDelay = 60; // frames before ball moves
    }

    updateScore() {
      this.pscoreEl.textContent = this.pScore;
      this.cscoreEl.textContent = this.cScore;
    }

    onKey(e, down) {
      const k = e.key.toLowerCase();
      if (k === 'arrowup' || k === 'w') { this.keys.up = down; e.preventDefault(); }
      else if (k === 'arrowdown' || k === 's') { this.keys.down = down; e.preventDefault(); }
    }

    onPointer(e) {
      const rect = this.cv.getBoundingClientRect();
      const y = (e.clientY - rect.top) / rect.height * this.H;
      this.playerY = Math.max(0, Math.min(this.H - this.paddleH, y - this.paddleH / 2));
    }

    cpuSpeed() {
      // difficulty scales with player score
      return 3.2 + this.pScore * 0.35;
    }

    update() {
      if (this.over) return;
      // player movement
      const ps = 6;
      if (this.keys.up || this.touchDir === -1) this.playerY -= ps;
      if (this.keys.down || this.touchDir === 1) this.playerY += ps;
      this.playerY = Math.max(0, Math.min(this.H - this.paddleH, this.playerY));

      // CPU AI: track ball when moving toward it, with reaction error scaling difficulty
      const cpuCenter = this.cpuY + this.paddleH / 2;
      const target = this.ballY;
      const err = Math.max(8, 60 - this.pScore * 4);
      const noisyTarget = target + (Math.sin(performance.now() / 500) * err);
      const diff = noisyTarget - cpuCenter;
      const sp = this.cpuSpeed();
      if (Math.abs(diff) > 4) {
        this.cpuY += Math.sign(diff) * Math.min(sp, Math.abs(diff));
      }
      this.cpuY = Math.max(0, Math.min(this.H - this.paddleH, this.cpuY));

      // ball
      if (this.serveDelay > 0) {
        this.serveDelay--;
      } else {
        this.ballX += this.vx;
        this.ballY += this.vy;
      }

      // top/bottom walls
      if (this.ballY < this.ballR) { this.ballY = this.ballR; this.vy *= -1; }
      if (this.ballY > this.H - this.ballR) { this.ballY = this.H - this.ballR; this.vy *= -1; }

      // paddle collisions
      const playerX = 20;
      const cpuX = this.W - 20 - this.paddleW;
      if (this.vx < 0 && this.ballX - this.ballR < playerX + this.paddleW &&
          this.ballX - this.ballR > playerX - 4 &&
          this.ballY > this.playerY && this.ballY < this.playerY + this.paddleH) {
        this.bouncePaddle(this.playerY, 1);
      }
      if (this.vx > 0 && this.ballX + this.ballR > cpuX &&
          this.ballX + this.ballR < cpuX + this.paddleW + 4 &&
          this.ballY > this.cpuY && this.ballY < this.cpuY + this.paddleH) {
        this.bouncePaddle(this.cpuY, -1);
      }

      // scoring
      if (this.ballX < -this.ballR) {
        this.cScore++;
        this.updateScore();
        if (this.cScore >= WIN_SCORE) this.endGame(false);
        else this.resetBall(-1);
      } else if (this.ballX > this.W + this.ballR) {
        this.pScore++;
        this.updateScore();
        if (this.pScore >= WIN_SCORE) this.endGame(true);
        else this.resetBall(1);
      }
    }

    bouncePaddle(paddleY, dir) {
      // dir = +1 means player hit (ball going right), -1 means cpu hit
      const rel = (this.ballY - (paddleY + this.paddleH / 2)) / (this.paddleH / 2);
      const maxAngle = Math.PI / 3.2;
      const angle = rel * maxAngle;
      const speed = Math.min(13, Math.hypot(this.vx, this.vy) * 1.06);
      this.vx = dir * speed * Math.cos(angle);
      this.vy = speed * Math.sin(angle);
      // ensure ball not stuck inside paddle
      this.ballX = dir > 0 ? 20 + this.paddleW + this.ballR + 1 : this.W - 20 - this.paddleW - this.ballR - 1;
    }

    endGame(playerWon) {
      this.over = true;
      cancelAnimationFrame(this.raf);
      if (this.pScore > this.highScore) {
        this.highScore = this.pScore;
        this.saveHighScore(this.highScore);
      }
      this.otitle.textContent = playerWon ? 'YOU WIN' : 'CPU WINS';
      this.otitle.className = 'otitle ' + (playerWon ? 'win' : 'lose');
      this.oscore.textContent = this.pScore + ' — ' + this.cScore;
      this.overlay.classList.add('show');
      this.dispatchEvent(new CustomEvent('game-over', {
        detail: { game: 'vector-volley', score: this.pScore },
        bubbles: true, composed: true
      }));
    }

    draw() {
      const ctx = this.ctx;
      const s = this.scale || 1;
      ctx.fillStyle = '#05050c';
      ctx.fillRect(0, 0, this.cv.width, this.cv.height);
      ctx.save();
      ctx.scale(s, s);
      // center dashed line
      ctx.strokeStyle = 'rgba(0,255,242,0.3)';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 10]);
      ctx.beginPath();
      ctx.moveTo(this.W / 2, 0);
      ctx.lineTo(this.W / 2, this.H);
      ctx.stroke();
      ctx.setLineDash([]);

      // paddles
      this.drawGlowRect(20, this.playerY, this.paddleW, this.paddleH, '#00fff2');
      this.drawGlowRect(this.W - 20 - this.paddleW, this.cpuY, this.paddleW, this.paddleH, '#ff2d95');

      // ball
      ctx.shadowColor = '#f9f871';
      ctx.shadowBlur = 16;
      ctx.fillStyle = '#f9f871';
      ctx.beginPath();
      ctx.arc(this.ballX, this.ballY, this.ballR, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // serve countdown
      if (this.serveDelay > 0 && !this.over) {
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.font = "10px 'Press Start 2P', monospace";
        ctx.textAlign = 'center';
        ctx.fillText('READY', this.W / 2, this.H / 2 - 20);
      }
      ctx.restore();
    }

    drawGlowRect(x, y, w, h, color) {
      const ctx = this.ctx;
      ctx.shadowColor = color;
      ctx.shadowBlur = 16;
      ctx.fillStyle = color;
      ctx.fillRect(x, y, w, h);
      ctx.shadowBlur = 0;
      ctx.fillStyle = 'rgba(255,255,255,0.25)';
      ctx.fillRect(x, y, w, 3);
    }

    loop() {
      if (this.over) return;
      this.update();
      this.draw();
      this.raf = requestAnimationFrame(() => this.loop());
    }
  }

  customElements.define('vector-volley', VectorVolley);
})();
