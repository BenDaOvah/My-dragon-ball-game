// Wix Custom Element — save as public/custom-elements/arcade-marquee.js — tag: arcade-marquee

(function () {
  const STYLE = `
    :host {
      display: block; width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body);
    }
    .marquee {
      position: relative;
      width: 100%;
      min-height: 280px;
      background: radial-gradient(circle at 50% 40%, rgba(177,77,255,0.12), var(--arcade-bg) 70%);
      border: 2px solid var(--arcade-neon-pink);
      border-radius: 14px;
      box-shadow: 0 0 24px rgba(255,45,149,0.45), inset 0 0 50px rgba(255,45,149,0.06);
      padding: 38px 22px;
      text-align: center;
      overflow: hidden;
      box-sizing: border-box;
    }
    .marquee::before {
      content: ""; position: absolute; inset: 0; pointer-events: none; z-index: 3;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.05) 0px, rgba(255,255,255,0.05) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay;
    }
    .marquee::after {
      content: ""; position: absolute; inset: 0; pointer-events: none; z-index: 2;
      background: radial-gradient(circle at 50% 50%, transparent 55%, rgba(0,0,0,0.55) 100%);
    }
    .title {
      position: relative; z-index: 4;
      font-family: var(--font-pixel);
      font-size: clamp(22px, 6vw, 54px);
      line-height: 1.25;
      letter-spacing: 2px;
      color: var(--arcade-neon-cyan);
      text-shadow:
        0 0 6px rgba(0,255,242,0.9),
        0 0 18px rgba(0,255,242,0.7),
        0 0 36px rgba(0,255,242,0.45);
      animation: glowPulse 3.6s ease-in-out infinite;
      margin: 0;
    }
    .title .accent { color: var(--arcade-neon-pink); }
    .subtitle {
      position: relative; z-index: 4;
      font-family: var(--font-body);
      font-size: clamp(13px, 2.4vw, 17px);
      color: #c9c9da;
      margin-top: 18px;
      letter-spacing: 0.5px;
      opacity: 0.92;
    }
    .blinkline {
      position: relative; z-index: 4;
      font-family: var(--font-pixel);
      font-size: clamp(9px, 1.6vw, 12px);
      color: var(--arcade-neon-yellow);
      margin-top: 22px;
      letter-spacing: 2px;
      text-shadow: 0 0 8px rgba(249,248,113,0.7);
      animation: softBlink 2.4s steps(1) infinite;
    }
    .stars {
      position: absolute; inset: 0; z-index: 1; pointer-events: none;
    }
    .stars span {
      position: absolute; width: 2px; height: 2px; border-radius: 50%;
      background: #fff; opacity: 0.5;
      animation: twinkle 3s ease-in-out infinite;
    }
    @keyframes glowPulse {
      0%, 100% { opacity: 1; filter: brightness(1); }
      50% { opacity: 0.82; filter: brightness(1.18); }
    }
    @keyframes softBlink {
      0%, 60% { opacity: 1; }
      61%, 100% { opacity: 0.15; }
    }
    @keyframes twinkle {
      0%, 100% { opacity: 0.2; }
      50% { opacity: 0.9; }
    }
    @media (prefers-reduced-motion: reduce) {
      .title, .blinkline, .stars span { animation: none; }
    }
  `;

  class ArcadeMarquee extends HTMLElement {
    constructor() { super(); this.attachShadow({ mode: 'open' }); }
    static get observedAttributes() { return ['subtitle', 'title', 'blinky']; }
    connectedCallback() {
      this.render();
    }
    attributeChangedCallback() { this.render(); }
    get subtitle() { return this.getAttribute('subtitle') || 'Insert coin · Press start · Defeat the high score'; }
    get titleText() {
      return this.getAttribute('title') || 'NEON ARCADE';
    }
    get blinky() { return this.getAttribute('blinky') || 'NOW LOADING...'; }
    render() {
      const title = this.titleText;
      // split title into words, accent the last word pink
      const words = title.split(' ');
      const head = words.slice(0, -1).join(' ');
      const tail = words[words.length - 1];
      const titleHtml = head ? `${head} <span class="accent">${tail}</span>` : `<span class="accent">${tail}</span>`;

      // generate stars
      let stars = '';
      for (let i = 0; i < 26; i++) {
        stars += `<span style="left:${Math.random()*100}%;top:${Math.random()*100}%;animation-delay:${(Math.random()*3).toFixed(2)}s"></span>`;
      }

      this.shadowRoot.innerHTML = `
        <style>${STYLE}</style>
        <div class="marquee">
          <div class="stars">${stars}</div>
          <h1 class="title">${titleHtml}</h1>
          <div class="subtitle">${this.subtitle}</div>
          <div class="blinkline">${this.blinky}</div>
        </div>
      `;
    }
  }
  customElements.define('arcade-marquee', ArcadeMarquee);
})();
