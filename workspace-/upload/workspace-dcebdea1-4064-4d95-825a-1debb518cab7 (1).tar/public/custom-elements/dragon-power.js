// Wix Custom Element — save as public/custom-elements/dragon-power.js — tag: dragon-power
//
// Dragon Power — a Dragon Ball-inspired action game.
//   • Pick a Z-fighter (Goku / Vegeta / Gohan / Piccolo / Trunks).
//   • Power levels are canon-accurate (Daizenshuu/manga guide values) and drive
//     a real combat ratio: damage scales with effectivePL vs enemyPL.
//   • Charge & fire ki blasts that CARVE destructible pixel terrain.
//   • Fight escalating waves of enemies, boss every 4th wave.
//   • Level up your Power Level; transform at canon thresholds (Kaioken, SSJ, SSJ2…).
//
// Controls: A/D move · W/S fly up/down · J or SPACE fire ki · K hold to charge ·
//           L transform (when unlocked) · P melee · touch buttons on mobile.

(function () {
  const STYLE = `
    :host {
      display: block; width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --arcade-neon-orange: #ff8c2a;
      --arcade-neon-purple: #b14dff;
      --arcade-neon-red: #ff3b3b;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body); color: #e8e8f0;
    }
    * { box-sizing: border-box; }
    .wrap {
      position: relative; background: var(--arcade-bg);
      border: 2px solid var(--arcade-neon-orange); border-radius: 10px;
      box-shadow: 0 0 16px rgba(255,140,42,0.5), inset 0 0 30px rgba(255,140,42,0.05);
      padding: 12px; overflow: hidden;
    }
    .wrap::after {
      content: ""; position: absolute; inset: 0; pointer-events: none; z-index: 6;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay;
    }
    .head { display:flex; align-items:center; justify-content:space-between; margin-bottom:8px; gap:8px; }
    .title { font-family: var(--font-pixel); font-size:13px; letter-spacing:1px; color: var(--arcade-neon-orange); text-shadow:0 0 8px rgba(255,140,42,0.9); }
    .hint { font-size:10px; color:#9aa; }
    .hud {
      display:flex; gap:6px; margin-bottom:8px; flex-wrap:wrap;
      font-family: var(--font-pixel); font-size:8px;
    }
    .hud .cell {
      background: var(--arcade-panel); border:1px solid #2a2a3d; border-radius:6px;
      padding:5px 8px; flex:1; min-width:64px;
    }
    .hud .l { color:#7a7a8c; letter-spacing:.5px; margin-bottom:3px; }
    .hud .v { font-size:11px; }
    .hud .pl .v { color: var(--arcade-neon-yellow); text-shadow:0 0 6px rgba(249,248,113,0.7); }
    .hud .wave .v { color: var(--arcade-neon-cyan); text-shadow:0 0 6px rgba(0,255,242,0.6); }
    .hud .form .v { color: var(--arcade-neon-orange); text-shadow:0 0 6px rgba(255,140,42,0.7); }
    .hud .best .v { color: var(--arcade-neon-green); text-shadow:0 0 6px rgba(57,255,20,0.6); }
    .hpbar, .kibar {
      height: 8px; border-radius: 4px; background:#222230; overflow:hidden; margin-top:3px;
      border:1px solid #2a2a3d;
    }
    .hpbar > div { height:100%; background: var(--arcade-neon-green); box-shadow:0 0 6px rgba(57,255,20,0.6); transition: width .15s; }
    .kibar > div  { height:100%; background: var(--arcade-neon-cyan);  box-shadow:0 0 6px rgba(0,255,242,0.6); transition: width .1s; }
    .bossbar {
      display:none; margin-bottom:8px;
    }
    .bossbar.show { display:block; }
    .bossbar .lbl { font-family: var(--font-pixel); font-size:8px; color: var(--arcade-neon-pink); margin-bottom:3px; text-shadow:0 0 6px rgba(255,45,149,0.7); letter-spacing:.5px; }
    .bossbar .bar { height:10px; border-radius:5px; background:#2a0a18; overflow:hidden; border:1px solid rgba(255,45,149,0.4); }
    .bossbar .bar > div { height:100%; background: linear-gradient(90deg, var(--arcade-neon-pink), var(--arcade-neon-red)); box-shadow:0 0 8px rgba(255,45,149,0.7); transition: width .15s; }
    canvas { display:block; width:100%; height:auto; background:#04040a; border:2px solid #2a2a3d; border-radius:6px; image-rendering:pixelated; touch-action:none; }
    .touch { display:none; margin-top:10px; }
    .touch .row { display:flex; gap:6px; }
    .tbtn {
      flex:1; font-family: var(--font-pixel); font-size:9px; padding:12px 0;
      background: var(--arcade-panel); color: var(--arcade-neon-cyan);
      border:1px solid var(--arcade-neon-cyan); border-radius:6px;
      box-shadow:0 0 6px rgba(0,255,242,0.25); cursor:pointer; user-select:none; touch-action:manipulation;
    }
    .tbtn.ki { color: var(--arcade-neon-yellow); border-color: var(--arcade-neon-yellow); box-shadow:0 0 6px rgba(249,248,113,0.3); }
    .tbtn.tf { color: var(--arcade-neon-orange); border-color: var(--arcade-neon-orange); box-shadow:0 0 6px rgba(255,140,42,0.3); }
    .tbtn.atk{ color: var(--arcade-neon-pink); border-color: var(--arcade-neon-pink); box-shadow:0 0 6px rgba(255,45,149,0.3); }
    .tbtn:active { background: rgba(0,255,242,0.18); }
    .tbtn.ki:active { background: rgba(249,248,113,0.18); }
    .tbtn.tf:active { background: rgba(255,140,42,0.18); }
    .tbtn.atk:active{ background: rgba(255,45,149,0.18); }
    .overlay { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(4,4,10,0.9); z-index:10; border-radius:10px; padding:14px; }
    .overlay.hide { display:none; }
    .ocard { text-align:center; max-width:520px; }
    .otitle { font-family: var(--font-pixel); font-size:16px; color: var(--arcade-neon-orange); text-shadow:0 0 12px rgba(255,140,42,0.9); margin-bottom:10px; letter-spacing:1px; }
    .osub { font-family: var(--font-pixel); font-size:9px; color:#9aa; margin-bottom:14px; line-height:1.5; }
    .oscore { font-family: var(--font-pixel); font-size:13px; color: var(--arcade-neon-yellow); text-shadow:0 0 8px rgba(249,248,113,0.7); margin-bottom:4px; }
    .ohs { font-size:10px; color:#7a7a8c; margin-bottom:14px; }
    .obtn { font-family: var(--font-pixel); font-size:10px; padding:12px 18px; background:transparent; color: var(--arcade-neon-orange); border:2px solid var(--arcade-neon-orange); border-radius:6px; box-shadow:0 0 12px rgba(255,140,42,0.4); cursor:pointer; text-transform:uppercase; letter-spacing:1px; }
    .obtn:active { background: rgba(255,140,42,0.18); }
    .transform-flash {
      position:absolute; inset:0; pointer-events:none; z-index:8;
      background: radial-gradient(circle, rgba(249,248,113,0.85), rgba(255,140,42,0.4) 40%, transparent 70%);
      opacity:0; border-radius:10px;
    }
  `;

  /* ------------------------------------------------------------------ */
  /* ROSTER — playable Z-fighters with canon power levels + forms       */
  /* ------------------------------------------------------------------ */
  const ROSTER = [
    {
      name: 'GOKU', tag: 'goku', color: '#ff8c2a', hair: '#111111', skin: '#f0c8a0',
      basePL: 416, // Saiyan saga base (weighted-clothes reading)
      forms: [
        { name: 'Base',           plMul: 1,   aura: null,        hair: '#111111' },
        { name: 'Kaio-ken',       plMul: 4,   aura: '#ff3b3b',   hair: '#111111' },
        { name: 'Super Saiyan',   plMul: 50,  aura: '#f9f871',   hair: '#f9f871' },
        { name: 'Super Saiyan 2', plMul: 100, aura: '#f9f871',   hair: '#f9f871', spark: true },
        { name: 'Super Saiyan 3', plMul: 400, aura: '#f9f871',   hair: '#f9f871', longHair: true, spark: true }
      ]
    },
    {
      name: 'VEGETA', tag: 'vegeta', color: '#00fff2', hair: '#111111', skin: '#f0c8a0',
      basePL: 18000,
      forms: [
        { name: 'Base',           plMul: 1,   aura: null,        hair: '#111111' },
        { name: 'Super Saiyan',   plMul: 50,  aura: '#f9f871',   hair: '#f9f871' },
        { name: 'Super Saiyan 2', plMul: 100, aura: '#f9f871',   hair: '#f9f871', spark: true },
        { name: 'Majin',          plMul: 150, aura: '#b14dff',   hair: '#111111', spark: true }
      ]
    },
    {
      name: 'GOHAN', tag: 'gohan', color: '#39ff14', hair: '#111111', skin: '#f0c8a0',
      basePL: 981, // early Saiyan saga
      forms: [
        { name: 'Base',           plMul: 1,   aura: null,        hair: '#111111' },
        { name: 'Super Saiyan',   plMul: 50,  aura: '#f9f871',   hair: '#f9f871' },
        { name: 'Super Saiyan 2', plMul: 100, aura: '#f9f871',   hair: '#f9f871', spark: true },
        { name: 'Ultimate',       plMul: 200, aura: '#e8e8f0',   hair: '#111111', spark: true }
      ]
    },
    {
      name: 'PICCOLO', tag: 'piccolo', color: '#39ff14', hair: '#ff8cb4', skin: '#5ab85a',
      basePL: 408, // weighted
      forms: [
        { name: 'Weighted',        plMul: 1,   aura: null,        hair: '#ff8cb4' },
        { name: 'Unweighted',       plMul: 1.5, aura: '#39ff14',   hair: '#ff8cb4' },
        { name: 'Fuse w/ Nail',     plMul: 12,  aura: '#39ff14',   hair: '#ff8cb4' },
        { name: 'Super Namek',      plMul: 50,  aura: '#39ff14',   hair: '#ff8cb4', spark: true }
      ]
    },
    {
      name: 'TRUNKS', tag: 'trunks', color: '#b14dff', hair: '#c9c9da', skin: '#f0c8a0',
      basePL: 78000,
      forms: [
        { name: 'Base',            plMul: 1,  aura: null,        hair: '#c9c9da' },
        { name: 'Super Saiyan',    plMul: 50, aura: '#f9f871',   hair: '#f9f871' },
        { name: 'Ultra SSJ',       plMul: 70, aura: '#f9f871',   hair: '#f9f871', bulk: true }
      ]
    }
  ];

  /* ------------------------------------------------------------------ */
  /* ENEMIES — canon power-level ladder, bosses flagged                 */
  /* ------------------------------------------------------------------ */
  const ENEMIES = [
    { name: 'Saibaman',           pl: 1200,     hp: 28,   color: '#7aa83a', size: 16, speed: 1.1 },
    { name: 'Raditz',             pl: 1500,     hp: 70,   color: '#7a7a7a', size: 20, speed: 1.2 },
    { name: 'Saibaman x3',        pl: 1200,     hp: 28,   color: '#7aa83a', size: 16, speed: 1.2, count: 3 },
    { name: 'Nappa',              pl: 4000,     hp: 180,  color: '#9a9a9a', size: 26, speed: 1.0 },
    { name: 'VEGETA (Saiyan Saga)', pl: 18000,  hp: 600,  color: '#3a3a5a', size: 24, speed: 1.6, boss: true },
    { name: 'Cui',                 pl: 18000,   hp: 380,  color: '#7a3aa0', size: 22, speed: 1.3 },
    { name: 'Dodoria',            pl: 22000,    hp: 520,  color: '#ff8cb4', size: 26, speed: 1.3 },
    { name: 'Zarbon',             pl: 23000,    hp: 560,  color: '#7ad0c0', size: 24, speed: 1.4 },
    { name: 'ZARBON (Transformed)', pl: 30000,  hp: 760,  color: '#3a6a5a', size: 28, speed: 1.5, boss: true },
    { name: 'Guldo',              pl: 19000,    hp: 300,  color: '#6a8a3a', size: 18, speed: 1.0 },
    { name: 'Recoome',            pl: 65000,    hp: 1100, color: '#ff8c2a', size: 28, speed: 1.1 },
    { name: 'Burter',             pl: 65000,    hp: 1050, color: '#3a6aff', size: 26, speed: 2.0 },
    { name: 'Jeice',              pl: 64000,    hp: 1020, color: '#ff3b3b', size: 26, speed: 1.5 },
    { name: 'CAPT. GINYU',        pl: 120000,   hp: 2200, color: '#3a3a5a', size: 28, speed: 1.7, boss: true },
    { name: 'Frieza 1st Form',    pl: 530000,   hp: 4800, color: '#e8e8f0', size: 28, speed: 1.5 },
    { name: 'Frieza 2nd Form',    pl: 1000000,  hp: 8200, color: '#b0b0c8', size: 32, speed: 1.6 },
    { name: 'Frieza 3rd Form',    pl: 2000000,  hp: 13000, color: '#9a9abe', size: 34, speed: 1.7 },
    { name: 'FRIEZA (Final 50%)', pl: 60000000, hp: 34000, color: '#e8e8f0', size: 30, speed: 2.0, boss: true },
    { name: 'FRIEZA (100%)',      pl: 120000000, hp: 60000, color: '#f9f871', size: 32, speed: 2.2, boss: true },
    { name: 'CELL (Perfect)',     pl: 900000000, hp: 120000, color: '#39ff14', size: 32, speed: 2.0, boss: true },
    { name: 'SUPER BUU',          pl: 8000000000, hp: 280000, color: '#ff8cb4', size: 34, speed: 2.4, boss: true },
    { name: 'KID BUU',            pl: 12000000000, hp: 360000, color: '#ff8cb4', size: 30, speed: 2.8, boss: true }
  ];

  const HS_KEY = 'arcade-highscore-dragon-power';
  const CHAR_KEY = 'arcade-dragon-lastchar';

  /* helper: format big numbers DBZ-style (1,200 / 1.2M / 12B) */
  function fmtPL(n) {
    n = Math.floor(n);
    if (n >= 1e12) return (n / 1e12).toFixed(2).replace(/\.00$/, '') + 'T';
    if (n >= 1e9)  return (n / 1e9).toFixed(2).replace(/\.00$/, '')  + 'B';
    if (n >= 1e6)  return (n / 1e6).toFixed(2).replace(/\.00$/, '')  + 'M';
    if (n >= 1e3)  return n.toLocaleString('en-US');
    return String(n);
  }

  /* combat ratio: 1 = full power, <1 = outmatched */
  function combatRatio(effPL, enemyPL) {
    if (effPL <= 0) return 0.02;
    if (effPL >= enemyPL) return 1;
    // sigmoid-ish: smoothly falls off as enemy outclasses you
    return Math.max(0.02, effPL / enemyPL);
  }

  class DragonPower extends HTMLElement {
    constructor() { super(); this.attachShadow({ mode: 'open' }); }
    connectedCallback() {
      const root = this.shadowRoot;
      root.innerHTML = `
        <style>${STYLE}</style>
        <div class="wrap" id="wrap">
          <div class="head">
            <div class="title">DRAGON POWER</div>
            <div class="hint">A/D move · W/S fly · J/SPACE ki · K charge · L transform · P punch</div>
          </div>
          <div class="bossbar" id="bossbar">
            <div class="lbl" id="bossname">BOSS</div>
            <div class="bar"><div id="bossfill" style="width:100%"></div></div>
          </div>
          <div class="hud">
            <div class="cell pl"><div class="l">POWER LEVEL</div><div class="v" id="plval">0</div></div>
            <div class="cell wave"><div class="l">WAVE</div><div class="v" id="waveval">1</div></div>
            <div class="cell form"><div class="l">FORM</div><div class="v" id="formval">BASE</div></div>
            <div class="cell"><div class="l">HP</div><div class="v" id="hpval">100</div>
              <div class="hpbar"><div id="hpfill" style="width:100%"></div></div>
            </div>
            <div class="cell"><div class="l">KI</div><div class="v" id="kival">100</div>
              <div class="kibar"><div id="kifill" style="width:100%"></div></div>
            </div>
            <div class="cell best"><div class="l">BEST PL</div><div class="v" id="bestval">0</div></div>
          </div>
          <canvas id="cv" width="720" height="400"></canvas>
          <div class="touch" id="touch">
            <div class="row">
              <button class="tbtn" data-k="left">◀</button>
              <button class="tbtn" data-k="right">▶</button>
              <button class="tbtn" data-k="up">▲</button>
              <button class="tbtn" data-k="down">▼</button>
            </div>
            <div class="row" style="margin-top:6px;">
              <button class="tbtn atk" data-k="punch">PUNCH</button>
              <button class="tbtn ki"  data-k="charge">CHARGE</button>
              <button class="tbtn ki"  data-k="fire">KI BLAST</button>
              <button class="tbtn tf"  data-k="transform">TRANSFORM</button>
            </div>
          </div>
          <div class="transform-flash" id="flash"></div>
          <div class="overlay" id="overlay">
            <div class="ocard" id="ocard"></div>
          </div>
        </div>
      `;

      this.cv = root.getElementById('cv');
      this.ctx = this.cv.getContext('2d');
      // offscreen terrain canvas
      this.terrainCv = document.createElement('canvas');
      this.terrainCtx = this.terrainCv.getContext('2d');

      this.plval = root.getElementById('plval');
      this.waveval = root.getElementById('waveval');
      this.formval = root.getElementById('formval');
      this.hpval = root.getElementById('hpval');
      this.hpfill = root.getElementById('hpfill');
      this.kival = root.getElementById('kival');
      this.kifill = root.getElementById('kifill');
      this.bestval = root.getElementById('bestval');
      this.bossbar = root.getElementById('bossbar');
      this.bossname = root.getElementById('bossname');
      this.bossfill = root.getElementById('bossfill');
      this.overlay = root.getElementById('overlay');
      this.ocard = root.getElementById('ocard');
      this.flash = root.getElementById('flash');
      this.touchWrap = root.getElementById('touch');

      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      if (isTouch) this.touchWrap.style.display = 'block';

      this.keys = {};
      this._onKey = (e) => this.onKey(e, true);
      this._onKeyUp = (e) => this.onKey(e, false);
      this._onResize = () => this.resize();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('keyup', this._onKeyUp);
      window.addEventListener('resize', this._onResize);

      // canvas pointer for character select
      this._onClick = (e) => this.onCanvasClick(e);
      this.cv.addEventListener('click', this._onClick);

      // touch controls -> set keys
      this.touchWrap.addEventListener('pointerdown', (e) => {
        const btn = e.target.closest('.tbtn');
        if (!btn) return;
        e.preventDefault();
        const k = btn.dataset.k;
        if (k === 'transform') { this.tryTransform(); return; }
        if (k === 'fire') { this.fireKi(); return; }
        if (k === 'punch') { this.melee(); return; }
        this.keys[k] = true;
      });
      this.touchWrap.addEventListener('pointerup', (e) => {
        const btn = e.target.closest('.tbtn');
        if (!btn) return;
        const k = btn.dataset.k;
        if (['left','right','up','down','charge'].includes(k)) this.keys[k] = false;
      });
      this.touchWrap.addEventListener('pointerleave', () => {
        ['left','right','up','down','charge'].forEach((k) => this.keys[k] = false);
      });

      this.highScore = this.loadHighScore();
      this.bestval.textContent = fmtPL(this.highScore);
      this.resize();
      this.state = 'select'; // 'select' | 'play' | 'over'
      this.selectedChar = parseInt(localStorage.getItem(CHAR_KEY) || '0', 10) || 0;
      this.renderSelect();
      this.lastT = performance.now();
      this.loop();
    }

    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('keyup', this._onKeyUp);
      window.removeEventListener('resize', this._onResize);
      this.cv.removeEventListener('click', this._onClick);
      cancelAnimationFrame(this.raf);
    }

    resize() {
      const w = this.clientWidth || 720;
      const ratio = 720 / 400;
      let cw = w;
      let ch = Math.round(cw / ratio);
      this.cv.width = cw; this.cv.height = ch;
      this.scale = cw / 720;
      // terrain grid
      this.cellSize = Math.max(4, Math.round(this.scale * 6));
      this.gridW = Math.floor(this.cv.width / this.cellSize);
      this.gridH = Math.floor(this.cv.height / this.cellSize);
      this.terrainCv.width = this.gridW;
      this.terrainCv.height = this.gridH;
      if (this.state === 'play') this.rebuildTerrain();
    }

    loadHighScore() { try { return parseInt(localStorage.getItem(HS_KEY) || '0', 10) || 0; } catch (e) { return 0; } }
    saveHighScore(v) { try { localStorage.setItem(HS_KEY, String(v)); } catch (e) {} }

    /* ---------------- character select screen ---------------- */
    renderSelect() {
      this.overlay.classList.remove('hide');
      let html = `<div class="otitle">SELECT FIGHTER</div>`;
      html += `<div class="osub">Power levels are canon-accurate.<br>Each form unlocks at PL thresholds.</div>`;
      html += `<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-bottom:14px;">`;
      ROSTER.forEach((c, i) => {
        const sel = i === this.selectedChar ? 'outline:2px solid ' + c.color + ';' : 'outline:2px solid #2a2a3d;';
        html += `<button class="obtn" data-sel="${i}" style="${sel} color:${c.color}; border-color:${c.color}; font-size:9px; padding:10px 8px;">${c.name}<br><span style="color:#7a7a8c; font-size:7px;">BASE ${fmtPL(c.basePL)}</span></button>`;
      });
      html += `</div>`;
      html += `<button class="obtn" id="startbtn">▶ POWER UP</button>`;
      html += `<div class="osub" style="margin-top:14px;">Tip: hold CHARGE to power up ki · fire to blast pixels & enemies · TRANSFORM when your PL is high enough.</div>`;
      this.ocard.innerHTML = html;
      this.ocard.querySelectorAll('[data-sel]').forEach((b) => {
        b.addEventListener('click', () => {
          this.selectedChar = parseInt(b.dataset.sel, 10);
          try { localStorage.setItem(CHAR_KEY, String(this.selectedChar)); } catch (e) {}
          this.renderSelect();
        });
      });
      this.ocard.querySelector('#startbtn').addEventListener('click', () => this.startGame());
    }

    startGame() {
      this.overlay.classList.add('hide');
      this.char = ROSTER[this.selectedChar];
      this.form = 0;
      this.powerLevel = this.char.basePL;
      this.hp = 100; this.maxHp = 100;
      this.ki = 100; this.maxKi = 100;
      this.wave = 0;
      this.enemies = [];
      this.bullets = []; // player ki blasts
      this.eBullets = []; // enemy ki blasts
      this.particles = [];
      this.popups = []; // floating text (PL readings, damage)
      this.shake = 0;
      this.state = 'play';
      this.waveCleared = true;
      this.waveDelay = 90;
      this.rebuildTerrain();
      this.bossbar.classList.remove('show');
      this.updateHud();
      this.lastT = performance.now();
    }

    rebuildTerrain() {
      const gw = this.gridW, gh = this.gridH;
      this.terrain = new Uint8Array(gw * gh);
      // ground (bottom 6 rows)
      const groundH = 6;
      for (let y = gh - groundH; y < gh; y++)
        for (let x = 0; x < gw; x++) this.terrain[y * gw + x] = 1;
      // a couple of floating platforms
      const plat = (px, py, pw) => {
        for (let x = px; x < px + pw && x < gw; x++)
          for (let y = py; y < py + 2 && y < gh; y++) this.terrain[y * gw + x] = 1;
      };
      plat(Math.floor(gw * 0.18), Math.floor(gh * 0.55), Math.floor(gw * 0.16));
      plat(Math.floor(gw * 0.66), Math.floor(gh * 0.55), Math.floor(gw * 0.16));
      plat(Math.floor(gw * 0.42), Math.floor(gh * 0.32), Math.floor(gw * 0.16));
      this.terrainDirty = true;
      this.player = {
        x: 100, y: this.cv.height * 0.45,
        vx: 0, vy: 0, face: 1, charge: 0, meleeCd: 0, invuln: 0, flashT: 0
      };
    }

    /* ---------------- input ---------------- */
    onKey(e, down) {
      const k = e.key.toLowerCase();
      const map = {
        a: 'left', arrowleft: 'left',
        d: 'right', arrowright: 'right',
        w: 'up', arrowup: 'up',
        s: 'down', arrowdown: 'down',
        k: 'charge',
        j: 'fire', ' ': 'fire',
        p: 'punch',
        l: 'transform'
      };
      if (map[k]) {
        e.preventDefault();
        if (down) {
          if (map[k] === 'fire') this.fireKi();
          else if (map[k] === 'punch') this.melee();
          else if (map[k] === 'transform') this.tryTransform();
          else this.keys[map[k]] = true;
        } else {
          if (['left','right','up','down','charge'].includes(map[k])) this.keys[map[k]] = false;
        }
      }
    }

    onCanvasClick(e) {
      if (this.state !== 'select') return;
      // handled by overlay buttons
    }

    /* ---------------- actions ---------------- */
    fireKi() {
      if (this.state !== 'play') return;
      const cost = 14;
      if (this.ki < cost) return;
      this.ki -= cost;
      const p = this.player;
      const form = this.char.forms[this.form];
      const effPL = this.effPL();
      // blast radius scales with charge held + power
      const rad = Math.max(10, 14 + (p.charge * 0.5) + Math.log10(effPL + 1) * 4);
      const dmg = this.kiDamage(effPL);
      // aim: horizontal by facing; if holding up/down, add vertical component (so you
      // can deliberately carve terrain by aiming blasts into the ground).
      let vx = p.face * (7 + p.charge * 0.2), vy = 0;
      if (this.keys.up)   { vx = p.face * 3.5; vy = -6; }
      if (this.keys.down) { vx = p.face * 3.5; vy =  6; }
      this.bullets.push({
        x: p.x + p.face * 18, y: p.y - 4,
        vx, vy,
        r: rad, dmg, life: 90, color: form.aura || this.char.color, trail: []
      });
      // recoil
      p.vx -= vx * 0.18; p.vy -= vy * 0.18;
      p.charge = 0;
    }

    kiDamage(effPL) {
      // base damage scales with log of power
      return 8 + Math.log10(effPL + 10) * 10;
    }

    melee() {
      if (this.state !== 'play') return;
      const p = this.player;
      if (p.meleeCd > 0) return;
      p.meleeCd = 18;
      const effPL = this.effPL();
      const dmg = this.kiDamage(effPL) * 0.6;
      const hitX = p.x + p.face * 30, hitY = p.y;
      let hitAny = false;
      for (const en of this.enemies) {
        if (Math.abs(en.x - hitX) < 28 && Math.abs(en.y - hitY) < 28) {
          this.damageEnemy(en, dmg * 0.8, p.face * 6);
          hitAny = true;
        }
      }
      if (hitAny) {
        this.shake = Math.max(this.shake, 4);
        p.vx -= p.face * 2;
      }
    }

    tryTransform() {
      if (this.state !== 'play') return;
      if (this.form + 1 >= this.char.forms.length) return;
      const nextForm = this.char.forms[this.form + 1];
      const threshold = this.transformThreshold(this.form + 1);
      if (this.powerLevel < threshold) {
        this.addPopup(this.player.x, this.player.y - 30, 'NEED PL ' + fmtPL(threshold), '#ff3b3b');
        return;
      }
      this.form++;
      this.flashTransform();
      this.addPopup(this.player.x, this.player.y - 40, this.char.forms[this.form].name.toUpperCase() + '!', this.char.forms[this.form].aura || '#f9f871');
      this.updateHud();
    }

    transformThreshold(formIndex) {
      // thresholds scale with the form's multiplier vs base — so SSJ (x50) needs ~50x base, etc.
      const form = this.char.forms[formIndex];
      // a bit forgiving so it's reachable in a run
      return Math.floor(this.char.basePL * form.plMul * 0.7);
    }

    effPL() {
      const form = this.char.forms[this.form];
      return this.powerLevel * form.plMul;
    }

    flashTransform() {
      this.flash.style.transition = 'none';
      this.flash.style.opacity = '1';
      // force reflow
      void this.flash.offsetWidth;
      this.flash.style.transition = 'opacity .8s ease-out';
      this.flash.style.opacity = '0';
      this.shake = 14;
      // burst particles
      const p = this.player;
      for (let i = 0; i < 40; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = Math.random() * 5 + 2;
        this.particles.push({ x: p.x, y: p.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 40, color: this.char.forms[this.form].aura || '#f9f871', r: 3 });
      }
    }

    addPopup(x, y, text, color) {
      this.popups.push({ x, y, text, color, life: 60 });
    }

    /* ---------------- wave / enemy management ---------------- */
    startNextWave() {
      this.wave++;
      const def = ENEMIES[(this.wave - 1) % ENEMIES.length];
      const count = def.count || 1;
      this.enemies = [];
      for (let i = 0; i < count; i++) {
        const side = i % 2 === 0 ? 1 : -1;
        this.enemies.push(this.makeEnemy(def, side, i * 30));
      }
      this.currentWaveDef = def;
      this.waveCleared = false;
      // scouter popup
      const txt = def.boss ? ('⚠ ' + def.name + ' — PL ' + fmtPL(def.pl)) : (def.name + ' PL ' + fmtPL(def.pl));
      this.addPopup(this.cv.width / 2, 40, txt, def.boss ? '#ff2d95' : '#00fff2');
      if (def.boss) {
        this.bossbar.classList.add('show');
        this.bossname.textContent = def.name + ' · PL ' + fmtPL(def.pl);
        this.bossMaxHp = def.hp;
      } else {
        this.bossbar.classList.remove('show');
      }
      this.updateHud();
    }

    makeEnemy(def, side, offset) {
      return {
        ...def,
        x: side > 0 ? this.cv.width + 30 + offset : -30 - offset,
        y: this.cv.height * 0.4 + (Math.random() - 0.5) * 80,
        vx: 0, vy: 0,
        hp: def.hp, maxHp: def.hp,
        fireCd: 80 + Math.random() * 60,
        hitFlash: 0, face: -side
      };
    }

    damageEnemy(en, dmg, knockback) {
      const ratio = combatRatio(this.effPL(), en.pl);
      const actual = dmg * ratio;
      en.hp -= actual;
      en.hitFlash = 8;
      en.vx += knockback;
      this.addPopup(en.x, en.y - en.size, '-' + Math.ceil(actual), ratio > 0.8 ? '#f9f871' : (ratio > 0.4 ? '#ff8c2a' : '#ff3b3b'));
      if (en.hp <= 0) this.killEnemy(en);
      else if (en.boss) this.bossfill.style.width = Math.max(0, (en.hp / en.maxHp) * 100) + '%';
    }

    killEnemy(en) {
      // power level gain = fraction of enemy PL
      const gain = Math.max(1, Math.floor(en.pl * 0.18));
      this.powerLevel += gain;
      this.addPopup(en.x, en.y - 20, '+' + fmtPL(gain) + ' PL', '#39ff14');
      // explosion particles + terrain carve
      this.explode(en.x, en.y, en.size + 10, en.color);
      this.shake = Math.max(this.shake, en.boss ? 16 : 6);
      // remove
      const idx = this.enemies.indexOf(en);
      if (idx >= 0) this.enemies.splice(idx, 1);
      // check transform availability
      if (this.form + 1 < this.char.forms.length) {
        const thresh = this.transformThreshold(this.form + 1);
        if (this.powerLevel >= thresh) {
          this.addPopup(this.player.x, this.player.y - 50, 'TRANSFORM READY [L]', this.char.forms[this.form + 1].aura || '#f9f871');
        }
      }
      this.updateHud();
      // wave clear?
      if (this.enemies.length === 0 && !this.waveCleared) {
        this.waveCleared = true;
        this.waveDelay = 100;
        this.bossbar.classList.remove('show');
      }
    }

    explode(x, y, r, color) {
      // carve terrain
      const gw = this.gridW, gh = this.gridH, cs = this.cellSize;
      const gx = Math.floor(x / cs), gy = Math.floor(y / cs), gr = Math.ceil(r / cs);
      for (let dy = -gr; dy <= gr; dy++) {
        for (let dx = -gr; dx <= gr; dx++) {
          if (dx * dx + dy * dy > gr * gr) continue;
          const cx = gx + dx, cy = gy + dy;
          if (cx < 0 || cx >= gw || cy < 0 || cy >= gh) continue;
          this.terrain[cy * gw + cx] = 0;
        }
      }
      this.terrainDirty = true;
      // particles
      for (let i = 0; i < 14; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = Math.random() * 4 + 1;
        this.particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 26 + Math.random() * 12, color, r: Math.random() * 3 + 1 });
      }
    }

    /* ---------------- update loop ---------------- */
    update(dt) {
      if (this.state !== 'play') return;
      const p = this.player;
      const effPL = this.effPL();
      const form = this.char.forms[this.form];

      // movement
      const sp = 3.6;
      if (this.keys.left)  { p.vx -= 0.6; p.face = -1; }
      if (this.keys.right) { p.vx += 0.6; p.face = 1; }
      if (this.keys.up)    p.vy -= 0.6;
      if (this.keys.down)  p.vy += 0.6;
      // friction + clamp
      p.vx *= 0.85; p.vy *= 0.85;
      p.vx = Math.max(-sp, Math.min(sp, p.vx));
      p.vy = Math.max(-sp, Math.min(sp, p.vy));
      p.x += p.vx; p.y += p.vy;
      // bounds (keep on screen)
      p.x = Math.max(20, Math.min(this.cv.width - 20, p.x));
      p.y = Math.max(20, Math.min(this.cv.height - 30, p.y));

      // charge
      if (this.keys.charge) {
        this.ki = Math.min(this.maxKi, this.ki + 1.4);
        p.charge = Math.min(60, p.charge + 1);
      } else {
        // passive ki regen
        this.ki = Math.min(this.maxKi, this.ki + 0.25);
      }
      if (p.meleeCd > 0) p.meleeCd--;
      if (p.invuln > 0) p.invuln--;
      if (p.flashT > 0) p.flashT--;

      // bullets
      for (const b of this.bullets) {
        b.trail.push({ x: b.x, y: b.y });
        if (b.trail.length > 6) b.trail.shift();
        b.x += b.vx; b.y += b.vy;
        b.life--;
        // hit terrain?
        if (this.solidAt(b.x, b.y)) {
          this.explode(b.x, b.y, b.r * 0.7, b.color);
          b.life = 0;
        }
        // hit enemies?
        for (const en of this.enemies) {
          if (Math.hypot(en.x - b.x, en.y - b.y) < en.size + b.r * 0.5) {
            this.damageEnemy(en, b.dmg, Math.sign(b.vx) * 4);
            this.explode(b.x, b.y, b.r * 0.6, b.color);
            b.life = 0;
            break;
          }
        }
      }
      this.bullets = this.bullets.filter((b) => b.life > 0 && b.x > -40 && b.x < this.cv.width + 40);

      // enemies
      for (const en of this.enemies) {
        // AI: fly toward player
        const dx = p.x - en.x, dy = p.y - en.y;
        const dist = Math.hypot(dx, dy) || 1;
        const ratio = combatRatio(en.pl, effPL); // enemy effectiveness vs player
        // approach but keep some distance for shooters
        const desired = 60;
        if (dist > desired) {
          en.vx += (dx / dist) * en.speed * 0.15;
          en.vy += (dy / dist) * en.speed * 0.15;
        } else {
          en.vx *= 0.9; en.vy *= 0.9;
        }
        en.vx *= 0.9; en.vy *= 0.9;
        en.x += en.vx; en.y += en.vy;
        en.face = dx >= 0 ? 1 : -1;
        en.x = Math.max(-40, Math.min(this.cv.width + 40, en.x));
        en.y = Math.max(20, Math.min(this.cv.height - 20, en.y));
        if (en.hitFlash > 0) en.hitFlash--;

        // enemy ki blasts (higher-tier enemies + all bosses)
        en.fireCd--;
        const canShoot = en.pl >= 4000;
        if (canShoot && en.fireCd <= 0 && dist < 360) {
          en.fireCd = en.boss ? 50 : 110;
          this.eBullets.push({
            x: en.x, y: en.y,
            vx: (dx / dist) * 4.5, vy: (dy / dist) * 4.5,
            r: en.boss ? 12 : 8,
            dmg: 8 + Math.log10(en.pl + 10) * 6,
            life: 120, color: en.color
          });
        }
        // melee touch damage
        if (dist < en.size + 18 && p.invuln <= 0) {
          this.hurtPlayer(en.boss ? 14 : 8, en.face);
        }
      }

      // enemy bullets
      for (const b of this.eBullets) {
        b.x += b.vx; b.y += b.vy; b.life--;
        if (this.solidAt(b.x, b.y)) { this.explode(b.x, b.y, b.r * 0.5, b.color); b.life = 0; }
        if (Math.hypot(b.x - p.x, b.y - p.y) < 16 + b.r * 0.5 && p.invuln <= 0) {
          this.hurtPlayer(b.dmg, Math.sign(b.vx));
          this.explode(b.x, b.y, b.r * 0.7, b.color);
          b.life = 0;
        }
      }
      this.eBullets = this.eBullets.filter((b) => b.life > 0 && b.x > -40 && b.x < this.cv.width + 40 && b.y > -40 && b.y < this.cv.height + 40);

      // particles
      for (const pt of this.particles) { pt.x += pt.vx; pt.y += pt.vy; pt.vx *= 0.96; pt.vy *= 0.96; pt.life--; }
      this.particles = this.particles.filter((pt) => pt.life > 0);

      // popups
      for (const pp of this.popups) { pp.y -= 0.6; pp.life--; }
      this.popups = this.popups.filter((pp) => pp.life > 0);

      // shake decay
      if (this.shake > 0) this.shake = Math.max(0, this.shake - 0.8);

      // wave management
      if (this.waveCleared) {
        this.waveDelay--;
        if (this.waveDelay <= 0) {
          if (this.wave >= ENEMIES.length) {
            // loop again with scaled difficulty (enemies HP x1.5 per loop)
            this.startNextWave();
          } else {
            this.startNextWave();
          }
        }
      }

      // regrow terrain? No — keep destroyed (DBZ destruction stays).

      this.updateHud();
    }

    hurtPlayer(dmg, dir) {
      this.hp -= dmg;
      this.player.invuln = 30;
      this.player.flashT = 20;
      this.player.vx += dir * 4;
      this.shake = Math.max(this.shake, 8);
      this.addPopup(this.player.x, this.player.y - 20, '-' + Math.ceil(dmg), '#ff3b3b');
      if (this.hp <= 0) this.endGame();
    }

    endGame() {
      this.state = 'over';
      this.hp = 0;
      const finalPL = this.powerLevel;
      if (finalPL > this.highScore) { this.highScore = finalPL; this.saveHighScore(finalPL); }
      this.bestval.textContent = fmtPL(this.highScore);
      this.bossbar.classList.remove('show');
      this.overlay.classList.remove('hide');
      this.ocard.innerHTML = `
        <div class="otitle" style="color:var(--arcade-neon-pink); text-shadow:0 0 12px rgba(255,45,149,0.9);">DEFEATED</div>
        <div class="osub">${this.char.name} reached <b style="color:var(--arcade-neon-yellow)">${fmtPL(finalPL)}</b> power level.<br>Wave ${this.wave} · Form: ${this.char.forms[this.form].name}</div>
        <div class="oscore">FINAL PL ${fmtPL(finalPL)}</div>
        <div class="ohs">BEST PL ${fmtPL(this.highScore)}</div>
        <button class="obtn" id="again">▶ POWER UP AGAIN</button>
      `;
      this.ocard.querySelector('#again').addEventListener('click', () => { this.state = 'select'; this.renderSelect(); });
      this.dispatchEvent(new CustomEvent('game-over', {
        detail: { game: 'dragon-power', score: Math.floor(finalPL) },
        bubbles: true, composed: true
      }));
    }

    solidAt(px, py) {
      const gw = this.gridW, gh = this.gridH, cs = this.cellSize;
      const gx = Math.floor(px / cs), gy = Math.floor(py / cs);
      if (gx < 0 || gx >= gw || gy < 0 || gy >= gh) return false;
      return this.terrain[gy * gw + gx] === 1;
    }

    updateHud() {
      this.plval.textContent = fmtPL(this.effPL());
      this.waveval.textContent = this.wave || 1;
      this.formval.textContent = (this.char ? this.char.forms[this.form].name : 'BASE').toUpperCase();
      this.hpval.textContent = Math.max(0, Math.ceil(this.hp));
      this.hpfill.style.width = Math.max(0, (this.hp / this.maxHp) * 100) + '%';
      this.kival.textContent = Math.ceil(this.ki);
      this.kifill.style.width = (this.ki / this.maxKi) * 100 + '%';
    }

    /* ---------------- render ---------------- */
    draw() {
      const ctx = this.ctx, s = this.scale;
      const W = this.cv.width, H = this.cv.height;
      // bg
      const grad = ctx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, '#0a0a18');
      grad.addColorStop(1, '#04040a');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
      // distant stars (parallax)
      ctx.fillStyle = 'rgba(255,255,255,0.25)';
      const t = performance.now() * 0.0002;
      for (let i = 0; i < 40; i++) {
        const x = (i * 73 - t * 30) % W; const y = (i * 41) % (H * 0.6);
        ctx.fillRect(((x + W) % W), y, 2, 2);
      }
      // far mountains silhouette
      ctx.fillStyle = 'rgba(40,30,60,0.5)';
      ctx.beginPath(); ctx.moveTo(0, H * 0.7);
      for (let x = 0; x <= W; x += 60) ctx.lineTo(x, H * 0.7 - Math.sin(x * 0.01) * 30 - (x % 120 === 0 ? 20 : 0));
      ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();

      ctx.save();
      // screen shake
      if (this.shake > 0) {
        ctx.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);
      }
      ctx.scale(s, s);
      const LSCALE = 720 / s * s; // logical 720 wide
      // logical draw at 720x400 coordinate space
      ctx.scale(1 / s, 1 / s); // undo so we draw in scaled pixels? simpler: just draw in pixel coords directly.
      ctx.restore();

      // Simpler approach: draw everything in canvas pixel coordinates using this.scale multiplier where needed.
      // Redo save/scale cleanly:
      ctx.save();
      if (this.shake > 0) ctx.translate((Math.random() - 0.5) * this.shake, (Math.random() - 0.5) * this.shake);

      // terrain
      this.renderTerrain(ctx);

      if (this.state === 'play') {
        // particles (behind chars)
        for (const pt of this.particles) {
          ctx.globalAlpha = Math.max(0, pt.life / 40);
          ctx.fillStyle = pt.color;
          ctx.shadowColor = pt.color; ctx.shadowBlur = 6;
          ctx.fillRect(pt.x - pt.r/2, pt.y - pt.r/2, pt.r, pt.r);
        }
        ctx.globalAlpha = 1; ctx.shadowBlur = 0;

        // player ki bullets
        for (const b of this.bullets) {
          // trail
          for (let i = 0; i < b.trail.length; i++) {
            const tr = b.trail[i];
            ctx.globalAlpha = (i / b.trail.length) * 0.5;
            ctx.fillStyle = b.color;
            ctx.beginPath(); ctx.arc(tr.x, tr.y, b.r * 0.6, 0, Math.PI * 2); ctx.fill();
          }
          ctx.globalAlpha = 1;
          ctx.shadowColor = b.color; ctx.shadowBlur = 16;
          ctx.fillStyle = '#fff';
          ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.5, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = b.color;
          ctx.globalAlpha = 0.7;
          ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2); ctx.fill();
          ctx.globalAlpha = 1; ctx.shadowBlur = 0;
        }

        // enemies
        for (const en of this.enemies) this.drawEnemy(ctx, en);

        // enemy bullets
        for (const b of this.eBullets) {
          ctx.shadowColor = b.color; ctx.shadowBlur = 12;
          ctx.fillStyle = b.color;
          ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#fff';
          ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 0.4, 0, Math.PI * 2); ctx.fill();
          ctx.shadowBlur = 0;
        }

        // player
        this.drawPlayer(ctx);

        // popups
        for (const pp of this.popups) {
          ctx.globalAlpha = Math.min(1, pp.life / 40);
          ctx.fillStyle = pp.color;
          ctx.font = "9px 'Press Start 2P', monospace";
          ctx.textAlign = 'center';
          ctx.shadowColor = pp.color; ctx.shadowBlur = 6;
          ctx.fillText(pp.text, pp.x, pp.y);
          ctx.shadowBlur = 0;
        }
        ctx.globalAlpha = 1;

        // scouter corner: show highest enemy PL
        if (this.enemies.length) {
          const maxEn = this.enemies.reduce((a, b) => a.pl > b.pl ? a : b);
          ctx.fillStyle = 'rgba(0,255,242,0.8)';
          ctx.font = "7px 'Press Start 2P', monospace";
          ctx.textAlign = 'right';
          ctx.fillText('SCOUTER: ' + maxEn.name.toUpperCase().slice(0,18) + ' = ' + fmtPL(maxEn.pl), W - 8, H - 8);
        }
      }
      ctx.restore();
    }

    renderTerrain(ctx) {
      // blit offscreen terrain canvas (1px per cell) scaled up
      const gw = this.gridW, gh = this.gridH, cs = this.cellSize;
      if (this.terrainDirty) {
        const img = this.terrainCtx.createImageData(gw, gh);
        for (let i = 0; i < gw * gh; i++) {
          const v = this.terrain[i];
          const o = i * 4;
          if (v === 1) {
            // rocky terrain — brownish, with subtle banding by depth
            const gy = Math.floor(i / gw);
            const band = (gy % 3);
            const base = band === 0 ? [110, 80, 60] : band === 1 ? [90, 64, 48] : [76, 54, 40];
            img.data[o] = base[0]; img.data[o+1] = base[1]; img.data[o+2] = base[2]; img.data[o+3] = 255;
          } else {
            img.data[o+3] = 0;
          }
        }
        this.terrainCtx.putImageData(img, 0, 0);
        this.terrainDirty = false;
      }
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(this.terrainCv, 0, 0, gw, gh, 0, 0, gw * cs, gh * cs);
    }

    drawPlayer(ctx) {
      const p = this.player;
      const c = this.char;
      const form = c.forms[this.form];
      const W = this.cv.width;
      // aura when charging or transformed
      if (form.aura && (this.keys.charge || this.form > 0)) {
        ctx.save();
        const r = 26 + (this.keys.charge ? 8 : 0) + p.charge * 0.3;
        const g = ctx.createRadialGradient(p.x, p.y, 4, p.x, p.y, r);
        g.addColorStop(0, form.aura + 'cc');
        g.addColorStop(0.6, form.aura + '44');
        g.addColorStop(1, 'transparent');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
        // rising aura particles
        for (let i = 0; i < 5; i++) {
          const ang = -Math.PI/2 + (Math.random() - 0.5) * 1.4;
          ctx.fillStyle = form.aura;
          ctx.globalAlpha = 0.5;
          ctx.fillRect(p.x + Math.cos(ang) * 12 * Math.random() - 2, p.y + Math.random() * 10, 2, 4);
        }
        ctx.globalAlpha = 1;
        ctx.restore();
      }

      // body
      const flash = p.flashT > 0 && Math.floor(p.flashT / 3) % 2 === 0;
      const skin = flash ? '#ff3b3b' : c.skin;
      const hair = flash ? '#ff3b3b' : form.hair;
      const cx = p.x, cy = p.y;
      const face = p.face;
      // torso (gi)
      ctx.fillStyle = c.color;
      ctx.fillRect(cx - 8, cy - 4, 16, 18);
      // belt
      ctx.fillStyle = '#222';
      ctx.fillRect(cx - 8, cy + 8, 16, 3);
      // legs
      ctx.fillStyle = c.color;
      ctx.fillRect(cx - 7, cy + 12, 5, 10);
      ctx.fillRect(cx + 2, cy + 12, 5, 10);
      // boots
      ctx.fillStyle = '#ff8c2a';
      ctx.fillRect(cx - 8, cy + 20, 6, 3);
      ctx.fillRect(cx + 2, cy + 20, 6, 3);
      // arms
      ctx.fillStyle = c.color;
      ctx.fillRect(cx - 11, cy - 2, 4, 12);
      ctx.fillRect(cx + 7, cy - 2, 4, 12);
      // hands (skin)
      ctx.fillStyle = skin;
      ctx.fillRect(cx - 11, cy + 9, 4, 3);
      ctx.fillRect(cx + 7, cy + 9, 4, 3);
      // head
      ctx.fillStyle = skin;
      ctx.fillRect(cx - 6, cy - 16, 12, 12);
      // eyes (face direction)
      ctx.fillStyle = '#111';
      ctx.fillRect(cx + (face > 0 ? 1 : -4), cy - 12, 3, 3);
      // hair — spiky
      ctx.fillStyle = hair;
      this.drawHair(ctx, cx, cy - 16, form, c);

      // power level tag floating above
      ctx.fillStyle = 'rgba(249,248,113,0.85)';
      ctx.font = "7px 'Press Start 2P', monospace";
      ctx.textAlign = 'center';
      ctx.shadowColor = '#f9f871'; ctx.shadowBlur = 4;
      ctx.fillText(fmtPL(this.effPL()), cx, cy - 24);
      ctx.shadowBlur = 0;
    }

    drawHair(ctx, cx, top, form, c) {
      const hair = form.hair;
      ctx.fillStyle = hair;
      if (c.tag === 'goku' || c.tag === 'vegeta' || c.tag === 'gohan' || c.tag === 'trunks') {
        if (form.longHair) {
          // SSJ3 long spikes downward
          ctx.fillRect(cx - 8, top + 6, 16, 8);
          ctx.beginPath();
          ctx.moveTo(cx - 8, top + 10); ctx.lineTo(cx - 12, top + 22); ctx.lineTo(cx - 4, top + 12); ctx.fill();
          ctx.beginPath();
          ctx.moveTo(cx + 8, top + 10); ctx.lineTo(cx + 12, top + 22); ctx.lineTo(cx + 4, top + 12); ctx.fill();
        }
        // upward spikes (SSJ)
        const spikeCount = 5;
        for (let i = 0; i < spikeCount; i++) {
          const sx = cx - 8 + i * 4;
          const sh = 6 + (form.plMul >= 50 ? 6 : 0);
          ctx.beginPath();
          ctx.moveTo(sx, top + 6);
          ctx.lineTo(sx + 2, top - sh);
          ctx.lineTo(sx + 4, top + 6);
          ctx.fill();
        }
        ctx.fillRect(cx - 8, top + 4, 16, 4);
      } else if (c.tag === 'piccolo') {
        // turban + antennas
        ctx.fillStyle = '#e8e8f0';
        ctx.fillRect(cx - 8, top - 2, 16, 6);
        ctx.fillRect(cx - 8, top + 2, 16, 3);
        ctx.fillStyle = form.hair; // pink antennas
        ctx.fillRect(cx - 9, top + 8, 2, 6);
        ctx.fillRect(cx + 7, top + 8, 2, 6);
      }
    }

    drawEnemy(ctx, en) {
      const flash = en.hitFlash > 0;
      const color = flash ? '#fff' : en.color;
      const x = en.x, y = en.y;
      // body
      ctx.fillStyle = color;
      ctx.fillRect(x - en.size/2, y - en.size/2, en.size, en.size);
      // head
      ctx.fillStyle = flash ? '#fff' : en.color;
      ctx.fillRect(x - en.size/3, y - en.size, en.size*0.66, en.size*0.6);
      // eyes (red glow for menace)
      ctx.fillStyle = '#ff3b3b';
      ctx.shadowColor = '#ff3b3b'; ctx.shadowBlur = 4;
      ctx.fillRect(x + (en.face > 0 ? 1 : -4), y - en.size + 3, 2, 2);
      ctx.fillRect(x + (en.face > 0 ? 4 : -7), y - en.size + 3, 2, 2);
      ctx.shadowBlur = 0;
      // aura for bosses
      if (en.boss) {
        ctx.save();
        const g = ctx.createRadialGradient(x, y, 4, x, y, en.size + 14);
        g.addColorStop(0, en.color + '88');
        g.addColorStop(1, 'transparent');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, en.size + 14, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
      // hp bar above
      const w = en.size + 8;
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(x - w/2, y - en.size - 12, w, 4);
      ctx.fillStyle = en.boss ? '#ff2d95' : '#39ff14';
      ctx.fillRect(x - w/2, y - en.size - 12, w * Math.max(0, en.hp / en.maxHp), 4);
      // PL label
      ctx.fillStyle = 'rgba(0,255,242,0.7)';
      ctx.font = "6px 'Press Start 2P', monospace";
      ctx.textAlign = 'center';
      ctx.fillText(fmtPL(en.pl), x, y - en.size - 16);
    }

    loop() {
      const now = performance.now();
      const dt = Math.min(50, now - this.lastT);
      this.lastT = now;
      this.update(dt);
      this.draw();
      this.raf = requestAnimationFrame(() => this.loop());
    }
  }

  customElements.define('dragon-power', DragonPower);
})();
