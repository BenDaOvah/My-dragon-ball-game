// Wix Custom Element — save as public/custom-elements/block-stacker.js — tag: block-stacker

(function () {
  const STYLE = `
    :host {
      display: block;
      width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --arcade-neon-purple: #b14dff;
      --arcade-neon-red: #ff3b3b;
      --arcade-neon-orange: #ff8c2a;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body);
      color: #e8e8f0;
    }
    * { box-sizing: border-box; }
    .wrap {
      position: relative;
      background: var(--arcade-bg);
      border: 2px solid var(--arcade-neon-cyan);
      border-radius: 10px;
      box-shadow: 0 0 14px rgba(0,255,242,0.55), inset 0 0 30px rgba(0,255,242,0.06);
      padding: 14px;
      overflow: hidden;
    }
    .wrap::after {
      content: "";
      position: absolute; inset: 0;
      pointer-events: none;
      background: repeating-linear-gradient(
        to bottom,
        rgba(255,255,255,0.04) 0px,
        rgba(255,255,255,0.04) 1px,
        transparent 1px,
        transparent 3px
      );
      mix-blend-mode: overlay;
      z-index: 5;
    }
    .head {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 10px; gap: 10px;
    }
    .title {
      font-family: var(--font-pixel);
      font-size: 13px; letter-spacing: 1px;
      color: var(--arcade-neon-pink);
      text-shadow: 0 0 8px rgba(255,45,149,0.8);
    }
    .hint {
      font-size: 11px; color: #9aa; font-family: var(--font-body);
    }
    .stage {
      display: flex; gap: 12px; align-items: flex-start;
    }
    .board-col { position: relative; }
    canvas.board {
      display: block;
      background: #05050c;
      border: 2px solid #2a2a3d;
      border-radius: 6px;
      image-rendering: pixelated;
      max-width: 100%;
      height: auto;
    }
    .side {
      display: flex; flex-direction: column; gap: 10px;
      min-width: 96px;
    }
    .panel {
      background: var(--arcade-panel);
      border: 1px solid #2a2a3d;
      border-radius: 6px;
      padding: 8px;
    }
    .panel-label {
      font-family: var(--font-pixel);
      font-size: 8px; letter-spacing: .5px;
      color: var(--arcade-neon-cyan);
      margin-bottom: 6px;
      text-shadow: 0 0 6px rgba(0,255,242,0.5);
    }
    .panel-val {
      font-family: var(--font-pixel);
      font-size: 14px; color: var(--arcade-neon-yellow);
      text-shadow: 0 0 8px rgba(249,248,113,0.6);
    }
    canvas.next {
      display: block;
      background: #05050c;
      border: 1px solid #2a2a3d;
      border-radius: 4px;
      image-rendering: pixelated;
    }
    .touch {
      display: none;
      grid-template-columns: repeat(4, 1fr);
      gap: 6px;
      margin-top: 12px;
    }
    .tbtn {
      font-family: var(--font-pixel);
      font-size: 11px;
      padding: 12px 0;
      background: var(--arcade-panel);
      color: var(--arcade-neon-cyan);
      border: 1px solid var(--arcade-neon-cyan);
      border-radius: 6px;
      box-shadow: 0 0 8px rgba(0,255,242,0.3);
      cursor: pointer;
      touch-action: manipulation;
      user-select: none;
    }
    .tbtn:active { background: rgba(0,255,242,0.18); }
    .tbtn.pink { color: var(--arcade-neon-pink); border-color: var(--arcade-neon-pink); box-shadow: 0 0 8px rgba(255,45,149,0.3);}
    .overlay {
      position: absolute; inset: 0;
      display: none;
      align-items: center; justify-content: center;
      background: rgba(5,5,12,0.86);
      z-index: 10;
      border-radius: 10px;
    }
    .overlay.show { display: flex; }
    .ocard {
      text-align: center; padding: 20px 24px;
    }
    .otitle {
      font-family: var(--font-pixel); font-size: 18px;
      color: var(--arcade-neon-pink);
      text-shadow: 0 0 12px rgba(255,45,149,0.9);
      margin-bottom: 12px;
    }
    .oscore {
      font-family: var(--font-pixel); font-size: 13px;
      color: var(--arcade-neon-yellow);
      text-shadow: 0 0 8px rgba(249,248,113,0.7);
      margin-bottom: 4px;
    }
    .ohs {
      font-size: 11px; color: #9aa; margin-bottom: 14px;
    }
    .obtn {
      font-family: var(--font-pixel); font-size: 10px;
      padding: 12px 18px;
      background: transparent;
      color: var(--arcade-neon-green);
      border: 2px solid var(--arcade-neon-green);
      border-radius: 6px;
      box-shadow: 0 0 12px rgba(57,255,20,0.4);
      cursor: pointer;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .obtn:active { background: rgba(57,255,20,0.15); }
    @media (max-width: 520px) {
      .stage { flex-direction: column; }
      .side { flex-direction: row; width: 100%; }
      .side .panel { flex: 1; }
      .panel.next-panel { display:none; }
    }
  `;

  // Tetromino definitions — each is a list of rotation states (4x4 matrices)
  const COLS = 10, ROWS = 20;
  const COLORS = {
    I: '#00fff2',
    O: '#f9f871',
    T: '#ff2d95',
    S: '#39ff14',
    Z: '#ff3b3b',
    J: '#b14dff',
    L: '#ff8c2a'
  };
  const PIECES = {
    I: [
      [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]],
      [[0,0,1,0],[0,0,1,0],[0,0,1,0],[0,0,1,0]],
      [[0,0,0,0],[0,0,0,0],[1,1,1,1],[0,0,0,0]],
      [[0,1,0,0],[0,1,0,0],[0,1,0,0],[0,1,0,0]]
    ],
    O: [
      [[1,1],[1,1]]
    ],
    T: [
      [[0,1,0],[1,1,1],[0,0,0]],
      [[0,1,0],[0,1,1],[0,1,0]],
      [[0,0,0],[1,1,1],[0,1,0]],
      [[0,1,0],[1,1,0],[0,1,0]]
    ],
    S: [
      [[0,1,1],[1,1,0],[0,0,0]],
      [[0,1,0],[0,1,1],[0,0,1]],
      [[0,0,0],[0,1,1],[1,1,0]],
      [[1,0,0],[1,1,0],[0,1,0]]
    ],
    Z: [
      [[1,1,0],[0,1,1],[0,0,0]],
      [[0,0,1],[0,1,1],[0,1,0]],
      [[0,0,0],[1,1,0],[0,1,1]],
      [[0,1,0],[1,1,0],[1,0,0]]
    ],
    J: [
      [[1,0,0],[1,1,1],[0,0,0]],
      [[0,1,1],[0,1,0],[0,1,0]],
      [[0,0,0],[1,1,1],[0,0,1]],
      [[0,1,0],[0,1,0],[1,1,0]]
    ],
    L: [
      [[0,0,1],[1,1,1],[0,0,0]],
      [[0,1,0],[0,1,0],[0,1,1]],
      [[0,0,0],[1,1,1],[1,0,0]],
      [[1,1,0],[0,1,0],[0,1,0]]
    ]
  };
  const TYPES = ['I','O','T','S','Z','J','L'];
  const HS_KEY = 'arcade-highscore-block-stacker';

  class BlockStacker extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
    }
    connectedCallback() {
      const root = this.shadowRoot;
      root.innerHTML = `
        <style>${STYLE}</style>
        <div class="wrap" id="wrap">
          <div class="head">
            <div class="title">BLOCK STACKER</div>
            <div class="hint">← → move · ↑/W rotate · ↓ soft · SPACE hard drop</div>
          </div>
          <div class="stage">
            <div class="board-col">
              <canvas class="board" id="board" width="300" height="600"></canvas>
              <div class="overlay" id="overlay">
                <div class="ocard">
                  <div class="otitle" id="otitle">GAME OVER</div>
                  <div class="oscore" id="oscore">SCORE 0</div>
                  <div class="ohs" id="ohs">BEST 0</div>
                  <button class="obtn" id="restart">PLAY AGAIN</button>
                </div>
              </div>
            </div>
            <div class="side">
              <div class="panel">
                <div class="panel-label">SCORE</div>
                <div class="panel-val" id="score">0</div>
              </div>
              <div class="panel">
                <div class="panel-label">LINES</div>
                <div class="panel-val" id="lines">0</div>
              </div>
              <div class="panel">
                <div class="panel-label">LEVEL</div>
                <div class="panel-val" id="level">1</div>
              </div>
              <div class="panel next-panel">
                <div class="panel-label">NEXT</div>
                <canvas class="next" id="next" width="96" height="72"></canvas>
              </div>
              <div class="panel">
                <div class="panel-label">BEST</div>
                <div class="panel-val" id="best">0</div>
              </div>
            </div>
          </div>
          <div class="touch" id="touch">
            <button class="tbtn" data-act="left">◀</button>
            <button class="tbtn" data-act="rotate">↻</button>
            <button class="tbtn pink" data-act="drop">⤓</button>
            <button class="tbtn" data-act="right">▶</button>
          </div>
        </div>
      `;

      this.board = root.getElementById('board');
      this.ctx = this.board.getContext('2d');
      this.nextCv = root.getElementById('next');
      this.nctx = this.nextCv.getContext('2d');
      this.scoreEl = root.getElementById('score');
      this.linesEl = root.getElementById('lines');
      this.levelEl = root.getElementById('level');
      this.bestEl = root.getElementById('best');
      this.overlay = root.getElementById('overlay');
      this.otitle = root.getElementById('otitle');
      this.oscore = root.getElementById('oscore');
      this.ohs = root.getElementById('ohs');
      this.touchWrap = root.getElementById('touch');

      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      if (isTouch) this.touchWrap.style.display = 'grid';

      this.cell = 30;
      this.resize();
      this.highScore = this.loadHighScore();
      this.bestEl.textContent = this.highScore;
      this.reset();

      // controls
      this._onKey = (e) => this.onKey(e);
      this._onResize = () => this.resize();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);

      root.getElementById('restart').addEventListener('click', () => this.reset(true));
      this.touchWrap.addEventListener('click', (e) => {
        const btn = e.target.closest('.tbtn');
        if (!btn) return;
        this.handleAction(btn.dataset.act);
      });

      this.loop();
    }

    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      cancelAnimationFrame(this.raf);
      clearTimeout(this.dropTimer);
    }

    resize() {
      const w = this.clientWidth || 300;
      // board is 10 wide. pick a cell size that fits width but cap height
      let cell = Math.floor(w / 12);
      if (cell < 16) cell = 16;
      if (cell > 34) cell = 34;
      this.cell = cell;
      this.board.width = COLS * cell;
      this.board.height = ROWS * cell;
      // next canvas
      this.nextCv.width = cell * 4;
      this.nextCv.height = cell * 3;
      this.draw();
      this.drawNext();
    }

    loadHighScore() {
      try { return parseInt(localStorage.getItem(HS_KEY) || '0', 10) || 0; }
      catch (e) { return 0; }
    }
    saveHighScore(v) {
      try { localStorage.setItem(HS_KEY, String(v)); } catch (e) {}
    }

    reset(restart) {
      this.grid = Array.from({ length: ROWS }, () => Array(COLS).fill(null));
      this.bag = [];
      this.next = this.drawFromBag();
      this.score = 0;
      this.lines = 0;
      this.level = 1;
      this.over = false;
      this.paused = false;
      this.lastDrop = performance.now();
      this.spawn();
      this.updateHud();
      this.overlay.classList.remove('show');
      if (restart) this.loop();
    }

    drawFromBag() {
      if (this.bag.length === 0) {
        this.bag = TYPES.slice();
        // shuffle
        for (let i = this.bag.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [this.bag[i], this.bag[j]] = [this.bag[j], this.bag[i]];
        }
      }
      return this.bag.pop();
    }

    spawn() {
      const type = this.next;
      this.next = this.drawFromBag();
      this.cur = {
        type,
        rot: 0,
        shape: PIECES[type][0],
        x: type === 'O' ? 4 : 3,
        y: 0
      };
      // game over if spawn collides
      if (this.collides(this.cur, 0, 0, 0)) {
        this.endGame();
      }
      this.drawNext();
    }

    collides(piece, dx, dy, drot) {
      const shape = PIECES[piece.type][(piece.rot + drot) % PIECES[piece.type].length];
      for (let r = 0; r < shape.length; r++) {
        for (let c = 0; c < shape[r].length; c++) {
          if (!shape[r][c]) continue;
          const nx = piece.x + c + dx;
          const ny = piece.y + r + dy;
          if (nx < 0 || nx >= COLS || ny >= ROWS) return true;
          if (ny >= 0 && this.grid[ny][nx]) return true;
        }
      }
      return false;
    }

    move(dx, dy) {
      if (this.over) return;
      if (!this.collides(this.cur, dx, dy, 0)) {
        this.cur.x += dx;
        this.cur.y += dy;
        return true;
      }
      return false;
    }

    rotate() {
      if (this.over) return;
      // simple wall kicks
      const kicks = [0, -1, 1, -2, 2];
      for (const k of kicks) {
        if (!this.collides(this.cur, k, 0, 1)) {
          this.cur.x += k;
          this.cur.rot = (this.cur.rot + 1) % PIECES[this.cur.type].length;
          this.cur.shape = PIECES[this.cur.type][this.cur.rot];
          return;
        }
      }
    }

    softDrop() {
      if (this.over) return;
      if (this.move(0, 1)) {
        this.score += 1;
        this.updateHud();
      } else {
        this.lock();
      }
      this.lastDrop = performance.now();
    }

    hardDrop() {
      if (this.over) return;
      let dist = 0;
      while (this.move(0, 1)) dist++;
      this.score += dist * 2;
      this.lock();
      this.updateHud();
    }

    lock() {
      const shape = this.cur.shape;
      for (let r = 0; r < shape.length; r++) {
        for (let c = 0; c < shape[r].length; c++) {
          if (shape[r][c]) {
            const x = this.cur.x + c, y = this.cur.y + r;
            if (y >= 0 && y < ROWS && x >= 0 && x < COLS) {
              this.grid[y][x] = this.cur.type;
            }
          }
        }
      }
      this.clearLines();
      this.spawn();
    }

    clearLines() {
      let cleared = 0;
      for (let r = ROWS - 1; r >= 0; r--) {
        if (this.grid[r].every((v) => v)) {
          this.grid.splice(r, 1);
          this.grid.unshift(Array(COLS).fill(null));
          cleared++;
          r++;
        }
      }
      if (cleared > 0) {
        const points = [0, 100, 300, 500, 800][cleared] * this.level;
        this.score += points;
        this.lines += cleared;
        const newLevel = Math.floor(this.lines / 10) + 1;
        if (newLevel > this.level) this.level = newLevel;
        this.updateHud();
      }
    }

    dropSpeed() {
      // ms per drop step
      return Math.max(80, 800 - (this.level - 1) * 70);
    }

    handleAction(act) {
      if (this.over) return;
      switch (act) {
        case 'left': this.move(-1, 0); break;
        case 'right': this.move(1, 0); break;
        case 'rotate': this.rotate(); break;
        case 'down': this.softDrop(); break;
        case 'drop': this.hardDrop(); break;
      }
      this.draw();
    }

    onKey(e) {
      const k = e.key.toLowerCase();
      const map = {
        arrowleft: 'left', a: 'left',
        arrowright: 'right', d: 'right',
        arrowup: 'rotate', w: 'rotate',
        arrowdown: 'down', s: 'down',
        ' ': 'drop'
      };
      if (map[k]) {
        e.preventDefault();
        this.handleAction(map[k]);
      }
    }

    updateHud() {
      this.scoreEl.textContent = this.score;
      this.linesEl.textContent = this.lines;
      this.levelEl.textContent = this.level;
    }

    endGame() {
      this.over = true;
      cancelAnimationFrame(this.raf);
      if (this.score > this.highScore) {
        this.highScore = this.score;
        this.saveHighScore(this.highScore);
      }
      this.bestEl.textContent = this.highScore;
      this.otitle.textContent = 'GAME OVER';
      this.oscore.textContent = 'SCORE ' + this.score;
      this.ohs.textContent = 'BEST ' + this.highScore;
      this.overlay.classList.add('show');
      this.dispatchEvent(new CustomEvent('game-over', {
        detail: { game: 'block-stacker', score: this.score },
        bubbles: true, composed: true
      }));
    }

    draw() {
      const ctx = this.ctx, cell = this.cell;
      ctx.fillStyle = '#05050c';
      ctx.fillRect(0, 0, this.board.width, this.board.height);
      // grid lines
      ctx.strokeStyle = 'rgba(255,255,255,0.04)';
      ctx.lineWidth = 1;
      for (let x = 0; x <= COLS; x++) {
        ctx.beginPath(); ctx.moveTo(x * cell, 0); ctx.lineTo(x * cell, ROWS * cell); ctx.stroke();
      }
      for (let y = 0; y <= ROWS; y++) {
        ctx.beginPath(); ctx.moveTo(0, y * cell); ctx.lineTo(COLS * cell, y * cell); ctx.stroke();
      }
      // locked blocks
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          if (this.grid[r][c]) this.drawCell(ctx, c, r, COLORS[this.grid[r][c]], cell);
        }
      }
      // ghost piece
      if (this.cur && !this.over) {
        let gy = 0;
        while (!this.collides(this.cur, 0, gy + 1, 0)) gy++;
        const shape = this.cur.shape;
        for (let r = 0; r < shape.length; r++) {
          for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c]) {
              this.drawCell(ctx, this.cur.x + c, this.cur.y + r + gy, COLORS[this.cur.type], cell, true);
            }
          }
        }
        // current piece
        for (let r = 0; r < shape.length; r++) {
          for (let c = 0; c < shape[r].length; c++) {
            if (shape[r][c]) {
              this.drawCell(ctx, this.cur.x + c, this.cur.y + r, COLORS[this.cur.type], cell);
            }
          }
        }
      }
    }

    drawCell(ctx, x, y, color, cell, ghost) {
      if (y < 0) return;
      const px = x * cell, py = y * cell;
      if (ghost) {
        ctx.fillStyle = 'rgba(255,255,255,0.08)';
        ctx.fillRect(px + 1, py + 1, cell - 2, cell - 2);
        ctx.strokeStyle = color;
        ctx.globalAlpha = 0.4;
        ctx.lineWidth = 1;
        ctx.strokeRect(px + 1.5, py + 1.5, cell - 3, cell - 3);
        ctx.globalAlpha = 1;
        return;
      }
      // fill
      ctx.fillStyle = color;
      ctx.fillRect(px + 1, py + 1, cell - 2, cell - 2);
      // inner highlight
      ctx.fillStyle = 'rgba(255,255,255,0.25)';
      ctx.fillRect(px + 2, py + 2, cell - 4, 3);
      // glow
      ctx.shadowColor = color;
      ctx.shadowBlur = 8;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.strokeRect(px + 1.5, py + 1.5, cell - 3, cell - 3);
      ctx.shadowBlur = 0;
    }

    drawNext() {
      const ctx = this.nctx, cell = this.cell;
      ctx.fillStyle = '#05050c';
      ctx.fillRect(0, 0, this.nextCv.width, this.nextCv.height);
      if (!this.next) return;
      const shape = PIECES[this.next][0];
      const color = COLORS[this.next];
      // center
      const w = shape[0].length, h = shape.length;
      const offX = Math.floor((4 - w) / 2);
      const offY = Math.floor((3 - h) / 2);
      for (let r = 0; r < h; r++) {
        for (let c = 0; c < w; c++) {
          if (shape[r][c]) this.drawCell(ctx, c + offX, r + offY, color, cell);
        }
      }
    }

    loop() {
      if (this.over) return;
      const now = performance.now();
      if (now - this.lastDrop > this.dropSpeed()) {
        if (!this.move(0, 1)) this.lock();
        this.lastDrop = now;
        this.draw();
      } else {
        this.draw();
      }
      this.raf = requestAnimationFrame(() => this.loop());
    }
  }

  customElements.define('block-stacker', BlockStacker);
})();
