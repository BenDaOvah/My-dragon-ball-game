// Wix Custom Element — save as public/custom-elements/pixel-runner.js — tag: pixel-runner

(function () {
  const STYLE = `
    :host {
      display: block; width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body); color: #e8e8f0;
    }
    * { box-sizing: border-box; }
    .wrap {
      position: relative; background: var(--arcade-bg);
      border: 2px solid var(--arcade-neon-cyan); border-radius: 10px;
      box-shadow: 0 0 14px rgba(0,255,242,0.5), inset 0 0 30px rgba(0,255,242,0.05);
      padding: 14px; overflow: hidden;
    }
    .wrap::after {
      content: ""; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay; z-index: 5;
    }
    .head { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; gap:10px; }
    .title { font-family: var(--font-pixel); font-size:13px; letter-spacing:1px; color: var(--arcade-neon-cyan); text-shadow:0 0 8px rgba(0,255,242,0.8); }
    .hint { font-size:11px; color:#9aa; }
    .bar { display:flex; gap:10px; margin-bottom:10px; }
    .stat { background: var(--arcade-panel); border:1px solid #2a2a3d; border-radius:6px; padding:6px 10px; flex:1; min-width:70px; }
    .stat .l { font-family: var(--font-pixel); font-size:8px; color:#7a7a8c; letter-spacing:.5px; }
    .stat .v { font-family: var(--font-pixel); font-size:14px; color: var(--arcade-neon-yellow); text-shadow:0 0 6px rgba(249,248,113,0.5); }
    .stat.best .v { color: var(--arcade-neon-green); text-shadow:0 0 6px rgba(57,255,20,0.5); }
    canvas { display:block; width:100%; height:auto; background:#05050c; border:2px solid #2a2a3d; border-radius:6px; image-rendering:pixelated; touch-action:none; }
    .touch { display:none; margin-top:12px; }
    .tbtn {
      font-family: var(--font-pixel); font-size:11px; padding:16px 0; width:100%;
      background: var(--arcade-panel); color: var(--arcade-neon-cyan);
      border:1px solid var(--arcade-neon-cyan); border-radius:6px;
      box-shadow:0 0 8px rgba(0,255,242,0.3); cursor:pointer; user-select:none; touch-action:manipulation;
    }
    .tbtn:active { background: rgba(0,255,242,0.18); }
    .overlay { position:absolute; inset:0; display:none; align-items:center; justify-content:center; background:rgba(5,5,12,0.86); z-index:10; border-radius:10px; }
    .overlay.show { display:flex; }
    .ocard { text-align:center; padding:20px 24px; }
    .otitle { font-family: var(--font-pixel); font-size:18px; color: var(--arcade-neon-pink); text-shadow:0 0 12px rgba(255,45,149,0.9); margin-bottom:12px; }
    .oscore { font-family: var(--font-pixel); font-size:13px; color: var(--arcade-neon-yellow); text-shadow:0 0 8px rgba(249,248,113,0.7); margin-bottom:4px; }
    .ohs { font-size:11px; color:#9aa; margin-bottom:14px; }
    .obtn { font-family: var(--font-pixel); font-size:10px; padding:12px 18px; background:transparent; color: var(--arcade-neon-green); border:2px solid var(--arcade-neon-green); border-radius:6px; box-shadow:0 0 12px rgba(57,255,20,0.4); cursor:pointer; text-transform:uppercase; letter-spacing:1px; }
    .obtn:active { background: rgba(57,255,20,0.15); }
  `;

  const HS_KEY = 'arcade-highscore-pixel-runner';

  class PixelRunner extends HTMLElement {
    constructor() { super(); this.attachShadow({ mode: 'open' }); }
    connectedCallback() {
      const root = this.shadowRoot;
      root.innerHTML = `
        <style>${STYLE}</style>
        <div class="wrap" id="wrap">
          <div class="head">
            <div class="title">PIXEL RUNNER</div>
            <div class="hint">SPACE / ↑ / W · tap to jump</div>
          </div>
          <div class="bar">
            <div class="stat"><div class="l">DISTANCE</div><div class="v" id="score">0</div></div>
            <div class="stat best"><div class="l">BEST</div><div class="v" id="best">0</div></div>
          </div>
          <canvas id="cv" width="640" height="240"></canvas>
          <div class="touch" id="touch">
            <button class="tbtn" id="jumpbtn">▲ JUMP</button>
          </div>
          <div class="overlay" id="overlay">
            <div class="ocard">
              <div class="otitle">CRASHED</div>
              <div class="oscore" id="oscore">SCORE 0</div>
              <div class="ohs" id="ohs">BEST 0</div>
              <button class="obtn" id="restart">PLAY AGAIN</button>
            </div>
          </div>
        </div>
      `;
      this.cv = root.getElementById('cv');
      this.ctx = this.cv.getContext('2d');
      this.scoreEl = root.getElementById('score');
      this.bestEl = root.getElementById('best');
      this.overlay = root.getElementById('overlay');
      this.oscore = root.getElementById('oscore');
      this.ohs = root.getElementById('ohs');
      this.touchWrap = root.getElementById('touch');

      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      if (isTouch) this.touchWrap.style.display = 'block';

      this._onKey = (e) => this.onKey(e);
      this._onResize = () => this.resize();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);
      this._onTap = () => this.jump();
      this.cv.addEventListener('pointerdown', this._onTap);
      root.getElementById('jumpbtn').addEventListener('click', () => this.jump());
      root.getElementById('restart').addEventListener('click', () => this.reset(true));

      this.highScore = this.loadHighScore();
      this.bestEl.textContent = this.highScore;
      this.reset();
      this.loop();
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      this.cv.removeEventListener('pointerdown', this._onTap);
      cancelAnimationFrame(this.raf);
    }
    resize() {
      const w = this.clientWidth || 640;
      const ratio = 640 / 240;
      this.cv.width = w; this.cv.height = w / ratio;
      this.scale = this.cv.width / 640;
    }
    loadHighScore() { try { return parseInt(localStorage.getItem(HS_KEY) || '0', 10) || 0; } catch (e) { return 0; } }
    saveHighScore(v) { try { localStorage.setItem(HS_KEY, String(v)); } catch (e) {} }

    reset(restart) {
      this.W = 640; this.H = 240;
      this.groundY = 190;
      this.playerX = 80;
      this.playerY = this.groundY;
      this.playerVY = 0;
      this.onGround = true;
      this.speed = 4;
      this.distance = 0;
      this.score = 0;
      this.over = false;
      this.obstacles = [];
      this.particles = [];
      this.spawnTimer = 60;
      this.bgOffset = 0;
      this.updateHud();
      this.overlay.classList.remove('show');
      if (restart) this.loop();
    }
    jump() {
      if (this.over) return;
      if (this.onGround) {
        this.playerVY = -11;
        this.onGround = false;
      }
    }
    onKey(e) {
      const k = e.key.toLowerCase();
      if (k === ' ' || k === 'arrowup' || k === 'w') { e.preventDefault(); this.jump(); }
    }
    updateHud() {
      this.scoreEl.textContent = this.score;
    }
    spawnObstacle() {
      // varied obstacles: cactus (tall/narrow) or block (wide/short) or floating (must not jump)
      const types = [
        { w: 18, h: 36, color: '#ff2d95', y: this.groundY - 36 },
        { w: 18, h: 48, color: '#ff3b3b', y: this.groundY - 48 },
        { w: 36, h: 26, color: '#b14dff', y: this.groundY - 26 }
      ];
      const t = types[Math.floor(Math.random() * types.length)];
      this.obstacles.push({ x: this.W + 10, y: t.y, w: t.w, h: t.h, color: t.color });
    }
    update() {
      if (this.over) return;
      // speed up gradually
      this.speed = Math.min(11, 4 + this.distance / 600);
      this.distance += this.speed;
      this.score = Math.floor(this.distance / 5);
      this.updateHud();

      // physics
      this.playerVY += 0.6; // gravity
      this.playerY += this.playerVY;
      if (this.playerY >= this.groundY) {
        this.playerY = this.groundY;
        this.playerVY = 0;
        this.onGround = true;
      }
      // running dust
      if (this.onGround && Math.random() < 0.4) {
        this.particles.push({ x: this.playerX - 4, y: this.groundY, vx: -this.speed * 0.5, life: 20, color: '#00fff2' });
      }

      // obstacles
      this.spawnTimer--;
      if (this.spawnTimer <= 0) {
        this.spawnObstacle();
        // procedural spacing tied to speed so it stays fair
        const gap = 60 + Math.random() * 80 + (12 - this.speed) * 6;
        this.spawnTimer = Math.max(40, gap);
      }
      for (const o of this.obstacles) o.x -= this.speed;
      this.obstacles = this.obstacles.filter((o) => o.x + o.w > -20);

      // particles
      for (const p of this.particles) { p.x += p.vx; p.life--; }
      this.particles = this.particles.filter((p) => p.life > 0);

      this.bgOffset = (this.bgOffset + this.speed) % 64;

      // collision: player is a 22x26 box centered at playerX, playerY-26..playerY
      const px = this.playerX - 11, py = this.playerY - 26, pw = 22, ph = 26;
      for (const o of this.obstacles) {
        if (px < o.x + o.w && px + pw > o.x && py < o.y + o.h && py + ph > o.y) {
          this.endGame();
          return;
        }
      }
    }
    endGame() {
      this.over = true;
      cancelAnimationFrame(this.raf);
      if (this.score > this.highScore) { this.highScore = this.score; this.saveHighScore(this.highScore); }
      this.bestEl.textContent = this.highScore;
      this.oscore.textContent = 'SCORE ' + this.score;
      this.ohs.textContent = 'BEST ' + this.highScore;
      this.overlay.classList.add('show');
      this.dispatchEvent(new CustomEvent('game-over', {
        detail: { game: 'pixel-runner', score: this.score },
        bubbles: true, composed: true
      }));
    }
    draw() {
      const ctx = this.ctx, s = this.scale || 1;
      ctx.fillStyle = '#05050c';
      ctx.fillRect(0, 0, this.cv.width, this.cv.height);
      ctx.save();
      ctx.scale(s, s);
      // stars / parallax dots
      ctx.fillStyle = 'rgba(0,255,242,0.25)';
      for (let i = 0; i < 30; i++) {
        const x = (i * 53 - this.bgOffset * 0.3) % this.W;
        const y = (i * 37) % 140;
        ctx.fillRect((x + this.W) % this.W, y, 2, 2);
      }
      // ground line
      ctx.strokeStyle = '#00fff2';
      ctx.shadowColor = '#00fff2'; ctx.shadowBlur = 8;
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, this.groundY + 6); ctx.lineTo(this.W, this.groundY + 6); ctx.stroke();
      ctx.shadowBlur = 0;
      // ground dashes
      ctx.strokeStyle = 'rgba(0,255,242,0.3)';
      ctx.setLineDash([12, 12]);
      ctx.lineDashOffset = -this.bgOffset;
      ctx.beginPath(); ctx.moveTo(0, this.groundY + 14); ctx.lineTo(this.W, this.groundY + 14); ctx.stroke();
      ctx.setLineDash([]);

      // particles
      for (const p of this.particles) {
        ctx.globalAlpha = p.life / 20;
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y - 2, 3, 3);
      }
      ctx.globalAlpha = 1;

      // obstacles
      for (const o of this.obstacles) {
        ctx.shadowColor = o.color; ctx.shadowBlur = 12;
        ctx.fillStyle = o.color;
        ctx.fillRect(o.x, o.y, o.w, o.h);
        ctx.shadowBlur = 0;
        ctx.fillStyle = 'rgba(255,255,255,0.2)';
        ctx.fillRect(o.x, o.y, o.w, 3);
      }

      // player (pixel runner) — a neon cyan character
      const px = this.playerX, py = this.playerY;
      ctx.shadowColor = '#00fff2'; ctx.shadowBlur = 14;
      ctx.fillStyle = '#00fff2';
      // body
      ctx.fillRect(px - 9, py - 26, 18, 16);
      // head
      ctx.fillRect(px - 7, py - 40, 14, 12);
      // legs (animate when on ground)
      const step = this.onGround ? Math.floor(this.distance / 6) % 2 : 0;
      ctx.fillRect(px - 9, py - 10, 6, 10 + step * 2);
      ctx.fillRect(px + 3, py - 10, 6, 10 + (1 - step) * 2);
      ctx.shadowBlur = 0;
      // eye
      ctx.fillStyle = '#05050c';
      ctx.fillRect(px + 1, py - 36, 3, 3);

      ctx.restore();
    }
    loop() {
      if (this.over) return;
      this.update(); this.draw();
      this.raf = requestAnimationFrame(() => this.loop());
    }
  }
  customElements.define('pixel-runner', PixelRunner);
})();
