// Wix Custom Element — save as public/custom-elements/brick-blaster.js — tag: brick-blaster

(function () {
  const STYLE = `
    :host {
      display: block; width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --arcade-neon-purple: #b14dff;
      --arcade-neon-orange: #ff8c2a;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body); color: #e8e8f0;
    }
    * { box-sizing: border-box; }
    .wrap {
      position: relative; background: var(--arcade-bg);
      border: 2px solid var(--arcade-neon-yellow); border-radius: 10px;
      box-shadow: 0 0 14px rgba(249,248,113,0.45), inset 0 0 30px rgba(249,248,113,0.05);
      padding: 14px; overflow: hidden;
    }
    .wrap::after {
      content: ""; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay; z-index: 5;
    }
    .head { display:flex; align-items:center; justify-content:space-between; margin-bottom:10px; gap:10px; }
    .title { font-family: var(--font-pixel); font-size:13px; letter-spacing:1px; color: var(--arcade-neon-yellow); text-shadow:0 0 8px rgba(249,248,113,0.8); }
    .hint { font-size:11px; color:#9aa; }
    .bar { display:flex; gap:10px; margin-bottom:10px; flex-wrap:wrap; }
    .stat { background: var(--arcade-panel); border:1px solid #2a2a3d; border-radius:6px; padding:6px 10px; flex:1; min-width:70px; }
    .stat .l { font-family: var(--font-pixel); font-size:8px; color:#7a7a8c; letter-spacing:.5px; }
    .stat .v { font-family: var(--font-pixel); font-size:14px; color: var(--arcade-neon-cyan); text-shadow:0 0 6px rgba(0,255,242,0.5); }
    .stat.best .v { color: var(--arcade-neon-green); text-shadow:0 0 6px rgba(57,255,20,0.5); }
    canvas { display:block; width:100%; height:auto; background:#05050c; border:2px solid #2a2a3d; border-radius:6px; image-rendering:pixelated; touch-action:none; }
    .touch { display:none; margin-top:12px; }
    .touch .row { display:flex; gap:8px; }
    .tbtn {
      font-family: var(--font-pixel); font-size:11px; padding:14px 0; flex:1;
      background: var(--arcade-panel); color: var(--arcade-neon-yellow);
      border:1px solid var(--arcade-neon-yellow); border-radius:6px;
      box-shadow:0 0 8px rgba(249,248,113,0.25); cursor:pointer; user-select:none; touch-action:manipulation;
    }
    .tbtn:active { background: rgba(249,248,113,0.15); }
    .overlay { position:absolute; inset:0; display:none; align-items:center; justify-content:center; background:rgba(5,5,12,0.88); z-index:10; border-radius:10px; }
    .overlay.show { display:flex; }
    .ocard { text-align:center; padding:20px 24px; }
    .otitle { font-family: var(--font-pixel); font-size:18px; margin-bottom:12px; }
    .otitle.win { color: var(--arcade-neon-green); text-shadow:0 0 12px rgba(57,255,20,0.9); }
    .otitle.lose { color: var(--arcade-neon-pink); text-shadow:0 0 12px rgba(255,45,149,0.9); }
    .oscore { font-family: var(--font-pixel); font-size:13px; color: var(--arcade-neon-yellow); text-shadow:0 0 8px rgba(249,248,113,0.7); margin-bottom:4px; }
    .ohs { font-size:11px; color:#9aa; margin-bottom:14px; }
    .obtn { font-family: var(--font-pixel); font-size:10px; padding:12px 18px; background:transparent; color: var(--arcade-neon-green); border:2px solid var(--arcade-neon-green); border-radius:6px; box-shadow:0 0 12px rgba(57,255,20,0.4); cursor:pointer; text-transform:uppercase; letter-spacing:1px; }
    .obtn:active { background: rgba(57,255,20,0.15); }
  `;

  const HS_KEY = 'arcade-highscore-brick-blaster';
  const COLS = 10;
  const ROWS = 6;
  // row colors + points (top rows worth more)
  const ROW_COLORS = ['#ff2d95', '#b14dff', '#00fff2', '#39ff14', '#f9f871', '#ff8c2a'];
  const ROW_POINTS = [60, 50, 40, 30, 20, 10];

  class BrickBlaster extends HTMLElement {
    constructor() { super(); this.attachShadow({ mode: 'open' }); }
    connectedCallback() {
      const root = this.shadowRoot;
      root.innerHTML = `
        <style>${STYLE}</style>
        <div class="wrap" id="wrap">
          <div class="head">
            <div class="title">BRICK BLASTER</div>
            <div class="hint">← → / A D · drag · SPACE launch</div>
          </div>
          <div class="bar">
            <div class="stat"><div class="l">SCORE</div><div class="v" id="score">0</div></div>
            <div class="stat"><div class="l">LIVES</div><div class="v" id="lives">3</div></div>
            <div class="stat"><div class="l">BRICKS</div><div class="v" id="bricks">0</div></div>
            <div class="stat best"><div class="l">BEST</div><div class="v" id="best">0</div></div>
          </div>
          <canvas id="cv" width="640" height="420"></canvas>
          <div class="touch" id="touch">
            <div class="row"><button class="tbtn" data-dir="left">◀ LEFT</button><button class="tbtn" data-dir="right">RIGHT ▶</button></div>
            <div class="row" style="margin-top:6px;"><button class="tbtn" data-act="launch">▲ LAUNCH</button></div>
          </div>
          <div class="overlay" id="overlay">
            <div class="ocard">
              <div class="otitle" id="otitle">GAME OVER</div>
              <div class="oscore" id="oscore">SCORE 0</div>
              <div class="ohs" id="ohs">BEST 0</div>
              <button class="obtn" id="restart">PLAY AGAIN</button>
            </div>
          </div>
        </div>
      `;
      this.cv = root.getElementById('cv');
      this.ctx = this.cv.getContext('2d');
      this.scoreEl = root.getElementById('score');
      this.livesEl = root.getElementById('lives');
      this.bricksEl = root.getElementById('bricks');
      this.bestEl = root.getElementById('best');
      this.overlay = root.getElementById('overlay');
      this.otitle = root.getElementById('otitle');
      this.oscore = root.getElementById('oscore');
      this.ohs = root.getElementById('ohs');
      this.touchWrap = root.getElementById('touch');

      const isTouch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
      if (isTouch) this.touchWrap.style.display = 'block';

      this.keys = { left: false, right: false };
      this._onKey = (e) => this.onKey(e, true);
      this._onKeyUp = (e) => this.onKey(e, false);
      this._onResize = () => this.resize();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('keyup', this._onKeyUp);
      window.addEventListener('resize', this._onResize);
      this._onPointer = (e) => this.onPointer(e);
      this.cv.addEventListener('pointerdown', this._onPointer);
      this.cv.addEventListener('pointermove', this._onPointer);

      root.getElementById('restart').addEventListener('click', () => this.reset(true));
      this.touchWrap.addEventListener('pointerdown', (e) => {
        const btn = e.target.closest('.tbtn');
        if (!btn) return;
        if (btn.dataset.dir === 'left') this.touchDir = -1;
        else if (btn.dataset.dir === 'right') this.touchDir = 1;
        else if (btn.dataset.act === 'launch') this.launch();
      });
      this.touchWrap.addEventListener('pointerup', () => { this.touchDir = 0; });
      this.touchWrap.addEventListener('pointerleave', () => { this.touchDir = 0; });

      this.highScore = this.loadHighScore();
      this.bestEl.textContent = this.highScore;
      this.reset();
      this.loop();
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('keyup', this._onKeyUp);
      window.removeEventListener('resize', this._onResize);
      this.cv.removeEventListener('pointerdown', this._onPointer);
      this.cv.removeEventListener('pointermove', this._onPointer);
      cancelAnimationFrame(this.raf);
    }
    resize() {
      const w = this.clientWidth || 640;
      const ratio = 640 / 420;
      let cw = w; let ch = cw / ratio;
      this.cv.width = cw; this.cv.height = ch;
      this.scale = cw / 640;
    }
    loadHighScore() { try { return parseInt(localStorage.getItem(HS_KEY) || '0', 10) || 0; } catch (e) { return 0; } }
    saveHighScore(v) { try { localStorage.setItem(HS_KEY, String(v)); } catch (e) {} }

    reset(restart) {
      this.W = 640; this.H = 420;
      this.paddleW = 92; this.paddleH = 14;
      this.ballR = 7;
      this.paddleX = (this.W - this.paddleW) / 2;
      this.score = 0; this.lives = 3; this.over = false;
      this.touchDir = 0;
      this.totalBricks = COLS * ROWS;
      this.bricksLeft = this.totalBricks;
      this.baseSpeed = 4.2;
      this.buildBricks();
      this.resetBall();
      this.updateHud();
      this.overlay.classList.remove('show');
      if (restart) this.loop();
    }
    buildBricks() {
      this.bricks = [];
      const bw = (this.W - 40) / COLS;
      const bh = 20;
      const top = 40;
      for (let r = 0; r < ROWS; r++) {
        for (let c = 0; c < COLS; c++) {
          this.bricks.push({
            x: 20 + c * bw, y: top + r * (bh + 4), w: bw - 3, h: bh,
            color: ROW_COLORS[r], points: ROW_POINTS[r], alive: true
          });
        }
      }
    }
    resetBall() {
      this.ballX = this.paddleX + this.paddleW / 2;
      this.ballY = this.H - 40;
      this.vx = 0; this.vy = 0;
      this.stuck = true;
    }
    launch() {
      if (!this.stuck || this.over) return;
      this.stuck = false;
      const speed = this.currentSpeed();
      this.vx = speed * (Math.random() < 0.5 ? -1 : 1) * 0.5;
      this.vy = -speed * 0.85;
    }
    currentSpeed() {
      const cleared = this.totalBricks - this.bricksLeft;
      return this.baseSpeed + cleared * 0.04;
    }
    updateHud() {
      this.scoreEl.textContent = this.score;
      this.livesEl.textContent = this.lives;
      this.bricksEl.textContent = this.bricksLeft;
    }
    onKey(e, down) {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') { this.keys.left = down; e.preventDefault(); }
      else if (k === 'arrowright' || k === 'd') { this.keys.right = down; e.preventDefault(); }
      else if (k === ' ' && down) { e.preventDefault(); this.launch(); }
    }
    onPointer(e) {
      const rect = this.cv.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width * this.W;
      this.paddleX = Math.max(0, Math.min(this.W - this.paddleW, x - this.paddleW / 2));
      if (this.stuck) this.ballX = this.paddleX + this.paddleW / 2;
    }
    update() {
      if (this.over) return;
      const ps = 7.5;
      if (this.keys.left || this.touchDir === -1) this.paddleX -= ps;
      if (this.keys.right || this.touchDir === 1) this.paddleX += ps;
      this.paddleX = Math.max(0, Math.min(this.W - this.paddleW, this.paddleX));
      if (this.stuck) {
        this.ballX = this.paddleX + this.paddleW / 2;
        return;
      }
      this.ballX += this.vx;
      this.ballY += this.vy;
      // walls
      if (this.ballX < this.ballR) { this.ballX = this.ballR; this.vx *= -1; }
      if (this.ballX > this.W - this.ballR) { this.ballX = this.W - this.ballR; this.vx *= -1; }
      if (this.ballY < this.ballR) { this.ballY = this.ballR; this.vy *= -1; }
      // paddle
      if (this.vy > 0 && this.ballY + this.ballR >= this.H - 26 &&
          this.ballY + this.ballR <= this.H - 12 &&
          this.ballX > this.paddleX && this.ballX < this.paddleX + this.paddleW) {
        const rel = (this.ballX - (this.paddleX + this.paddleW / 2)) / (this.paddleW / 2);
        const maxAngle = Math.PI / 3;
        const angle = rel * maxAngle;
        const speed = Math.max(this.currentSpeed(), Math.hypot(this.vx, this.vy));
        this.vx = speed * Math.sin(angle);
        this.vy = -speed * Math.cos(angle);
        this.ballY = this.H - 26 - this.ballR;
      }
      // bottom = lose life
      if (this.ballY > this.H + this.ballR) {
        this.lives--;
        this.updateHud();
        if (this.lives <= 0) this.endGame(false);
        else this.resetBall();
      }
      // bricks
      for (const b of this.bricks) {
        if (!b.alive) continue;
        if (this.ballX + this.ballR > b.x && this.ballX - this.ballR < b.x + b.w &&
            this.ballY + this.ballR > b.y && this.ballY - this.ballR < b.y + b.h) {
          b.alive = false;
          this.bricksLeft--;
          this.score += b.points;
          // determine collision side for realistic bounce
          const overlapX = Math.min(this.ballX + this.ballR - b.x, b.x + b.w - (this.ballX - this.ballR));
          const overlapY = Math.min(this.ballY + this.ballR - b.y, b.y + b.h - (this.ballY - this.ballR));
          if (overlapX < overlapY) this.vx *= -1; else this.vy *= -1;
          // speed up slightly
          const sp = Math.hypot(this.vx, this.vy) * 1.015;
          const cur = this.currentSpeed();
          const target = Math.min(sp, cur * 1.8);
          const ang = Math.atan2(this.vy, this.vx);
          this.vx = target * Math.cos(ang);
          this.vy = target * Math.sin(ang);
          this.updateHud();
          if (this.bricksLeft <= 0) { this.endGame(true); break; }
          break;
        }
      }
    }
    endGame(won) {
      this.over = true;
      cancelAnimationFrame(this.raf);
      if (this.score > this.highScore) { this.highScore = this.score; this.saveHighScore(this.highScore); }
      this.bestEl.textContent = this.highScore;
      this.otitle.textContent = won ? 'YOU CLEARED IT!' : 'GAME OVER';
      this.otitle.className = 'otitle ' + (won ? 'win' : 'lose');
      this.oscore.textContent = 'SCORE ' + this.score;
      this.ohs.textContent = 'BEST ' + this.highScore;
      this.overlay.classList.add('show');
      this.dispatchEvent(new CustomEvent('game-over', {
        detail: { game: 'brick-blaster', score: this.score },
        bubbles: true, composed: true
      }));
    }
    draw() {
      const ctx = this.ctx, s = this.scale || 1;
      ctx.fillStyle = '#05050c';
      ctx.fillRect(0, 0, this.cv.width, this.cv.height);
      ctx.save();
      ctx.scale(s, s);
      // bricks
      for (const b of this.bricks) {
        if (!b.alive) continue;
        ctx.shadowColor = b.color; ctx.shadowBlur = 10;
        ctx.fillStyle = b.color;
        ctx.fillRect(b.x, b.y, b.w, b.h);
        ctx.shadowBlur = 0;
        ctx.fillStyle = 'rgba(255,255,255,0.25)';
        ctx.fillRect(b.x, b.y, b.w, 3);
      }
      // paddle
      ctx.shadowColor = '#00fff2'; ctx.shadowBlur = 14;
      ctx.fillStyle = '#00fff2';
      ctx.fillRect(this.paddleX, this.H - 26, this.paddleW, this.paddleH);
      ctx.shadowBlur = 0;
      // ball
      ctx.shadowColor = '#f9f871'; ctx.shadowBlur = 14;
      ctx.fillStyle = '#f9f871';
      ctx.beginPath(); ctx.arc(this.ballX, this.ballY, this.ballR, 0, Math.PI * 2); ctx.fill();
      ctx.shadowBlur = 0;
      // launch hint
      if (this.stuck && !this.over) {
        ctx.fillStyle = 'rgba(255,255,255,0.6)';
        ctx.font = "9px 'Press Start 2P', monospace";
        ctx.textAlign = 'center';
        ctx.fillText('PRESS SPACE / LAUNCH', this.W / 2, this.H - 50);
      }
      ctx.restore();
    }
    loop() {
      if (this.over) return;
      this.update(); this.draw();
      this.raf = requestAnimationFrame(() => this.loop());
    }
  }
  customElements.define('brick-blaster', BrickBlaster);
})();
