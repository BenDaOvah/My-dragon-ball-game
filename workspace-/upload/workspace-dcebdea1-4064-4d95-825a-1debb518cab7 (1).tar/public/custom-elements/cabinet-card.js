// Wix Custom Element — save as public/custom-elements/cabinet-card.js — tag: cabinet-card

(function () {
  const STYLE = `
    :host {
      display: block; width: 100%;
      --arcade-bg: #0a0a12;
      --arcade-panel: #14141f;
      --arcade-neon-pink: #ff2d95;
      --arcade-neon-cyan: #00fff2;
      --arcade-neon-yellow: #f9f871;
      --arcade-neon-green: #39ff14;
      --font-pixel: 'Press Start 2P', monospace;
      --font-body: system-ui, -apple-system, sans-serif;
      font-family: var(--font-body);
    }
    .card {
      position: relative;
      display: block;
      width: 100%;
      background: linear-gradient(180deg, var(--arcade-panel) 0%, var(--arcade-bg) 100%);
      border: 2px solid var(--arcade-neon-cyan);
      border-radius: 12px;
      padding: 18px 16px 16px;
      cursor: pointer;
      text-align: center;
      box-shadow: 0 0 12px rgba(0,255,242,0.25), inset 0 0 24px rgba(0,255,242,0.04);
      transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
      overflow: hidden;
      outline: none;
    }
    .card::before {
      content: ""; position: absolute; inset: 0; pointer-events: none; z-index: 4;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.04) 0px, rgba(255,255,255,0.04) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay;
    }
    .card:hover, .card:focus-visible {
      transform: translateY(-4px);
      border-color: var(--arcade-neon-pink);
      box-shadow: 0 0 22px rgba(255,45,149,0.55), inset 0 0 28px rgba(255,45,149,0.06);
    }
    .marquee-top {
      position: relative; z-index: 3;
      font-family: var(--font-pixel);
      font-size: clamp(9px, 1.7vw, 12px);
      letter-spacing: 1px;
      color: var(--arcade-neon-yellow);
      text-shadow: 0 0 8px rgba(249,248,113,0.7);
      margin-bottom: 12px;
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .screen {
      position: relative; z-index: 3;
      width: 100%;
      aspect-ratio: 4 / 3;
      background: #05050c;
      border: 2px solid #2a2a3d;
      border-radius: 8px;
      overflow: hidden;
      display: flex; align-items: center; justify-content: center;
      box-shadow: inset 0 0 18px rgba(0,0,0,0.8);
    }
    .screen::after {
      content: ""; position: absolute; inset: 0; pointer-events: none;
      background: repeating-linear-gradient(to bottom, rgba(255,255,255,0.05) 0px, rgba(255,255,255,0.05) 1px, transparent 1px, transparent 3px);
      mix-blend-mode: overlay;
    }
    .icon {
      font-size: clamp(40px, 9vw, 64px);
      filter: drop-shadow(0 0 10px currentColor);
      line-height: 1;
    }
    .title {
      position: relative; z-index: 3;
      font-family: var(--font-pixel);
      font-size: clamp(11px, 2vw, 15px);
      color: var(--arcade-neon-cyan);
      text-shadow: 0 0 8px rgba(0,255,242,0.6);
      margin-top: 14px;
      line-height: 1.3;
    }
    .play {
      position: relative; z-index: 3;
      font-family: var(--font-pixel);
      font-size: 9px;
      color: var(--arcade-neon-green);
      letter-spacing: 1px;
      margin-top: 10px;
      opacity: 0.85;
    }
    .card:hover .play, .card:focus-visible .play { opacity: 1; }
    .knobs {
      position: relative; z-index: 3;
      display: flex; justify-content: center; gap: 10px;
      margin-top: 12px;
    }
    .knob {
      width: 10px; height: 10px; border-radius: 50%;
      background: radial-gradient(circle at 30% 30%, #555, #111);
      border: 1px solid #333;
      box-shadow: 0 0 4px rgba(0,0,0,0.6);
    }
  `;

  class CabinetCard extends HTMLElement {
    constructor() { super(); this.attachShadow({ mode: 'open' }); }
    static get observedAttributes() { return ['game-title', 'game-tag', 'game-icon', 'icon-color']; }
    connectedCallback() { this.render(); this._wire(); }
    attributeChangedCallback() { this.render(); }
    get gameTitle() { return this.getAttribute('game-title') || 'UNKNOWN'; }
    get gameTag() { return this.getAttribute('game-tag') || ''; }
    get gameIcon() { return this.getAttribute('game-icon') || '🎮'; }
    get iconColor() { return this.getAttribute('icon-color') || '#00fff2'; }
    render() {
      this.shadowRoot.innerHTML = `
        <style>${STYLE}</style>
        <button class="card" type="button" role="button" tabindex="0" aria-label="Play ${this.gameTitle}">
          <div class="marquee-top">${this.gameTitle.toUpperCase()}</div>
          <div class="screen">
            <span class="icon" style="color:${this.iconColor}">${this.gameIcon}</span>
          </div>
          <div class="title">${this.gameTitle}</div>
          <div class="knobs"><span class="knob"></span><span class="knob"></span></div>
          <div class="play">▶ INSERT COIN</div>
        </button>
      `;
    }
    _wire() {
      const card = this.shadowRoot.querySelector('.card');
      if (!card) return;
      const activate = () => {
        this.dispatchEvent(new CustomEvent('cabinet-selected', {
          detail: { gameTag: this.gameTag },
          bubbles: true, composed: true
        }));
      };
      card.addEventListener('click', activate);
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activate(); }
      });
    }
  }
  customElements.define('cabinet-card', CabinetCard);
})();
